function e(e, t, o) {
    return t in e ? Object.defineProperty(e, t, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = o, e;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    var o = !0, r = (0, t.getItem)("loginInfo").userId, i = (0, t.getItem)("totalGoodsCodeSwitch");
    if (i) {
        var n = i[r];
        void 0 === n ? (0, t.setItem)("totalGoodsCodeSwitch", Object.assign(i, e({}, r, o))) : o = n;
    } else (0, t.setItem)("totalGoodsCodeSwitch", e({}, r, o));
    return o;
};

!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var t = require("./storage");