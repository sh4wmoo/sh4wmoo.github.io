Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getUUID = exports.uuid = void 0;

!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

require("../../libs/analytics-v1.7.0");

var e = require("./storage.js"), r = exports.uuid = (0, e.getItem)("uuid");

if (!r) {
    var t = (0, e.getItem)("_lx_sdk_lxcuid");
    t.length < 64 ? t += Array(64 - t.length).fill("0").join("") : t = t.slice(0, 64), 
    exports.uuid = r = t, (0, e.setItem)("uuid", r);
}

exports.getUUID = function() {
    return Promise.resolve(r);
};