Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e) {
    return e.map(function(e) {
        return e.name = e.name ? e.name : e.phone ? e.phone : "您的好友", e.status = e.status || {}, 
        e.label = 10 === e.status.value ? "remind" : "", e.text = e.status.text || "", e.avatarUrl = e.avatarUrl ? e.avatarUrl : "https://vfile.meituan.net/paotui/jfi673poikvs4i.png", 
        e;
    });
};

!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));