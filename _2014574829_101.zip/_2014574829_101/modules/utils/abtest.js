function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.configPromise = exports.globalConfig = void 0;

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = e(require("../api/fetch.js")), t = require("./util.js"), o = require("./storage.js"), a = e(require("../global.js")), i = require("./uuid.js"), n = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var t = arguments[r];
        for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
    }
    return e;
}, s = a.default.domain, c = a.default.version, d = exports.globalConfig = {
    abtest_authorization_page: "v1",
    favorites_degrade: !1,
    testIdMapping: {
        wx_authorize: "a",
        wx_groupcoupon: "a",
        ab_wx_190_groupcoupon_UI: "a",
        addresspage_autorecognition: "a",
        modify_order: "A",
        address_recommend: 201,
        recognition_address_pic: "A",
        recognition_address_clipboard: "A",
        recognition_address_gif: "A",
        certification_test: "",
        wx_search_aoi: "A",
        miniprogram_websocket: "A",
        miniProgram_backFromPay: "A",
        processing_order_entry: "A",
        urge_grab: "A"
    },
    testIdParams: {
        recognition_address_gif: {
            strategy: "a"
        }
    },
    cancelFeeRefreshInterval: 5
}, u = (0, o.getItem)("actPoint") || {};

exports.configPromise = (0, i.getUUID)().then(function(e) {
    return (0, r.default)({
        url: s + "/wx/v1/system/config",
        method: "POST",
        header: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        },
        data: {
            uuid: e,
            wm_ctype: a.default.clientType,
            wm_appversion: c,
            longitude: (0, t.locFormat)(u.lng || 116.44355),
            latitude: (0, t.locFormat)(u.lat || 39.9219)
        }
    });
}).then(function(e) {
    0 === e.code && (exports.globalConfig = d = Object.assign(d, n({}, e.data)));
}).catch(function(e) {});