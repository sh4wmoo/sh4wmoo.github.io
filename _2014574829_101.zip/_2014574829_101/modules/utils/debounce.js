function n(n) {
    var o = void 0 === n ? "undefined" : t(n);
    return null != n && ("object" == o || "function" == o);
}

var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(n) {
    return typeof n;
} : function(n) {
    return n && "function" == typeof Symbol && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : typeof n;
}, t = (function(n) {
    n && n.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js")), "function" == typeof Symbol && "symbol" === o(Symbol.iterator) ? function(n) {
    return void 0 === n ? "undefined" : o(n);
} : function(n) {
    return n && "function" == typeof Symbol && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : void 0 === n ? "undefined" : o(n);
}), i = 300, e = {
    leading: !0,
    trailing: !1
};

module.exports = function(o) {
    function t(n) {
        var t = m, i = y;
        return m = y = void 0, S = n, s = o.apply(i, t);
    }
    function r(n) {
        return S = n, b = setTimeout(c, a), h ? t(n) : s;
    }
    function u(n) {
        var o = n - S, t = a - (n - g);
        return T ? Math.min(t, p - o) : t;
    }
    function f(n) {
        var o = n - g, t = n - S;
        return void 0 === g || o >= a || o < 0 || T && t >= p;
    }
    function c() {
        var n = Date.now();
        if (f(n)) return d(n);
        b = setTimeout(c, u(n));
    }
    function d(n) {
        return b = void 0, w && m ? t(n) : (m = y = void 0, s);
    }
    function l() {
        for (var n = Date.now(), o = f(n), i = arguments.length, e = Array(i), u = 0; u < i; u++) e[u] = arguments[u];
        if (m = e, y = this, g = n, o) {
            if (void 0 === b) return r(g);
            if (T) return b = setTimeout(c, a), t(g);
        }
        return void 0 === b && (b = setTimeout(c, a)), s;
    }
    var a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i, v = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : e, m = void 0, y = void 0, p = void 0, s = void 0, b = void 0, g = void 0, S = 0, h = !1, T = !1, w = !0;
    if ("function" != typeof o) throw new TypeError("Expected a function");
    return a = +a || 0, n(v) && (h = !!v.leading, p = (T = "maxWait" in v) ? Math.max(+v.maxWait || 0, a) : p, 
    w = "trailing" in v ? !!v.trailing : w), l.cancel = function() {
        void 0 !== b && clearTimeout(b), S = 0, m = g = y = b = void 0;
    }, l.flush = function() {
        return void 0 === b ? s : d(Date.now());
    }, l.pending = function() {
        return void 0 !== b;
    }, l;
};