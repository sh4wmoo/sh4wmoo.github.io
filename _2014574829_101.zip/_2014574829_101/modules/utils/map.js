function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = e(require("../../libs/qqmap-wx-jssdk.js"));

exports.default = new r.default({
    key: "APOBZ-NAFHR-2EMWO-WZHIO-V5J55-7XFF7"
});