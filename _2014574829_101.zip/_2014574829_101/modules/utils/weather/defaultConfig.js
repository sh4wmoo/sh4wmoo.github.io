Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        rain: {
            hasCloud: !0,
            linearGradient: {
                from: "rgba(41, 41, 47, 0.3)",
                to: "rgba(41, 41, 47, 0)"
            }
        },
        sun: {
            center: {
                x: 60,
                y: 60
            },
            lightWave: {
                enable: !0,
                url: "https://p1.meituan.net/paotui/k7vx7cfst4.png",
                size: {
                    w: 281,
                    h: 281
                },
                pos: {
                    x: -141,
                    y: -141
                }
            },
            sunShine: {
                enable: !0,
                url: "https://p0.meituan.net/paotui/k7vx76sqs2a.png",
                size: {
                    w: 600,
                    h: 600
                },
                pos: {
                    x: -300,
                    y: -300
                }
            },
            cover: {
                enable: !0,
                from: "rgba(255, 191, 0, 0.25)",
                to: "rgba(255, 191, 0, 0)"
            }
        }
    };
};

!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));