function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function r(i, o) {
                try {
                    var a = t[i](o), c = a.value;
                } catch (e) {
                    return void n(e);
                }
                if (!a.done) return Promise.resolve(c).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(c);
            }
            return r("next");
        });
    };
}

function n(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function r(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" !== (void 0 === t ? "undefined" : o(t)) && "function" != typeof t ? e : t;
}

function i(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + (void 0 === t ? "undefined" : o(t)));
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, a = e(require("../../../../libs/regenerator-runtime/runtime-module.js")), c = e(require("../../../../libs/particles.js")), s = e(require("./base.js")), u = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), l = {
    canvas: {
        tag_id: "weather",
        w: 750,
        h: 360
    },
    particles: {
        number: {
            value: 200,
            density: {
                enable: !0,
                value_area: 500
            }
        },
        color: {
            value: "#ffffff"
        },
        shape: {
            type: "line",
            radius: 5,
            stroke: {
                random: !0,
                width: 5,
                color: "#ffffff"
            }
        },
        opacity: {
            value: 1,
            random: !0,
            anim: {
                enable: !1,
                speed: 1,
                opacity_min: 1,
                sync: !1
            }
        },
        size: {
            value: 10,
            random: !0,
            anim: {
                enable: !1,
                speed: 40,
                size_min: .1,
                sync: !1
            }
        },
        line_linked: {
            enable: !1,
            distance: 150,
            color: "#000000",
            opacity: 0,
            width: 1
        },
        move: {
            enable: !0,
            speed: 50,
            direction: "custom",
            custom_direction: {
                x: .1,
                y: .6
            },
            random: !1,
            straight: !0,
            out_mode: "out",
            bounce: !1,
            attract: {
                enable: !1,
                rotateX: 600,
                rotateY: 1200
            }
        }
    },
    interactivity: {
        detect_on: "canvas",
        events: {
            onhover: {
                enable: !1,
                mode: "grab"
            },
            onclick: {
                enable: !1,
                mode: "push"
            },
            resize: !1
        },
        modes: {
            grab: {
                distance: 140,
                line_linked: {
                    opacity: 1
                }
            },
            bubble: {
                distance: 400,
                size: 40,
                duration: 2,
                opacity: 8,
                speed: 3
            },
            repulse: {
                distance: 200,
                duration: .4
            },
            push: {
                particles_nb: 4
            },
            remove: {
                particles_nb: 2
            }
        }
    },
    retina_detect: !0
}, d = function(e) {
    function o(e, t, i) {
        return n(this, o), r(this, (o.__proto__ || Object.getPrototypeOf(o)).call(this, e, t, i));
    }
    return i(o, s.default), u(o, [ {
        key: "start",
        value: function() {
            var e = t(a.default.mark(function e(t) {
                var n, r, i, o, s, u, d, f, p, h, v, b, m, y, x, w, g, _, S, k, j, P, O, I, C, J, z, q, E, G = this;
                return a.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n = void 0, e.prev = 1, e.next = 4, this.downLoadImageList(this.canvas, [ "https://p0.meituan.net/paotui/k88n71fwo2.png", "https://p1.meituan.net/paotui/k7ne2tnxjem.png", "https://p0.meituan.net/paotui/k88n6w949ag.png" ]);

                      case 4:
                        n = e.sent, e.next = 10;
                        break;

                      case 7:
                        return e.prev = 7, e.t0 = e.catch(1), e.abrupt("return");

                      case 10:
                        r = this.cWidth, i = this.cHeight, o = n[0].img, s = n[1].img, u = n[2].img, d = this.ctx.createLinearGradient(0, 0, 0, i), 
                        f = this.calcPx(1400), p = this.calcPx(446), h = this.calcPx(12) / 1e3, v = n[0].res.width, 
                        b = n[0].res.height, m = f / v, y = this.calcPx(20) / 1e3, x = n[2].res.width, w = n[2].res.height, 
                        g = f / x, _ = n[1].res.width, S = n[1].res.height, k = p / _, j = void 0, P = void 0, 
                        O = void 0, I = void 0, C = void 0, J = void 0, z = void 0, q = void 0, E = function(e) {
                            void 0 === O && (O = e), void 0 === j && (j = e), void 0 === P && (P = e), void 0 === C && (C = r - 2 * f), 
                            void 0 === J && (J = r - f), void 0 === z && (z = r - 2 * f), void 0 === q && (q = r - f);
                            var n = e - O;
                            if (n % 4e3 >= 3920 && (I = n), I && n - I >= 200 && (I = void 0), d.addColorStop(0, t.linearGradient.from), 
                            d.addColorStop(1, t.linearGradient.to), G.ctx.fillStyle = d, G.ctx.save(), I && n - I >= 80 && (G.ctx.globalAlpha = .2), 
                            G.ctx.fillRect(0, 0, r, i), G.ctx.restore(), t.hasCloud) {
                                var a = h * (e - j) + C;
                                a >= J && (j = void 0, J = a, C = a - f), G.ctx.save(), G.ctx.scale(m, m), G.ctx.drawImage(o, a / m, 0, v, b), 
                                G.ctx.drawImage(o, (a + f) / m, 0, v, b), G.ctx.restore();
                            }
                            if (I && n - I >= 80 && (G.ctx.save(), G.ctx.scale(k, k), G.ctx.drawImage(s, 0, 0, _, S), 
                            G.ctx.restore()), t.hasCloud) {
                                var c = y * (e - P) + z;
                                c >= q && (P = void 0, q = c, z = c - f), G.ctx.save(), G.ctx.globalAlpha = .9, 
                                G.ctx.scale(g, g), G.ctx.drawImage(u, c / g, 0, x, w), G.ctx.drawImage(u, (c + f) / g, 0, x, w), 
                                G.ctx.restore();
                            }
                        }, l.callback = {
                            afterDraw: E
                        }, l.canvas.w = r, l.canvas.h = i, l.canvas.el = this.canvas, l.canvas.ctx = this.ctx, 
                        this.pJS = new c.default("weather", l);

                      case 44:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 1, 7 ] ]);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }()
    }, {
        key: "stop",
        value: function() {
            this.pJS && this.pJS.pJS.fn.vendors.destroypJS(), this.ctx.clearRect(0, 0, this.cWidth, this.cHeight);
        }
    } ]), o;
}();

exports.default = d;