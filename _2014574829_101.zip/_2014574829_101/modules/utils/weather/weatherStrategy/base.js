function t(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

!function(t) {
    t && t.__esModule;
}(require("../../../../libs/regenerator-runtime/runtime-module.js"));

var e = function() {
    function t(t, e) {
        for (var n = 0; n < e.length; n++) {
            var i = e[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(t, i.key, i);
        }
    }
    return function(e, n, i) {
        return n && t(e.prototype, n), i && t(e, i), e;
    };
}(), n = function() {
    function n(e, i, r) {
        t(this, n), this.dpr = i, this.canvas = e.node, this.cWidth = e.width * this.dpr, 
        this.cHeight = e.height * this.dpr, this.canvas.width = this.cWidth, this.canvas.height = this.cHeight, 
        this.ctx = this.canvas.getContext("2d"), this.start(r);
    }
    return e(n, [ {
        key: "start",
        value: function() {}
    }, {
        key: "stop",
        value: function() {}
    }, {
        key: "downloadImage",
        value: function(t, e) {
            return new Promise(function(n, i) {
                var r = t.createImage();
                r.onload = function() {
                    wx.getImageInfo({
                        src: e,
                        success: function(t) {
                            n({
                                img: r,
                                res: t
                            });
                        }
                    });
                }, r.onerror = function(t) {
                    i(t);
                }, r.src = e;
            });
        }
    }, {
        key: "downLoadImageList",
        value: function(t, e) {
            var n = this;
            return Promise.all(e.map(function(e) {
                return n.downloadImage(t, e);
            }));
        }
    }, {
        key: "calcPx",
        value: function(t) {
            return Math.ceil(t * this.cWidth / 750);
        }
    } ]), n;
}();

exports.default = n;