function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function r(a, o) {
                try {
                    var i = t[a](o), c = i.value;
                } catch (e) {
                    return void n(e);
                }
                if (!i.done) return Promise.resolve(c).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(c);
            }
            return r("next");
        });
    };
}

function n(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function r(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" !== (void 0 === t ? "undefined" : o(t)) && "function" != typeof t ? e : t;
}

function a(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + (void 0 === t ? "undefined" : o(t)));
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, i = e(require("../../../../libs/regenerator-runtime/runtime-module.js")), c = e(require("./base.js")), u = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), s = function(e) {
    function o(e, t, a) {
        n(this, o);
        var i = r(this, (o.__proto__ || Object.getPrototypeOf(o)).call(this, e, t, a));
        return i.animationFrame = null, i;
    }
    return a(o, c.default), u(o, [ {
        key: "start",
        value: function() {
            var e = t(i.default.mark(function e(t) {
                var n, r, a, o, c, u, s, l = this;
                return i.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n = this.cHeight, r = this.cWidth, a = void 0, e.prev = 3, e.next = 6, this.downLoadImageList(this.canvas, [ t.sunShine.url, t.lightWave.url ]);

                      case 6:
                        a = e.sent, e.next = 12;
                        break;

                      case 9:
                        return e.prev = 9, e.t0 = e.catch(3), e.abrupt("return");

                      case 12:
                        o = this.ctx.createLinearGradient(0, 0, 0, n), c = null, u = 10, s = function e(i) {
                            l.ctx.clearRect(0, 0, r, n), c || (c = i);
                            var s = i - c;
                            if (t.cover.enable && (o.addColorStop(0, t.cover.from), o.addColorStop(1, t.cover.to), 
                            l.ctx.fillStyle = o, l.ctx.fillRect(0, 0, r, n)), l.ctx.save(), l.ctx.translate(l.calcPx(t.center.x), l.calcPx(t.center.y)), 
                            t.sunShine.enable && (l.ctx.save(), l.ctx.rotate(s / 1e3 * u % 360 * Math.PI / 180), 
                            l.ctx.drawImage(a[0].img, l.calcPx(t.sunShine.pos.x), l.calcPx(t.sunShine.pos.y), l.calcPx(t.sunShine.size.w), l.calcPx(t.sunShine.size.h)), 
                            l.ctx.restore()), t.lightWave.enable && Math.floor(s / 1e3) % 3 == 0) {
                                l.ctx.save();
                                var f = s % 1e3;
                                f > 800 && (l.ctx.globalAlpha = 1 - (f - 800) / 200);
                                var h = f / 1e3 * 3 + 1;
                                l.ctx.scale(h, h), l.ctx.drawImage(a[1].img, l.calcPx(t.lightWave.pos.x), l.calcPx(t.lightWave.pos.y), l.calcPx(t.lightWave.size.w), l.calcPx(t.lightWave.size.h)), 
                                l.ctx.restore();
                            }
                            l.ctx.restore(), l.animationFrame = l.canvas.requestAnimationFrame(e);
                        }, this.animationFrame = this.canvas.requestAnimationFrame(s);

                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 3, 9 ] ]);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }()
    }, {
        key: "stop",
        value: function() {
            this.animationFrame && this.canvas.cancelAnimationFrame(this.animationFrame), this.ctx.clearRect(0, 0, this.cWidth, this.cHeight);
        }
    } ]), o;
}();

exports.default = s;