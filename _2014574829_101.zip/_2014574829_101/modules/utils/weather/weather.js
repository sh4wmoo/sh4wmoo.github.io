function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function n(i, s) {
                try {
                    var u = t[i](s), a = u.value;
                } catch (e) {
                    return void r(e);
                }
                if (!u.done) return Promise.resolve(a).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(a);
            }
            return n("next");
        });
    };
}

function r(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var n = e(require("../../../libs/regenerator-runtime/runtime-module.js")), i = e(require("./weatherStrategy/rain.js")), s = e(require("./weatherStrategy/sun.js")), u = require("../util.js"), a = e(require("./defaultConfig.js")), o = e(require("../../global.js")), c = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), f = wx.getSystemInfoSync(), l = f.pixelRatio || 1, h = f.SDKVersion, d = (0, 
u.getSystemVersion)(o.default.systemInfo), p = (0, u.compareVersion)(h, "2.9.0") >= 0, y = o.default.isIOS && (0, 
u.compareVersion)(d, "13.0.0") >= 0, v = {
    1: {
        key: "rain",
        class: i.default
    },
    4: {
        key: "sun",
        class: s.default
    },
    11: {
        key: "rain",
        class: i.default
    },
    14: {
        key: "sun",
        class: s.default
    }
}, g = function() {
    function e(t, n) {
        var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        r(this, e), this.tagId = t, this.isStop = !0, this.config = (0, u.deepExtend)((0, 
        a.default)(), i), this.start(n);
    }
    return c(e, [ {
        key: "start",
        value: function(e) {
            var r = this;
            if (p && y && (this.currentWeatherType !== e || !1 !== this.isStop)) {
                this.currentWeatherType = e, this.stop();
                var i = v[e];
                i && wx.createSelectorQuery().select("#" + this.tagId).fields({
                    node: !0,
                    size: !0
                }).exec(function() {
                    var e = t(n.default.mark(function e(t) {
                        var s;
                        return n.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                s = i.class, r.currentWeather = new s(t[0], l, r.config[i.key]), r.isStop = !1;

                              case 3:
                              case "end":
                                return e.stop();
                            }
                        }, e, r);
                    }));
                    return function(t) {
                        return e.apply(this, arguments);
                    };
                }());
            }
        }
    }, {
        key: "stop",
        value: function() {
            this.currentWeather && this.currentWeather.stop(), this.isStop = !0;
        }
    } ]), e;
}();

exports.default = g;