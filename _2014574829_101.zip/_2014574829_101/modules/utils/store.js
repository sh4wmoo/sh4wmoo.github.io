function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, o = (t(require("../../libs/regenerator-runtime/runtime-module.js")), require("./util")), i = t(require("../computed/index")), r = "function" == typeof Symbol && "symbol" === n(Symbol.iterator) ? function(t) {
    return void 0 === t ? "undefined" : n(t);
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : n(t);
}, u = function() {
    function t(t, e) {
        for (var n = 0; n < e.length; n++) {
            var o = e[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(t, o.key, o);
        }
    }
    return function(e, n, o) {
        return n && t(e.prototype, n), o && t(e, o), e;
    };
}(), a = function() {
    function t() {
        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        e(this, t), this.state = n.state || {}, this.actions = n.actions || {}, this.computed = n.computed || null, 
        this.vm = null, this.keys = [], this.def();
    }
    return u(t, [ {
        key: "def",
        value: function() {
            var t = this, e = this;
            Object.keys(this.state).forEach(function(n) {
                Object.defineProperty(t, n, {
                    enumerable: !0,
                    configurable: !0,
                    get: function() {
                        return e.getState(n);
                    },
                    set: function() {}
                });
            });
        }
    }, {
        key: "setState",
        value: function(t) {
            var e = this;
            Object.keys(t).forEach(function(n) {
                e.state[n] = t[n];
            });
        }
    }, {
        key: "getState",
        value: function(t) {
            return this.state[t];
        }
    }, {
        key: "mapComputed",
        value: function(t) {
            (0, i.default)(this, t);
        }
    }, {
        key: "mapSetData",
        value: function(t, e) {
            var n = this.state, o = {};
            this.vm = t, this.keys = e, e.forEach(function(t) {
                o[t] = n[t];
            }), t.setData(o);
        }
    }, {
        key: "dispatch",
        value: function(t, e) {
            var n = this, i = function(t) {
                if ("object" === (void 0 === t ? "undefined" : r(t)) && null !== t) {
                    n.setState(t);
                    var e = {};
                    Object.keys(t).forEach(function(o) {
                        n.keys.indexOf(o) > -1 && ("object" === r(n.vm.data[o]) ? e[o] = Object.assign({}, t[o]) : e[o] = t[o]);
                    }), Object.keys(e).length && n.vm.setData(e);
                }
            };
            if ("function" == typeof this.actions[t]) {
                var u = this.actions[t](this, e);
                return (0, o.isPromise)(u) ? u.then(i) : new Promise(function(t) {
                    i(u), t();
                });
            }
        }
    }, {
        key: "destroy",
        value: function() {
            var t = this;
            Object.getOwnPropertyNames(this).forEach(function(e) {
                t[e] = null;
            });
        }
    } ]), t;
}();

exports.default = a;