function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function r(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, t) {
            function a(n, u) {
                try {
                    var s = r[n](u), c = s.value;
                } catch (e) {
                    return void t(e);
                }
                if (!s.done) return Promise.resolve(c).then(function(e) {
                    a("next", e);
                }, function(e) {
                    a("throw", e);
                });
                e(c);
            }
            return a("next");
        });
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = e(require("../../libs/regenerator-runtime/runtime-module.js")), a = require("../api/request.js"), n = require("../api/metrics.js"), u = e(require("../global.js")).default.mafPrefix, s = u + "/geo", c = u + "/regeo", i = u + "/search", o = {
    key: "ae9f5acf-e80d-4219-b686-aaab27abbf06"
}, f = function(e, r) {
    return new Promise(function(t, u) {
        var s = Object.assign({}, r);
        (0, n.request)({
            url: e,
            data: s,
            isRequest: !0,
            success: function(e) {
                t(e);
            },
            fail: function(e) {
                u(e);
            },
            reportError: function(r) {
                return (0, a.mafReportError)(r, {
                    url: e,
                    param: s
                });
            }
        });
    });
};

exports.default = {
    search: function(e) {
        var a = this;
        return r(t.default.mark(function r() {
            var n;
            return t.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, f(i, Object.assign({}, o, e));

                  case 2:
                    if (!((n = r.sent) && n.data && 200 === n.data.status && n.data.result)) {
                        r.next = 7;
                        break;
                    }
                    return r.abrupt("return", n.data.result);

                  case 7:
                    return r.abrupt("return", Promise.reject(n));

                  case 8:
                  case "end":
                    return r.stop();
                }
            }, r, a);
        }))();
    },
    geocoder: function(e) {
        var a = this;
        return r(t.default.mark(function r() {
            var n;
            return t.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, f(s, Object.assign({}, o, e));

                  case 2:
                    if (!((n = r.sent) && n.data && 200 === n.data.status && n.data.result && n.data.result.length > 0)) {
                        r.next = 7;
                        break;
                    }
                    return r.abrupt("return", n.data.result);

                  case 7:
                    return r.abrupt("return", Promise.reject(n));

                  case 8:
                  case "end":
                    return r.stop();
                }
            }, r, a);
        }))();
    },
    reverseGeocoder: function(e) {
        var a = this;
        return r(t.default.mark(function r() {
            var n;
            return t.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, f(c, Object.assign({}, o, e));

                  case 2:
                    if (!((n = r.sent) && n.data && 200 === n.data.status && n.data.result)) {
                        r.next = 7;
                        break;
                    }
                    return r.abrupt("return", n.data.result);

                  case 7:
                    return r.abrupt("return", Promise.reject(n));

                  case 8:
                  case "end":
                    return r.stop();
                }
            }, r, a);
        }))();
    }
};