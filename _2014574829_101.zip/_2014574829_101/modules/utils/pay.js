function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function r(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, t) {
            function n(a, i) {
                try {
                    var s = r[a](i), o = s.value;
                } catch (e) {
                    return void t(e);
                }
                if (!s.done) return Promise.resolve(o).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(o);
            }
            return n("next");
        });
    };
}

function t() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.pay_success_url, t = e.param, n = g({
        pay_success_url: r,
        param: t
    });
    (0, i.navigateTo)({
        url: "/pages/webView/webView?url=" + encodeURIComponent(n)
    });
}

var n = e(require("../../libs/regenerator-runtime/runtime-module.js")), a = require("../../modules/utils/user.js"), i = require("../api/route.js"), s = e(require("../global.js")), o = require("../../modules/api/urls.js"), u = require("../../modules/api/request.js"), c = require("../../modules/utils/storage.js"), p = require("../../modules/api/wx.js"), d = require("../../modules/api/login.js"), l = require("../../modules/api/cat.js"), f = function() {
    var e = r(n.default.mark(function e(r) {
        var t, i, c, p, l;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t = s.default.appId, i = (0, a.getUserInfo)().openId) {
                    e.next = 12;
                    break;
                }
                return e.prev = 3, e.next = 6, (0, d.getOpenIdSilent)();

              case 6:
                c = e.sent, i = c.openId, e.next = 12;
                break;

              case 10:
                e.prev = 10, e.t0 = e.catch(3);

              case 12:
                return p = {
                    orderViewId: r,
                    wmFingerprint: "",
                    fingerprint: "",
                    openId: i,
                    appId: t,
                    deviceInfoByQQ: JSON.stringify({
                        identityInfo: {
                            openid: i,
                            app_id: t
                        },
                        user_type: "wx"
                    })
                }, e.prev = 13, e.next = 16, (0, u.postInfo)(o.prePay, p);

              case 16:
                return l = e.sent, e.abrupt("return", l);

              case 20:
                e.prev = 20, e.t1 = e.catch(13), console.error(e.t1);

              case 23:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 3, 10 ], [ 13, 20 ] ]);
    }));
    return function(r) {
        return e.apply(this, arguments);
    };
}(), m = function() {}, v = s.default.env, y = s.default.payDomain + "/i/cashier/show/index", g = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.pay_success_url, t = void 0 === r ? "" : r, n = e.param, i = void 0 === n ? "" : n, o = (0, 
    a.getUserInfo)() || {}, u = (0, c.getItem)("cityid") || "", p = (0, c.getItem)("uuid") || "", d = (0, 
    c.getItem)("actPoint") || {}, l = d.lat + "_" + d.lng;
    return y + "?auth=v2&redr_url=&app_id=" + s.default.appId + "&nb_app=weixin&" + i + "&token=" + (o.token || "") + "&nb_ci=" + (u || "") + "&pay_success_url=" + encodeURIComponent(t) + "&nb_location=" + (l || "") + "&nb_uuid=" + (p || "");
};

module.exports = {
    ptPay: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.orderViewId, n = e.pay_success_url, a = e.success, i = void 0 === a ? m : a, s = e.fail, o = void 0 === s ? m : s, u = e.mtPayCallback, c = void 0 === u ? m : u, d = e.prePaySuccess, y = void 0 === d ? m : d, g = e.prePayFail, _ = void 0 === g ? m : g;
        f(r).then(function(e) {
            if (0 === e.code && e.data) {
                if ("h5cashier" === e.data.contractType) {
                    var r = e.data.nonCashierPayParams, a = r.slice(0, r.length);
                    t({
                        pay_success_url: n,
                        param: a
                    }), c(), (0, l.reportMetric)("mt_pay");
                } else if ("test" === v) i(); else {
                    var s = null;
                    try {
                        s = JSON.parse(e.data.nonCashierPayParams || "{}");
                    } catch (e) {
                        return void wx.showToast({
                            title: "wx支付参数解析错误",
                            icon: "none"
                        });
                    }
                    var u = s, d = u.timeStamp, f = u.nonceStr, m = u.signType, g = u.paySign;
                    (0, p.requestPayment)({
                        timeStamp: d,
                        nonceStr: f,
                        package: s.package,
                        signType: m,
                        paySign: g
                    }).then(function() {
                        i(), (0, l.reportMetric)("wx_pay_success");
                    }).catch(function(e) {
                        o(e);
                    }), (0, l.reportMetric)("wx_pay");
                }
                y();
            } else wx.showToast({
                title: e.message,
                icon: "none"
            }), _();
        });
    }
};