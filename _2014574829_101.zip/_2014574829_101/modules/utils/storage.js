!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

module.exports = {
    getItem: function(e) {
        try {
            return wx.getStorageSync(e);
        } catch (t) {
            console.log("缓存" + e + "获取失败" + t);
        }
    },
    setItem: function(e, t) {
        try {
            return wx.setStorageSync(e, t);
        } catch (t) {
            console.log("缓存" + e + "添加失败" + t);
        }
    },
    removeItem: function(e) {
        try {
            return wx.removeStorageSync(e);
        } catch (t) {
            console.log("缓存" + e + "删除失败" + t);
        }
    }
};