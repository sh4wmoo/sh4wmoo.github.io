!function(a) {
    a && a.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var a = "#ccc", o = "#ffbb1f";

module.exports = {
    statusConfig: function(e) {
        var t = 1 === e;
        return {
            1: {
                color: o,
                operations: {
                    isShowPayBtn: !0
                },
                map: !0,
                hasPayBtn: !0,
                hasCancelBtn: !0,
                hasBottomCallServer: !0
            },
            2: {
                color: o,
                operations: {
                    isShowCancleBtn: !0,
                    isShowTipFeeBtn: !0
                },
                map: !0,
                hasCancelBtn: !0,
                hasBottomCallServer: !0
            },
            3: {
                color: o,
                operations: {
                    isShowCancleBtn: !0,
                    isShowShareBtn: !!t
                },
                map: !0,
                hasCancelBtn: !0,
                hasShareBtn: !0,
                hasBottomCallServer: !0
            },
            4: {
                color: o,
                operations: {
                    isShowCancleBtn: !!t,
                    isShowShareBtn: !!t
                },
                map: !0,
                hasCancelBtn: !!t,
                hasShareBtn: !0,
                hasProductPayBtn: !t,
                hasProductPaidStatus: !t,
                hasBottomCallServer: !0
            },
            5: {
                color: a,
                operations: {
                    isShowCommentBtn: !0
                },
                hasCommentBtn: !0,
                hasBottomCallServer: !0,
                hasAgain: !0,
                hasInvoiceBtn: !0
            },
            6: {
                color: a,
                hasBottomCallServer: !0,
                hasAgain: !0
            },
            7: {
                color: o,
                hasCheckRefundStatus: !0,
                hasTopCallServer: !0,
                hasAgain: !0
            },
            8: {
                color: o,
                hasCheckRefundStatus: !0,
                hasTopCallServer: !0,
                hasAgain: !0
            },
            9: {
                color: o,
                hasCheckRefundStatus: !0,
                hasTopCallServer: !0,
                hasAgain: !0
            },
            10: {
                color: o,
                hasCheckRefundStatus: !0,
                hasTopCallServer: !0,
                hasAgain: !0
            },
            21: {
                color: o,
                operations: {
                    isShowCancleBtn: !0,
                    isShowTipFeeBtn: !0
                },
                map: !0,
                hasCancelBtn: !0,
                hasBottomCallServer: !0
            },
            31: {
                color: o,
                operations: {
                    isShowCancleBtn: !0,
                    isShowShareBtn: !!t
                },
                map: !0,
                hasCancelBtn: !0,
                hasShareBtn: !0,
                hasProductPayBtn: !t,
                hasProductPaidStatus: !t,
                hasBottomCallServer: !0
            },
            61: {
                color: o,
                hasTopCallServer: !0
            },
            62: {
                color: o,
                map: !0,
                hasCancelBtn: !0,
                hasShareBtn: !0,
                hasBottomCallServer: !0
            },
            64: {
                color: o,
                map: !0,
                hasCancelBtn: !0,
                hasTopCallServer: !0
            }
        };
    }
};