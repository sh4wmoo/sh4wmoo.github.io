function e(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.WaitQueue = void 0;

!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var n = function() {
    function e(e, n) {
        for (var t = 0; t < n.length; t++) {
            var o = n[t];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(n, t, o) {
        return t && e(n.prototype, t), o && e(n, o), n;
    };
}();

exports.WaitQueue = function() {
    function t() {
        e(this, t), this.queue = [];
    }
    return n(t, [ {
        key: "append",
        value: function(e) {
            e ? (e.id || console.error('property "id" is needed'), "function" == typeof e.onExecute ? "function" == typeof e.onRemove ? this.queue.find(function(n) {
                return n.id === e.id;
            }) ? console.error(e.id + " has already in queue") : (this.queue.push(e), 1 === this.queue.length && this.execute()) : console.error('property "onRemove" must be a function') : console.error('property "onExecute" must be a function')) : console.error("argument item is needed");
        }
    }, {
        key: "execute",
        value: function() {
            if (0 !== this.queue.length) {
                var e = this.queue[0];
                "function" == typeof e.onExecute && e.onExecute();
            }
        }
    }, {
        key: "remove",
        value: function(e) {
            var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            if (0 !== this.queue.length) if (this.queue[0].id === e) {
                var t = this.queue.shift();
                "function" == typeof t.onRemove && t.onRemove(n), this.execute();
            } else this.queue = this.queue.filter(function(t) {
                return t.id === e && "function" == typeof t.onRemove && t.onRemove(n), t.id !== e;
            });
        }
    } ]), t;
}();