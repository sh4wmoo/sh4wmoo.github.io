function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = e(require("../api/fetch.js")), u = e(require("../global.js"));

exports.default = (0, r.default)({
    url: u.default.feConfigPrefix + "/bm/config/1578972958212.js"
});