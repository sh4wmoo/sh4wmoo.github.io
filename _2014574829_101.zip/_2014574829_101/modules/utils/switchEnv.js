!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../api/route.js"), t = wx.getStorageSync("PAOTUI_ENV"), o = wx.getStorageSync("PAOTUI_HOST"), n = !0;

wx.startAccelerometer({
    success: function() {
        wx.onAccelerometerChange(function(t) {
            var o = t.x, a = t.y, s = t.z;
            n && (Math.abs(o) > 2 || Math.abs(a) > 2 || Math.abs(s) > 2) && "demo/pages/switchEnv/switchEnv" !== getCurrentPages().pop().route && (0, 
            e.navigateTo)({
                url: "/demo/pages/switchEnv/switchEnv"
            });
        });
    }
});

try {
    wx.onAppHide(function() {
        n = !1;
    }), wx.onAppShow(function() {
        n = !0;
    });
} catch (e) {
    console.log(e);
}

if (t && o) {
    wx.showToast({
        icon: "none",
        duration: 1e3,
        title: "当前环境" + t
    });
    var a = {
        dev: "paotui.banma.dev.sankuai.com",
        test: "paotui.banma.test.sankuai.com",
        st: "paotui.banma.st.meituan.com",
        online: "paotui.meituan.com"
    };
    a[t] = o, module.exports = {
        ENV: t,
        HOST: a
    };
} else module.exports = null;