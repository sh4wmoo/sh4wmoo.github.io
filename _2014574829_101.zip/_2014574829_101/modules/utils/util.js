function e(e, t) {
    "number" == typeof t && (t = new Date(t));
    var n = {
        "M+": t.getMonth() + 1,
        "d+": t.getDate(),
        "h+": t.getHours(),
        "m+": t.getMinutes(),
        "s+": t.getSeconds(),
        "q+": Math.floor((t.getMonth() + 3) / 3),
        S: t.getMilliseconds()
    };
    /(y+)/.test(e) && (e = e.replace(RegExp.$1, (t.getFullYear() + "").substr(4 - RegExp.$1.length)));
    for (var r in n) new RegExp("(" + r + ")").test(e) && (e = e.replace(RegExp.$1, 1 == RegExp.$1.length ? n[r] : ("00" + n[r]).substr(("" + n[r]).length)));
    return e;
}

function t(e) {
    return [ "日", "一", "二", "三", "四", "五", "六" ][new Date(e).getDay()];
}

function n(e) {
    return (e = e.toString())[1] ? e : "0" + e;
}

!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = function() {};

module.exports = {
    ptShowModal: function(e) {
        var t = e.title, n = void 0 === t ? "" : t, o = e.content, i = void 0 === o ? "" : o, u = e.confirm, a = void 0 === u ? r : u, c = e.cancel, s = void 0 === c ? r : c, l = e.showCancel, h = void 0 === l || l, f = e.cancelText, d = void 0 === f ? "取消" : f, m = e.cancelColor, g = void 0 === m ? "#000000" : m, p = e.confirmText, v = void 0 === p ? "确定" : p, b = e.confirmColor, M = void 0 === b ? "#ffb000" : b, D = e.fail, x = void 0 === D ? r : D, y = e.complete, N = void 0 === y ? r : y;
        wx.showModal({
            title: n,
            content: i,
            success: function(e) {
                e.confirm ? a() : s();
            },
            showCancel: h,
            cancelText: d,
            cancelColor: g,
            confirmText: v,
            confirmColor: M,
            fail: x,
            complete: N
        });
    },
    timeFormat: e,
    timeToDate: function(n, r) {
        r = Object.assign({
            needToday: !1,
            needWeekDay: !1
        }, r);
        var o = new Date(n), i = [ new Date() ], u = i[0], a = i[1], c = void 0 === a ? u.getFullYear() : a, s = i[2], l = void 0 === s ? u.getMonth() : s, h = i[3], f = void 0 === h ? u.getDate() : h, d = new Date(c, l, f, 0, 0, 0), m = +d, g = d.setDate(d.getDate() - 1), p = new Date(c, l, f, 23, 59, 59), v = +p, b = p.setDate(p.getDate() + 1);
        return n >= m && n <= v ? r.needToday ? "今天" + e("hh:mm", o) : e("hh:mm", o) : n > v && n <= b ? r.needWeekDay ? "明天（周" + t(o) + "）" + e("hh:mm", o) : "明天" + e("hh:mm", o) : n < m && n >= g ? r.needWeekDay ? "昨天（周" + t(o) + "）" + e("hh:mm", o) : "昨天" + e("hh:mm", o) : r.needWeekDay ? o.getMonth() + 1 + "月" + o.getDate() + "日（周" + t(o) + "） " + e("hh:mm", o) : o.getMonth() + 1 + "月" + o.getDate() + "日 " + e("hh:mm", o);
    },
    limitStr: function(e, t) {
        return "[object String]" !== Object.prototype.toString.call(e) ? "" : (t || (t = 4), 
        (e + "").length <= t ? e : e.substring(0, t - 1) + "...");
    },
    locFormat: function(e, t) {
        if (Number.isNaN(e) || null === e || "null" === e || void 0 === e || "undefined" === e) return 0;
        var n = Math.abs(e);
        return 0 <= n && n <= 180 ? Math.round(1e6 * e) : Math.round(e);
    },
    locIntToFloat: function(e) {
        return Number.isNaN(e) || null === e || "null" === e || void 0 === e || "undefined" === e || e < 0 ? 0 : Math.abs(e) > 1e3 ? e / 1e6 : e;
    },
    checkLoc: function(e) {
        return !(Number.isNaN(e) || null === e || "null" === e || void 0 === e || "undefined" === e || e < 0);
    },
    switchToHttps: function(e) {
        return e ? e.indexOf("https:") < 0 ? e.replace("http:", "https:") : e : "";
    },
    fixedNumber: function(e, t) {
        if (!isNaN(e)) {
            var n = e.toString(), r = n.indexOf(".");
            return -1 !== r ? parseFloat(n.substring(0, r + 1 + t)) : parseInt(e);
        }
    },
    escapePhoneNum: function(e) {
        return e.replace(/[^\d]/g, "").replace(/^(86|086)/, "").slice(0, 11);
    },
    compareVersion: function(e, t) {
        e = e.split("."), t = t.split(".");
        for (var n = Math.max(e.length, t.length); e.length < n; ) e.push("0");
        for (;t.length < n; ) t.push("0");
        for (var r = 0; r < n; r++) {
            var o = parseInt(e[r]), i = parseInt(t[r]);
            if (o > i) return 1;
            if (o < i) return -1;
        }
        return 0;
    },
    getCountDownFromSeconds: function(e) {
        if (e <= 0) return "00：00：00";
        var t = Math.floor(e / 3600), r = Math.floor((e - 3600 * t) / 60), o = e - 3600 * t - 60 * r;
        return {
            hours: n(t),
            minutes: n(r),
            seconds: n(o)
        };
    },
    jsonToUrl: function(e) {
        return Object.keys(e).map(function(t) {
            return encodeURIComponent(t) + "=" + encodeURIComponent(e[t]);
        }).join("&");
    },
    decodeOptions: function(e) {
        var t = {};
        return Object.keys(e).forEach(function(n) {
            var r = decodeURIComponent(e[n]);
            "false" === r && (r = !1), "true" === r && (r = !0), t[n] = r;
        }), t;
    },
    isPromise: function(e) {
        return !!e && "function" == typeof e.then;
    },
    mulDecimals: function(e, t) {
        var n = 0, r = e.toString(), o = t.toString();
        try {
            n += r.split(".")[1].length;
        } catch (e) {}
        try {
            n += o.split(".")[1].length;
        } catch (e) {}
        return Number(r.replace(".", "")) * Number(o.replace(".", "")) / Math.pow(10, n);
    },
    isInteger: function(e) {
        return /^[0-9]+$/.test(e);
    },
    filterLabel: function(e) {
        var t = e.match(/<font(.+)>([\s\S]*)<\/font>/);
        return t && t.length ? t[2] : e;
    },
    addMoney: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return (Math.round(100 * e) + Math.round(100 * t)) / 100;
    },
    hexToRgba: function(e) {
        if (e) {
            var t = [], n = [];
            if (4 === (e = e.replace(/#/, "")).length) {
                for (var r = [], o = 0; o < 4; o++) r.push(e.charAt(o) + e.charAt(o));
                e = r.join("");
            }
            for (var i = 0; i < 3; i++) t[i] = "0x" + e.substr(2 * i, 2), n.push(parseInt(Number(t[i])));
            return t[4] = "0x" + e.substr(6, 2), n.push(parseFloat(Number(t[4]) / 255)), "rgba(" + n.join(",") + ")";
        }
    },
    deepExtend: function e(t, n) {
        for (var r in n) n[r] && n[r].constructor && n[r].constructor === Object ? (t[r] = t[r] || {}, 
        e(t[r], n[r])) : t[r] = n[r];
        return t;
    },
    getSystemVersion: function(e) {
        return /\d+(\.\d+)*/.test(e.system) ? /\d+(\.\d+)*/.exec(e.system)[0] : "0";
    }
};