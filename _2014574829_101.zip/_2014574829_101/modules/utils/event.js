function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = e(require("../../libs/event.js"));

exports.default = new r.default();