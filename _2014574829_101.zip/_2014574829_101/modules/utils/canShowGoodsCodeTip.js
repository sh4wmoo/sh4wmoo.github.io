function e(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    var r = (0, t.getItem)("loginInfo").userId, o = (0, t.getItem)("goodsCodeSwitchTip");
    return o ? void 0 === o[r] && ((0, t.setItem)("goodsCodeSwitchTip", Object.assign(o, e({}, r, !0))), 
    !0) : ((0, t.setItem)("goodsCodeSwitchTip", e({}, r, !0)), !0);
};

!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var t = require("./storage");