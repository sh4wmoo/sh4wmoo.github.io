Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.reportDetailResourceError = exports.reportDetailAjaxError = exports.reportDetailJsError = exports.reportDetailError = void 0;

!function(r) {
    r && r.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = require("../api/cat.js"), e = exports.reportDetailError = function(e) {
    var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "jsError", i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "warn";
    if ("function" == typeof r.pushError) try {
        (0, r.pushError)({
            content: "" + JSON.stringify(o),
            category: t,
            sec_category: e,
            level: i
        }, !0);
    } catch (e) {
        try {
            (0, r.pushError)({
                content: "" + e.stack,
                category: "jsError",
                sec_category: "utils/reportDetailError.js函数出现异常",
                level: "error"
            });
        } catch (r) {}
    }
};

exports.reportDetailJsError = function(r, o) {
    var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "warn";
    e(r, o, "jsError", t);
}, exports.reportDetailAjaxError = function(r, o) {
    var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "warn";
    e(r, o, "ajaxError", t);
}, exports.reportDetailResourceError = function(r, o) {
    var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "warn";
    e(r, o, "resourceError", t);
};