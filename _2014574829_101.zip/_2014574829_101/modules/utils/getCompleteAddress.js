Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getCompleteAddress = void 0;

!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var e = require("./getCityAndDistrict.js");

exports.getCompleteAddress = function(t) {
    var r = t.addr_info, i = void 0 === r ? [] : r, s = t.address, d = void 0 === s ? "" : s, n = (0, 
    e.getCityAndDistrict)(i), o = n.cityName, u = n.district, l = !1, c = "";
    return o && d && d.includes(o) ? l = !0 : o && (c += o), !(!l && u && u.length > 0) || d && 0 !== d.length && d.includes(u) || (c += u), 
    d && d.length > 0 && (c += t.address), c;
};