Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.promisify = void 0;

!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

Promise.prototype.finally = function(e) {
    var n = this.constructor;
    return this.then(function(r) {
        return n.resolve(e(r)).then(function() {
            return r;
        });
    }, function(r) {
        return n.resolve(e(r)).then(function() {
            throw r;
        });
    });
};

var e = function() {};

exports.promisify = function(n) {
    var r = n.api, t = n.options, i = void 0 === t ? {} : t, o = n.before, u = void 0 === o ? e : o, s = n.after, c = void 0 === s ? e : s;
    return function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return u(), new Promise(function(n, t) {
            r(Object.assign({}, i, e, {
                success: function(e) {
                    return i.success ? i.success(e, n, t) : n(e), e;
                },
                fail: function(e) {
                    return i.fail ? i.fail(e, n, t) : t(e), e;
                }
            }));
        }).finally(function(n) {
            c(e, n);
        });
    };
};