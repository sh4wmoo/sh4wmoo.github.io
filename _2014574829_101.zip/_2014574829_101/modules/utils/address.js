!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var e = require("./util"), r = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var o = arguments[r];
        for (var a in o) Object.prototype.hasOwnProperty.call(o, a) && (e[a] = o[a]);
    }
    return e;
};

module.exports = {
    formatAddress: function(o) {
        var a = {
            id: o.id,
            name: o.name,
            phone: o.phone,
            lat: o.latitude,
            lng: o.longitude,
            gender: o.gender,
            address: o.address,
            houseNumber: o.houseNumber,
            disable: o.disable,
            disableReason: o.disableReason || "",
            invalid: o.invalid
        };
        if (o.addressTag) {
            var d = o.addressTag, n = d.backgroundColor, s = d.fontColor, i = d.borderColor;
            a.addressTag = r({}, o.addressTag, {
                backgroundColor: (0, e.hexToRgba)(n) || "rgba(255,222,24,25)",
                fontColor: (0, e.hexToRgba)(s) || "rgba(248,152,0,255)",
                borderColor: (0, e.hexToRgba)(i) || "rgba(255,222,24,127)"
            });
        }
        return a;
    }
};