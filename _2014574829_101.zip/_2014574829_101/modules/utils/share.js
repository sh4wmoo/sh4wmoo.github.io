!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../modules/api/urls.js"), r = require("../../modules/api/request.js");

module.exports = {
    getHomeShareData: function() {
        var t = this;
        (0, r.postInfo)(e.homeShareApi, {}).then(function(e) {
            t.setData({
                homeShareCfg: {
                    shareTitle: e.data.shareTitle,
                    shareIcon: e.data.shareIcon,
                    shareContent: e.data.shareContent
                }
            });
        }).catch(function() {});
    },
    getRiderShareData: function() {
        var t = this;
        (0, r.postInfo)(e.riderShareApi, {}).then(function(e) {
            0 === e.code && t.setData({
                riderShareCfg: {
                    shareTitle: e.data.shareTitle,
                    shareIcon: e.data.shareIcon,
                    shareContent: e.data.shareContent
                }
            });
        }).catch(function() {});
    },
    shareApp: function(e) {
        if ("button" === e.type) {
            var r = this.data.riderShareCfg;
            return {
                title: r && r.shareTitle || "我正用美团跑腿送东西，点击查看骑手实时位置",
                path: "/pages/orderProgress/orderProgress?channel=wx_miniProgramsShare&orderViewId=" + e.orderViewId + "&sig=" + e.sig,
                imageUrl: r && r.shareIcon || "https://vfile.meituan.net/paotui/jecxy83crpb9.png"
            };
        }
        var t = this.data.homeShareCfg;
        return {
            title: t && t.shareTitle || "美团跑腿，同城取送1小时达",
            path: "/pages/index/index?channel=wx_miniProgramsShare",
            imageUrl: t && t.shareIcon || "https://vfile.meituan.net/paotui/jesbouin1b57b9.png"
        };
    },
    shareHome: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return {
            title: e.shareTitle || "美团跑腿，同城取送1小时达",
            path: "/pages/index/index?channel=wx_miniProgramsShare",
            imageUrl: e.shareIcon || "https://vfile.meituan.net/paotui/jesbouin1b57b9.png"
        };
    },
    shareRider: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return {
            title: e.shareTitle || "我正用美团跑腿送东西，点击查看骑手实时位置",
            path: "/pages/orderProgress/orderProgress?channel=wx_miniProgramsShare&orderViewId=" + e.orderViewId + "&sig=" + e.sig,
            imageUrl: e.shareIcon || "https://vfile.meituan.net/paotui/jecxy83crpb9.png"
        };
    },
    shareInviteCoupon: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return {
            title: e.shareTitle || "",
            path: "/marketing/pages/couponInvitee/couponInvitee?shareKey=" + e.shareKey,
            imageUrl: e.shareIcon || "https://vfile.meituan.net/paotui/jiec9ko21mj9k9.png"
        };
    }
};