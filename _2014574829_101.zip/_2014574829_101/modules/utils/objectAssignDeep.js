var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
    return typeof o;
} : function(o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
}, t = (function(o) {
    o && o.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js")), "function" == typeof Symbol && "symbol" === o(Symbol.iterator) ? function(t) {
    return void 0 === t ? "undefined" : o(t);
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : void 0 === t ? "undefined" : o(t);
});

module.exports = function(o) {
    for (var e = arguments.length, r = Array(e > 1 ? e - 1 : 0), n = 1; n < e; n++) r[n - 1] = arguments[n];
    for (var u = r.length, y = 0; y < u; ++y) {
        var f = r[y];
        if (f && "object" === (void 0 === f ? "undefined" : t(f))) for (var i = Object.keys(f), l = i.length - 1; l > -1; --l) {
            var m = i[l];
            o[m] = f[m];
        }
    }
    return o;
};