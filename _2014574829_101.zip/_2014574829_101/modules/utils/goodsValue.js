Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.formatGoodsValue = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = r(e, 2), n = t[0], o = void 0 === n ? 0 : n, i = t[1], u = void 0 === i ? 0 : i, a = "";
    return 0 === o ? 0 !== u && -1 !== u && (a = u + "元以下") : a = -1 === u ? o + "元以上" : o + "-" + u + "元", 
    a;
}, exports.validateGoodsValue = function(r, e) {
    return !(void 0 === r || void 0 === e || null === r || null === e || isNaN(r) || isNaN(e) || (r = Number(r), 
    e = Number(e), r < 0 || 0 === r && (0 === e || -1 === e)));
};

!function(r) {
    r && r.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = function() {
    function r(r, e) {
        var t = [], n = !0, o = !1, i = void 0;
        try {
            for (var u, a = r[Symbol.iterator](); !(n = (u = a.next()).done) && (t.push(u.value), 
            !e || t.length !== e); n = !0) ;
        } catch (r) {
            o = !0, i = r;
        } finally {
            try {
                !n && a.return && a.return();
            } finally {
                if (o) throw i;
            }
        }
        return t;
    }
    return function(e, t) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return r(e, t);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}();