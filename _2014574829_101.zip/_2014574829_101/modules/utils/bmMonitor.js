function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = require("user.js"), u = e(require("../../libs/bmMonitor")), n = (0, r.getUserInfo)();

u.default.init({
    appName: "banma_fe_runner_wx",
    projectName: "banma_fe_runner_wx",
    userId: String(n && n.userId) || "",
    channel: "wx_miniProgramsDefault"
}), module.exports = u.default;