function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.subscribeOnInvoice = exports.subscribeOnCancel = exports.subscribeOnPay = void 0;

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = require("./abtest.js"), i = require("../api/wx.js"), s = require("./util.js"), n = e(require("../global.js")), o = require("../api/request.js"), t = require("../api/urls"), u = (0, 
s.compareVersion)(n.default.systemInfo.SDKVersion, "2.8.2") >= 0, a = n.default.isAndroid ? (0, 
s.compareVersion)(n.default.systemInfo.version, "7.0.7") >= 0 : n.default.isIOS ? (0, 
s.compareVersion)(n.default.systemInfo.version, "7.0.6") >= 0 : void 0, c = {
    deliveryOrder: [ "iHVWJDx_K4j_WVkuDIOxFL_e4E00Nhh8fIGBh4ZdoME", "tNBKeExi8HAO8Us67O_3maD7XBaU7tBaSbjmayQLbGo" ],
    buyOrder: [ "tNBKeExi8HAO8Us67O_3mYPX42uzblajqSgeDEoJLec", "iHVWJDx_K4j_WVkuDIOxFPGhOb844USq_BeQi_fOQfw" ],
    deliveryCancel: [ "ipyfkxDM2Ir6fbdTezLapUA4DjL8zaLlhWg90DVqwIE", "n1c6G1G8UAdoSf2OQx7lEnynEx3SyA5syVkiX7YeUGI" ],
    buyCancel: [ "ipyfkxDM2Ir6fbdTezLapY6cTxneIoD8mWHc0bD_peU", "n1c6G1G8UAdoSf2OQx7lEnynEx3SyA5syVkiX7YeUGI" ],
    invoice: [ "N4HcHtG-2zrMITQX7jqo9KIBC34AmQiIBG2JM89m4tI" ]
};

r.configPromise.then(function() {
    r.globalConfig.wxPushTemplate && Object.keys(r.globalConfig.wxPushTemplate).forEach(function(e) {
        c[e] = r.globalConfig.wxPushTemplate[e];
    });
});

var l = function(e) {
    var r = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
    return u ? function(s) {
        var n = [];
        if (a) n = c[e]; else {
            if ("deliveryOrder" === e) return Promise.resolve();
            n = c[e].slice(0, 1);
        }
        return (0, i.requestSubscribeMessage)({
            tmplIds: n
        }).then(function(e) {
            var i = Object.keys(e).filter(function(r) {
                return "errMsg" !== r && "accept" === e[r];
            });
            r && i.length > 0 && (0, o.postInfo)(t.savePushTemplateApi, Object.assign({
                templateIds: i.join(",")
            }, s));
        }).catch(function(e) {});
    } : function() {
        return Promise.resolve();
    };
}, d = l("deliveryOrder"), f = l("buyOrder"), b = l("deliveryCancel"), p = l("buyCancel");

exports.subscribeOnPay = function(e) {
    var r = e.businessType, i = e.orderViewId;
    return 1 === r ? d({
        orderId: i
    }) : 2 === r ? f({
        orderId: i
    }) : void 0;
}, exports.subscribeOnCancel = function(e) {
    var r = e.businessType, i = e.orderViewId;
    return 1 === r ? b({
        orderId: i
    }) : 2 === r ? p({
        orderId: i
    }) : void 0;
}, exports.subscribeOnInvoice = l("invoice", !1);