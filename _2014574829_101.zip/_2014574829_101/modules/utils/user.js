Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getWxUserInfo = exports.getUserInfo = void 0;

!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var e = require("./storage.js");

exports.getUserInfo = function() {
    return (0, e.getItem)("loginInfo");
}, exports.getWxUserInfo = function() {
    return (0, e.getItem)("wxUserInfo");
};