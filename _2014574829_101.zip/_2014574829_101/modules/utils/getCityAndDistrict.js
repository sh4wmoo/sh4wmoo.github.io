Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getCityAndDistrict = void 0;

(function(e) {
    e && e.__esModule;
})(require("../../libs/regenerator-runtime/runtime-module.js")), exports.getCityAndDistrict = function(e) {
    for (var t = e.length, r = "", i = !0, s = "", n = ""; t; ) {
        var o = e[t - 1], a = o.admin_level, c = void 0 === a ? "" : a, d = o.name, u = void 0 === d ? "" : d;
        switch (c) {
          case "4":
            s = u || "";
            break;

          case "5":
            r = u || "", i = !1;
            break;

          case "6":
            n = u || "";
        }
        t--;
    }
    return i && (r = s), {
        cityName: r,
        district: n
    };
};