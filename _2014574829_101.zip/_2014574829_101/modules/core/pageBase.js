Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(t) {
    (0, e.default)(t);
};

var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../page.js"));