function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    var e;
    return (e = i).send.apply(e, arguments);
};

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = e(require("../../libs/brandy-ws/es5/lib/proxy.js")), t = require("./metrics.js"), o = require("./cat.js"), s = require("../utils/reportDetailError"), i = null;

!function() {
    var e = Date.now();
    (i = new r.default("paotui_wxapp", {
        isNeedWmParams: 0,
        request: t.request,
        isFilterParam: !1
    })).onOpen(function() {
        (0, o.addApi)({
            name: "长连接建立",
            networkCode: 200,
            statusCode: 0,
            responseTime: Date.now() - e
        });
    }), i.onClose(function(e) {
        (0, s.reportDetailError)("socket close", e);
    }), i.onError(function(r) {
        r && "initError" === r.type && (0, o.addApi)({
            name: "长连接建立",
            networkCode: 500,
            statusCode: -1,
            responseTime: Date.now() - e
        }), r ? r.message ? (0, s.reportDetailError)("socket error：" + r.message, r) : r.description ? (0, 
        s.reportDetailError)("socket error：" + r.description, r) : (0, s.reportDetailError)("socket error", r) : (0, 
        s.reportDetailError)("socket error", r);
    });
}();