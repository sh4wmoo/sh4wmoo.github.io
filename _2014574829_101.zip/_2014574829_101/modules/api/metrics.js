!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../libs/metrics-wxapp.js"), t = require("./cat.js");

module.exports = {
    app: e.app,
    page: e.page,
    init: function(e, t, r) {
        var a = "online" === r ? "5cf4d4321c9d443137a4abb5" : "5cf4e9371c9d443143c91a53", i = "online" === r ? {
            app: .1,
            pageShow: .1,
            pageReady: .1,
            pageSize: .1,
            customSpeed: .1,
            request: .1,
            fmp: .1,
            data: .1,
            rate: .1,
            socket: .1
        } : {
            app: .5,
            pageShow: .5,
            pageReady: .5,
            pageSize: .5,
            customSpeed: .5,
            request: .5,
            fmp: .5,
            data: .5,
            rate: .5,
            socket: .5
        };
        e.initMetrics({
            token: a,
            version: t,
            sample: i
        });
    },
    metrics: e.metrics,
    startMetricsPagePoint: function(e, t, r) {
        try {
            e.startMetricsPoint(t, r);
        } catch (e) {
            return null;
        }
    },
    request: function(r) {
        return (0, e.request)(r, t.request);
    }
};