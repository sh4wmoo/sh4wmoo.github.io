function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var t = require("./metrics.js"), r = require("../utils/wxPromise.js"), o = require("../utils/reportDetailError.js"), i = e(require("../utils/bmMonitor.js")), n = e(require("../global.js")), a = function(e) {
    return "string" == typeof e;
}, s = {};

[ {
    key: "getLocation",
    options: {
        type: "gcj02"
    }
}, {
    key: "login",
    options: {
        timeout: 3e3
    }
}, "getSystemInfo", "getSetting", "openSetting", "saveImageToPhotosAlbum", "previewImage", "getUserInfo", "getFileInfo", "getClipboardData", "makePhoneCall", "downloadFile", "getStorage", "setStorage", "requestPayment", "login", "setClipboardData", "request", "requestSubscribeMessage" ].forEach(function(e) {
    var t = null, n = {};
    a(e) ? t = e : (t = e.key, n = e.options), s[t] = (0, r.promisify)({
        api: wx[t],
        options: Object.assign(n, {
            fail: function(e, r, i) {
                i(), (0, o.reportDetailJsError)("wxAPI " + t + " error", e);
            }
        }),
        after: function(e, r) {
            i.default.log({
                logType: 5105,
                summary: "调用wxAPI " + t,
                description: {
                    params: e,
                    result: r
                }
            });
        }
    });
});

var u = (0, r.promisify)({
    api: t.request,
    options: {
        header: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        },
        isRequest: !0,
        success: function(e, t, r) {
            e.data ? t({
                data: e.data
            }) : r(e);
        },
        before: function() {
            wx.showNavigationBarLoading();
        },
        after: function() {
            wx.hideNavigationBarLoading();
        }
    },
    key: "request"
});

module.exports = Object.assign({}, s, {
    getSystemInfoSync: function() {
        var e = wx.getSystemInfoSync();
        return {
            wm_dtype: e.model,
            wm_dversion: e.system,
            wm_appversion: n.default.version
        };
    },
    request: u,
    getUpdateManager: function() {
        return wx.getUpdateManager();
    }
});