function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function r(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, t) {
            function n(u, o) {
                try {
                    var a = r[u](o), i = a.value;
                } catch (e) {
                    return void t(e);
                }
                if (!a.done) return Promise.resolve(i).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(i);
            }
            return n("next");
        });
    };
}

function t(e, t) {
    var u = this, s = o.default;
    return function() {
        var o = r(n.default.mark(function r() {
            var o, f, d = arguments;
            return n.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (null === (o = s.loginPromise || null)) {
                        r.next = 3;
                        break;
                    }
                    return r.abrupt("return", o);

                  case 3:
                    return s.loginPromise = e.apply(void 0, d), f = void 0, r.prev = 5, r.next = 8, 
                    s.loginPromise;

                  case 8:
                    f = r.sent, s.loginPromise = null, r.next = 18;
                    break;

                  case 12:
                    return r.prev = 12, r.t0 = r.catch(5), s.loginPromise = null, p.default.log({
                        logType: 5104,
                        summary: t,
                        tag1: "fail",
                        description: f
                    }), (0, a.reportDetailJsError)(t + " error", r.t0), r.abrupt("return", !1);

                  case 18:
                    if (!f || f.error) {
                        r.next = 29;
                        break;
                    }
                    return (0, i.setItem)("loginInfo", f), f.wxUserInfo && (0, i.setItem)("wxUserInfo", f.wxUserInfo), 
                    g(f).catch(function(e) {}), c.default.setLoginInfo(f), (0, l.setCatLoginInfo)(f), 
                    p.default.updateBaseParams({
                        userId: f.userId
                    }), p.default.log({
                        logType: 5104,
                        summary: t,
                        tag1: "success",
                        description: f
                    }), r.abrupt("return", f);

                  case 29:
                    return p.default.log({
                        logType: 5104,
                        summary: t,
                        tag1: "fail",
                        description: f
                    }), (0, a.reportDetailJsError)(t + " fail", f), r.abrupt("return", !1);

                  case 32:
                  case "end":
                    return r.stop();
                }
            }, r, u, [ [ 5, 12 ] ]);
        }));
        return function() {
            return o.apply(this, arguments);
        };
    }();
}

var n = e(require("../../libs/regenerator-runtime/runtime-module.js")), u = require("../utils/user.js"), o = e(require("../global.js")), a = require("../utils/reportDetailError"), i = require("../utils/storage"), s = require("../../modules/api/urls"), c = e(require("./lx.js")), f = require("./wx.js"), l = require("../../modules/api/cat.js"), p = e(require("../../modules/utils/bmMonitor.js")), d = require("../../pages/login/index"), g = function() {
    var e = r(n.default.mark(function e(r) {
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", (0, f.request)({
                    url: s.updateUserInfoApi,
                    method: "POST",
                    data: {
                        userid: r.userId,
                        token: r.token,
                        uuid: r.uuid,
                        wm_uuid: r.uuid,
                        openId: r.openId,
                        wm_ctype: o.default.clientType,
                        nickName: r.wxUserInfo ? r.wxUserInfo.nickName : "",
                        wechatAvatarUrl: r.wxUserInfo ? r.wxUserInfo.avatarUrl ? r.wxUserInfo.avatarUrl : "https://p1.meituan.net/paotui/jradumhwydh.png" : ""
                    }
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, e, void 0);
    }));
    return function(r) {
        return e.apply(this, arguments);
    };
}(), I = t(function() {
    var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).force;
    return void 0 !== e && e && h(), m() ? (0, u.getUserInfo)() : d.wxLogin({
        slient: !0,
        bind: !1
    });
}, "silent"), v = t(function() {
    var e = r(n.default.mark(function e() {
        var r, t = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).force, o = void 0 !== t && t;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (o && h(), !m() || !x()) {
                    e.next = 3;
                    break;
                }
                return e.abrupt("return", (0, u.getUserInfo)());

              case 3:
                return r = !1, e.prev = 4, e.next = 7, d.wxLogin({
                    slient: !1,
                    bind: !1
                });

              case 7:
                r = e.sent, e.next = 13;
                break;

              case 10:
                e.prev = 10, e.t0 = e.catch(4), console.log(e.t0);

              case 13:
                if (!r || r.error) {
                    e.next = 15;
                    break;
                }
                return e.abrupt("return", r);

              case 15:
                return e.prev = 15, e.next = 18, d.login();

              case 18:
                r = e.sent, e.next = 24;
                break;

              case 21:
                e.prev = 21, e.t1 = e.catch(15), console.log(e.t1);

              case 24:
                return e.abrupt("return", r);

              case 25:
              case "end":
                return e.stop();
            }
        }, e, void 0, [ [ 4, 10 ], [ 15, 21 ] ]);
    }));
    return function() {
        return e.apply(this, arguments);
    };
}(), "ptLogin"), m = function() {
    return !!(0, u.getUserInfo)();
}, x = function() {
    return !!(0, i.getItem)("wxUserInfo");
}, h = function() {
    (0, i.removeItem)("loginInfo"), (0, i.removeItem)("wxUserInfo");
}, w = function() {
    var e = r(n.default.mark(function e() {
        var r;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!(r = (0, i.getItem)("sdkLoginInfo")) || !r.openId) {
                    e.next = 5;
                    break;
                }
                return e.abrupt("return", r);

              case 5:
                return e.prev = 5, e.next = 8, d.wxLogin({
                    bind: !1
                });

              case 8:
                return r = e.sent, d.destroySession(), e.abrupt("return", r);

              case 13:
                return e.prev = 13, e.t0 = e.catch(5), e.abrupt("return", {});

              case 16:
              case "end":
                return e.stop();
            }
        }, e, void 0, [ [ 5, 13 ] ]);
    }));
    return function() {
        return e.apply(this, arguments);
    };
}();

m() || w().then(function(e) {
    c.default.setLoginInfo(e), (0, l.setCatLoginInfo)(e);
}).catch(function() {}), module.exports = {
    silentLogin: I,
    ptLogin: v,
    checkIsLogin: m,
    checkIsAuthorize: x,
    logout: function() {
        var e = (0, u.getUserInfo)();
        if (e) return d.logout(e.token).then(function() {
            h();
        });
    },
    clearLoginInfo: h,
    updateUserInfo: g,
    updateWxUserInfo: function(e) {
        (0, i.setItem)("wxUserInfo", e), d.updateWxUserInfo();
        var r = (0, u.getUserInfo)();
        r.wxUserInfo = e, g(r).catch(function(e) {
            console.log(e);
        });
    },
    getOpenIdSilent: w
};