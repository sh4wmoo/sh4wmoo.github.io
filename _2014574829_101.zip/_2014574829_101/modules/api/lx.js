function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return {
        abtest: [ "ab_wx_170_authorizepage_no_" + r.globalConfig.abtest_authorization_page, "ab_wx_180_groupcoupon_no_" + r.globalConfig.testIdMapping.wx_groupcoupon, "ab_wx_180_authorize_no_" + r.globalConfig.testIdMapping.wx_authorize, "ab_wx_190_groupcoupon_UI" + r.globalConfig.testIdMapping.ab_wx_190_groupcoupon_UI, "addresspage_autorecognition" + r.globalConfig.testIdMapping.addresspage_autorecognition, "recognition_address_pic" + r.globalConfig.testIdMapping.recognition_address_pic, "recognition_address_clipboard" + r.globalConfig.testIdMapping.recognition_address_clipboard, "recognition_address_gif" + r.globalConfig.testIdMapping.recognition_address_gif, "address_recommend" + r.globalConfig.testIdMapping.address_recommend, "modify_order" + r.globalConfig.testIdMapping.modify_order, "certification_test" + r.globalConfig.testIdMapping.certification_test, "wx_search_aoi" + r.globalConfig.testIdMapping.wx_search_aoi, "order_share" + r.globalConfig.testIdMapping.order_share, "goods_code_switch" + r.globalConfig.testIdMapping.goods_code_switch, "miniprogram_websocket" + r.globalConfig.testIdMapping.miniprogram_websocket, "processing_order_entry" + r.globalConfig.testIdMapping.processing_order_entry, "miniProgram_backFromPay" + r.globalConfig.testIdMapping.miniProgram_backFromPay, "urge_grab" + r.globalConfig.testIdMapping.urge_grab ].join(","),
        custom: Object.assign({}, {
            channel: s.default.channel,
            channel_activity_id: s.default.channel_activity_id,
            legwork_type: "1"
        }, e || {})
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var i = require("../utils/user.js"), o = e(require("../../libs/analytics-v1.7.0.js")), n = require("../utils/storage.js"), a = e(require("../utils/bmMonitor.js")), r = require("../utils/abtest.js"), s = e(require("../global.js")), d = {};

d.init = function(e, t) {
    o.default.init(e, t);
}, d.pv = function(e, i) {
    o.default.pageView(e, t(i)), a.default.log({
        logType: 5101,
        summary: e,
        description: i
    });
}, d.view = function(e, i) {
    o.default.moduleView(e, t(i));
}, d.click = function(e, i) {
    o.default.moduleClick(e, t(i)), a.default.log({
        logType: 5103,
        summary: e,
        description: i
    });
}, d.order = function(e, i, n) {
    o.default.order(e, i, t(n));
}, d.set = d.setEnv = function(e, t) {
    o.default.set(e, t);
}, d.setPaotuiEnv = function() {
    d.setLocateCity(), d.setCity(), d.setLoginInfo();
}, d.setLocateCity = function(e) {
    e || (e = (0, n.getItem)("locate_city_id") || "-1"), o.default.set("locate_city_id", e), 
    (0, n.setItem)("locate_city_id", e);
}, d.setCity = function(e) {
    e || (e = (0, n.getItem)("cityid") || "-1"), o.default.set("cityid", e), (0, n.setItem)("cityid", e);
}, d.setLoginInfo = function(e) {
    e || (e = (0, i.getUserInfo)() || {
        userId: "",
        openId: ""
    }), o.default.set("wxid", e.openId), o.default.set("uid", e.userId);
}, d.start = function() {
    o.default.start();
}, d.quit = function() {
    o.default.quit();
}, d.validate = function() {
    return o.default.turnOnValidate();
}, exports.default = d;