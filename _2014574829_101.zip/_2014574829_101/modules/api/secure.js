function o(o) {
    return o && o.__esModule ? o : {
        default: o
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
    return typeof o;
} : function(o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
}, n = (o(require("../../libs/regenerator-runtime/runtime-module.js")), o(require("../utils/bmMonitor")), 
"function" == typeof Symbol && "symbol" === t(Symbol.iterator) ? function(o) {
    return void 0 === o ? "undefined" : t(o);
} : function(o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : void 0 === o ? "undefined" : t(o);
}), e = require("../../libs/pako.min.js"), r = "function" == typeof Symbol && "symbol" == n(Symbol.iterator) ? function(o) {
    return void 0 === o ? "undefined" : n(o);
} : function(o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : void 0 === o ? "undefined" : n(o);
}, u = "function" == typeof Symbol && "symbol" == r(Symbol.iterator) ? function(o) {
    return void 0 === o ? "undefined" : r(o);
} : function(o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : void 0 === o ? "undefined" : r(o);
}, i = function(o) {
    for (var t = e.deflate(JSON.stringify(o), {
        to: "array"
    }), n = t, r = 0; r < 32; r++) n[r] = r < 16 ? 2 ^ n[r] : 6 ^ n[r];
    return wx.arrayBufferToBase64(t);
}, f = function(o) {
    var t = [];
    return Object.keys(o).sort().forEach(function(n) {
        var e = o[n];
        "_token" !== n && "" !== e && void 0 !== e && null !== e && (e && "object" === (void 0 === e ? "undefined" : u(e)) && (e = JSON.stringify(e)), 
        t.push(n + "=" + encodeURIComponent(e)));
    }), i(t.join("&"));
};

exports.default = function(o) {
    var t = {
        rId: 100016,
        ts: 1527496130523,
        cts: 1527496147694,
        brVD: [ 360, 465 ],
        brR: [ [ 1080, 1395 ], [ 1080, 1395 ], 24, 24 ],
        bI: [ "pages/restaurant/restaurant", "pages/index/index" ],
        mT: [],
        kT: [],
        aT: [ "190,461,view" ],
        tT: [],
        sign: f(o)
    };
    return f(t);
};