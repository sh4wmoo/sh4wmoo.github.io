Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.checkIsFirstPage = exports.navigateBackTo = exports.navigateBack = exports.redirectTo = exports.reLaunch = exports.navigateTo = void 0;

(function(e) {
    e && e.__esModule;
})(require("../../libs/regenerator-runtime/runtime-module.js")), exports.navigateTo = function(e) {
    return wx.navigateTo(e);
}, exports.reLaunch = function(e) {
    return wx.reLaunch(e);
}, exports.redirectTo = function(e) {
    return wx.redirectTo(e);
};

var e = exports.navigateBack = function(e) {
    return wx.navigateBack(e);
};

exports.navigateBackTo = function(t) {
    for (var r = getCurrentPages(), n = 0; n < r.length; n++) if (r[n].route === t) return void e({
        delta: r.length - n - 1
    });
    e({
        delta: r.length - 1
    });
}, exports.checkIsFirstPage = function() {
    return 1 === getCurrentPages().length;
};