function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = require("../utils/user.js"), o = require("../../libs/owl/index.js"), s = e(require("../../modules/utils/debounce.js")), t = e(require("../utils/bmMonitor.js")), a = e(require("../global.js")), n = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var o = arguments[r];
        for (var s in o) Object.prototype.hasOwnProperty.call(o, s) && (e[s] = o[s]);
    }
    return e;
}, d = {}, i = void 0, u = {
    "pages/index/index": 1,
    "address/pages/addrEdit/addrEdit": 1,
    "address/pages/addrList/addrList": 1,
    "address/pages/addressSelect/addressSelect": 1,
    "address/pages/locSearch/locSearch": 1,
    "pages/orderList/orderList": 1,
    "order/pages/orderConfirm/orderConfirm": 1,
    "order/pages/orderBuy/orderBuy": 1,
    "pages/goodsInfo/goodsInfo": 1,
    "pages/orderDetail/orderDetail": 1,
    "pages/couponList/couponList": 1
}, l = (0, s.default)(function() {
    i.report(), i.clearMetric();
}, 1e3, {
    leading: !1,
    trailing: !0
}), p = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
    "string" == typeof e && (i.setTags({
        channel: a.default.channel,
        os: a.default.systemInfo.platform,
        version: a.default.version
    }), i.setMetric(e, r), l());
};

module.exports = {
    request: o.request,
    app: o.app,
    page: o.page,
    setCatLoginInfo: function(e) {
        o.owl.cfgManager.update("unionId", e.openId), d = n({}, e);
    },
    start: function(e, s) {
        var a = (0, r.getUserInfo)(), n = "test" === s || "dev" === s, l = {
            project: "banma-fe-runner-wx",
            devMode: n,
            wxAppVersion: e,
            resource: {
                sample: n ? 1 : .2,
                errSample: n ? 1 : .2
            },
            onErrorPush: function(e) {
                if ("error" === e.level && "jsError" === e.category) {
                    var r = getCurrentPages().slice(-1)[0].route;
                    r && u[r] && p("important_page_error");
                }
                return e.updateTags({
                    userId: d.userId,
                    token: d.token,
                    uuid: d.uuid,
                    openId: d.openId
                }), t.default.log({
                    logType: 5106,
                    summary: e.sec_category.slice(0, 512),
                    description: e
                }), e;
            }
        };
        a && a.openId && Object.assign(l, {
            unionId: a.openId
        }), o.owl.start(l), i = o.owl.newMetric();
    },
    pushError: function(e) {
        o.owl.error.pushError(e, !0);
    },
    reportMetric: p,
    addApi: function(e) {
        o.owl.resource.addApi(e);
    }
};