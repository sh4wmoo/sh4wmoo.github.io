function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function a(o, n) {
                try {
                    var u = t[o](n), s = u.value;
                } catch (e) {
                    return void r(e);
                }
                if (!u.done) return Promise.resolve(s).then(function(e) {
                    a("next", e);
                }, function(e) {
                    a("throw", e);
                });
                e(s);
            }
            return a("next");
        });
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.downloadFile = exports.updateUserInfo = exports.postInfo = exports.getInfo = exports.ptfetch = exports.getCommonInfo = exports.mafReportError = void 0;

var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, a = e(require("../../libs/regenerator-runtime/runtime-module.js")), o = require("../utils/user.js"), n = require("../../libs/qs"), u = require("./metrics.js"), s = require("../utils/util.js"), i = require("./urls.js"), c = e(require("./secure.js")), d = require("../utils/reportDetailError"), l = require("./wx.js"), f = e(require("../utils/bmMonitor.js")), p = e(require("../global.js")), m = require("../utils/uuid.js"), g = require("../utils/abtest.js"), h = e(require("./websocket.js")), y = require("./cat.js"), v = "function" == typeof Symbol && "symbol" === r(Symbol.iterator) ? function(e) {
    return void 0 === e ? "undefined" : r(e);
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : r(e);
}, w = require("../utils/storage").getItem, x = require("./login"), q = x.ptLogin, b = x.clearLoginInfo, j = x.silentLogin, k = (0, 
require("./wx").getSystemInfoSync)(), C = function(e, t) {
    return e.data && 0 === e.data.code ? (f.default.log({
        logType: 5102,
        summary: t.url,
        tag1: "success",
        description: {
            req: t,
            res: I(e.data.data)
        }
    }), {
        code: 0,
        log: e.data.message,
        name: "请求成功"
    }) : e.data && e.data.code && 0 !== e.data.code ? (f.default.log({
        logType: 5102,
        summary: t.url,
        tag1: "ajaxError",
        description: {
            req: t,
            res: e
        }
    }), (0, d.reportDetailAjaxError)("ajaxError " + t.url, {
        req: t,
        res: e.data
    }), {
        code: e.data.code,
        log: e.data.message,
        name: "业务错误"
    }) : e.data ? void 0 : (f.default.log({
        logType: 5102,
        summary: t.url,
        tag1: "httpError",
        description: {
            req: t,
            res: e
        }
    }), {
        code: -1,
        log: String(e),
        name: "ajax错误"
    });
}, _ = (exports.mafReportError = function(e, t) {
    return e && e.data && void 0 !== e.data.status ? 200 === e.data.status ? (f.default.log({
        logType: 5102,
        summary: t.url,
        tag1: "success",
        description: {
            req: t,
            res: I(e.data.result)
        }
    }), {
        code: 0,
        log: e.data.msg,
        name: "请求成功"
    }) : (f.default.log({
        logType: 5102,
        summary: t.url,
        tag1: "ajaxError",
        description: {
            req: t,
            res: e
        }
    }), (0, d.reportDetailAjaxError)("ajaxError " + t.url, {
        req: t,
        res: e.data
    }), {
        code: e.data.status,
        log: e.data.msg,
        name: "业务错误"
    }) : (f.default.log({
        logType: 5102,
        summary: t.url,
        tag1: "httpError",
        description: {
            req: t,
            res: e
        }
    }), {
        code: -1,
        log: String(e),
        name: "ajax错误"
    });
}, function(e, t, r) {
    e && void 0 !== e.code && (0 === e.code ? (f.default.log({
        logType: 5102,
        summary: "socket_" + t.url,
        tag1: "success",
        description: {
            req: t,
            res: I(e.data)
        }
    }), (0, y.addApi)({
        name: "socket_" + t.url,
        networkCode: 200,
        statusCode: 0,
        responseTime: r
    })) : (f.default.log({
        logType: 5102,
        summary: "socket_" + t.url,
        tag1: "ajaxError",
        description: {
            req: t,
            res: e
        }
    }), (0, d.reportDetailAjaxError)("ajaxError socket_" + t.url, {
        req: t,
        res: e
    }), (0, y.addApi)({
        name: "socket_" + t.url,
        networkCode: 200,
        statusCode: e.code,
        responseTime: r
    })));
}), L = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments[1], r = arguments[2];
    f.default.log({
        logType: 5102,
        summary: "socket_" + t.url,
        tag1: "httpError",
        description: {
            req: t,
            res: e
        }
    }), (0, y.addApi)({
        name: "socket_" + t.url,
        networkCode: e.statusCode || 500,
        statusCode: e.code || -1,
        responseTime: r
    });
}, D = exports.getCommonInfo = function(e) {
    var t = (0, o.getUserInfo)(), r = {
        actual_latitude: 0,
        actual_longitude: 0
    };
    p.default.actualLocation && (r = {
        actual_latitude: p.default.actualLocation.lat,
        actual_longitude: p.default.actualLocation.lng
    });
    var a = w("actPoint") || {};
    if (!(0, s.checkLoc)(a.lng) || !(0, s.checkLoc)(a.lat)) try {
        throw new Error();
    } catch (t) {
        (0, d.reportDetailError)("经纬度错误：getCommonInfo", {
            actPoint: a,
            stack: t.stack,
            url: e,
            channel: p.default.channel
        });
    }
    return Object.assign({}, k, {
        userid: t.userId,
        token: t.token,
        uuid: m.uuid,
        wm_uuid: m.uuid,
        channel: p.default.channel,
        channel_activity_id: p.default.channel_activity_id,
        wm_ctype: p.default.clientType,
        longitude: (0, s.locFormat)(a.lng, !0),
        latitude: (0, s.locFormat)(a.lat, !0)
    }, r);
}, E = function() {
    var e = t(a.default.mark(function e() {
        var t;
        return a.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return b(), e.next = 3, j();

              case 3:
                if (!(t = e.sent)) {
                    e.next = 6;
                    break;
                }
                return e.abrupt("return", t);

              case 6:
                return e.next = 8, q();

              case 8:
                return t = e.sent, e.abrupt("return", t);

              case 10:
              case "end":
                return e.stop();
            }
        }, e, void 0);
    }));
    return function() {
        return e.apply(this, arguments);
    };
}(), I = function(e) {
    var t = {};
    return e ? (Object.keys(e).forEach(function(r) {
        null === e[r] ? t[r] = null : "object" !== v(e[r]) ? t[r] = e[r] : Array.isArray(e[r]) ? t[r] = [ e[r][0] ] : t[r] = e[r];
    }), t) : t;
}, S = (exports.ptfetch = function() {
    var e = t(a.default.mark(function e(t) {
        return a.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", new Promise(function(e, r) {
                    t.success = function(t) {
                        t ? /2\d\d/.test(t.statusCode) ? e(t.data) : r(t.data) : r(t);
                    }, t.fail = r, t.isRequest = !0, (0, u.request)(t);
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, e, void 0);
    }));
    return function(t) {
        return e.apply(this, arguments);
    };
}(), exports.getInfo = function(e, t) {
    return new Promise(function(r, a) {
        wx.showNavigationBarLoading();
        var o = Object.assign({}, D(), t);
        if (o.ajaxId = Date.now() + "_" + Math.floor(1e4 * Math.random()), o.secureToken = (0, 
        c.default)(o), "B" === (g.globalConfig.testIdMapping.miniprogram_websocket || "A")) {
            var n = {
                "content-type": "application/x-www-form-urlencoded; charset=utf-8"
            }, s = Date.now(), i = {
                url: e,
                data: o,
                options: {
                    header: n,
                    method: "get",
                    isNeedCommonParams: 0
                }
            };
            (0, h.default)(i).then(function(t) {
                var a = Date.now() - s;
                r(t), u.metrics.addSocket({
                    url: e,
                    key: "success",
                    value: a
                }), _(t, i, a);
            }).catch(function(o) {
                var c = Date.now() - s;
                /2\d\d/.test(o.statusCode) ? (1e4 === o.code ? E().then(function() {
                    var o = Date.now(), s = {
                        url: e,
                        data: Object.assign({}, D(), t),
                        options: {
                            header: n,
                            method: "get",
                            isNeedCommonParams: 0
                        }
                    };
                    (0, h.default)(s).then(function(t) {
                        var a = Date.now() - o;
                        r(t), u.metrics.addSocket({
                            url: e,
                            key: "success",
                            value: a
                        }), _(t, s, a);
                    }).catch(function(e) {
                        var t = Date.now() - o;
                        wx.hideNavigationBarLoading(), /2\d\d/.test(e.statusCode) ? (r(e), _(e, s, t)) : (a(e), 
                        L(e, s, t));
                    });
                }) : r(o), _(o, i, c)) : (a(o), L(o, i, c));
            }).finally(function() {
                wx.hideNavigationBarLoading();
            });
        } else (0, u.request)({
            url: e,
            data: o,
            isRequest: !0,
            success: function(n) {
                n && n.data ? 1e4 === n.data.code ? E().then(function() {
                    (0, u.request)({
                        url: e,
                        data: Object.assign({}, D(), t),
                        isRequest: !0,
                        success: function(e) {
                            return e && e.data ? r(e.data) : a(e);
                        },
                        fail: a,
                        complete: function() {
                            wx.hideNavigationBarLoading();
                        },
                        reportError: function(t) {
                            return C(t, {
                                url: e,
                                param: o
                            });
                        }
                    });
                }) : r(n.data) : a(n);
            },
            fail: function(e) {
                a(e);
            },
            complete: function() {
                wx.hideNavigationBarLoading();
            },
            reportError: function(t) {
                return C(t, {
                    url: e,
                    param: o
                });
            }
        });
    });
}, exports.postInfo = function(e, t, r) {
    return r = Object.assign({
        navBarLoading: !0,
        showLoading: !1,
        successCode: 0
    }, r), new Promise(function(a, o) {
        r.navBarLoading && wx.showNavigationBarLoading(), r.showLoading && wx.showLoading();
        var s = Object.assign({}, D(e), t);
        s.ajaxId = Date.now() + "_" + Math.floor(1e4 * Math.random()), s.secureToken = (0, 
        c.default)(s);
        var i = (0, n.stringify)(s, {
            allowDots: !0,
            arrayFormat: "repeat"
        }), d = {
            "content-type": "application/x-www-form-urlencoded; charset=utf-8"
        }, l = function() {
            r.navBarLoading && wx.hideNavigationBarLoading(), r.showLoading && wx.hideLoading();
        };
        if ("B" === (g.globalConfig.testIdMapping.miniprogram_websocket || "A")) {
            var f = Date.now(), p = {
                url: e,
                data: i,
                options: {
                    header: d,
                    method: "post",
                    dataParam: "queryString",
                    isNeedCommonParams: 0,
                    successCode: r.successCode
                }
            };
            (0, h.default)(p).then(function(t) {
                var r = Date.now() - f;
                a(t), u.metrics.addSocket({
                    url: e,
                    key: "success",
                    value: r
                }), _(t, p, r);
            }).catch(function(s) {
                var i = Date.now() - f;
                /2\d\d/.test(s.statusCode) ? (1e4 === s.code ? E().then(function() {
                    var s = Date.now(), i = Object.assign({}, D(e), t);
                    i.ajaxId = Date.now() + "_" + Math.floor(1e4 * Math.random()), i.secureToken = (0, 
                    c.default)(i);
                    var l = (0, n.stringify)(i, {
                        allowDots: !0,
                        arrayFormat: "repeat"
                    }), f = {
                        url: e,
                        data: l,
                        options: {
                            header: d,
                            method: "post",
                            dataParam: "queryString",
                            isNeedCommonParams: 0,
                            successCode: r.successCode
                        }
                    };
                    (0, h.default)(f).then(function(t) {
                        var r = Date.now() - s;
                        a(t), u.metrics.addSocket({
                            url: e,
                            key: "success",
                            value: r
                        }), _(t, f, r);
                    }).catch(function(e) {
                        var t = Date.now() - s;
                        /2\d\d/.test(e.statusCode) ? (a(e), _(e, f, t)) : (o(e), L(e, f, t));
                    });
                }) : a(s), _(s, p, i)) : (o(s), L(s, p, i));
            }).finally(function() {
                l();
            });
        } else {
            var m = function(e) {
                return e && /2\d\d/.test(e.statusCode) ? !!e.data || (o(e), !1) : (o(e), !1);
            }, y = o;
            (0, u.request)({
                url: e,
                method: "post",
                header: d,
                data: i,
                fail: y,
                complete: l,
                isRequest: !0,
                reportError: function(t) {
                    return C(t, {
                        url: e,
                        param: i
                    });
                },
                success: function(r) {
                    m(r) && (1e4 === r.data.code ? E().then(function() {
                        var r = Object.assign({}, D(e), t);
                        r.ajaxId = Date.now() + "_" + Math.floor(1e4 * Math.random()), r.secureToken = (0, 
                        c.default)(r);
                        var o = (0, n.stringify)(r, {
                            allowDots: !0,
                            arrayFormat: "repeat"
                        });
                        (0, u.request)({
                            url: e,
                            method: "post",
                            header: d,
                            data: o,
                            fail: y,
                            complete: l,
                            isRequest: !0,
                            reportError: function(t) {
                                return C(t, {
                                    url: e,
                                    param: o
                                });
                            },
                            success: function(e) {
                                m(e) && a(e.data);
                            }
                        });
                    }) : a(r.data));
                }
            });
        }
    });
});

exports.updateUserInfo = function() {
    var e = t(a.default.mark(function e() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return a.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", S(i.updateUserInfoApi, t));

              case 1:
              case "end":
                return e.stop();
            }
        }, e, void 0);
    }));
    return function() {
        return e.apply(this, arguments);
    };
}(), exports.downloadFile = function() {
    var e = t(a.default.mark(function e(t, r) {
        var o, u;
        return a.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return wx.showNavigationBarLoading(), o = Object.assign({}, D(), r), t = t + "?" + (0, 
                n.stringify)(o), u = function() {
                    return wx.hideNavigationBarLoading();
                }, e.next = 6, (0, l.downloadFile)({
                    url: t,
                    complete: u
                });

              case 6:
                return e.abrupt("return", e.sent);

              case 7:
              case "end":
                return e.stop();
            }
        }, e, void 0);
    }));
    return function(t, r) {
        return e.apply(this, arguments);
    };
}();