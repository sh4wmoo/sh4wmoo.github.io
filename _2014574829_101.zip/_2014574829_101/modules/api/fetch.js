!function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../modules/api/metrics.js");

module.exports = function(a) {
    var t = a.loading;
    return new Promise(function(o, d) {
        a = Object.assign({
            method: "GET",
            header: {
                "Content-Type": "application/json;charset=UTF-8"
            },
            isRequest: !0,
            success: function(e) {
                e ? /2\d\d/.test(e.statusCode) ? o(e.data) : d(e.data) : d(e);
            },
            fail: function(e) {
                d(e);
            },
            complete: function() {
                t && wx.hideLoading();
            },
            reportError: function(e) {
                return e.data && e.data.code && 0 === e.data.code ? {
                    code: 0,
                    log: e.data.message,
                    name: "请求成功"
                } : e.data && e.data.code && 0 !== e.data.code ? {
                    code: e.data.code,
                    log: e.data.message,
                    name: "业务错误"
                } : e.data ? void 0 : {
                    code: -1,
                    log: String(e),
                    name: "ajax错误"
                };
            }
        }, a), t && (wx.showLoading({
            title: "",
            mask: !0
        }), delete a.isLoading), (0, e.request)(a);
    });
};