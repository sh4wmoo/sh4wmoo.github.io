!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../utils/goodsValue.js");

Component({
    properties: {
        goodsType: {
            type: String,
            value: ""
        },
        goodsTypeName: {
            type: String,
            value: ""
        },
        weight: {
            type: Number,
            value: 1,
            observer: function(e) {
                this.setData({
                    _displayWeight: e < 5 ? "小于5公斤" : e + "公斤"
                });
            }
        },
        goodsValue: {
            type: Array,
            value: {},
            observer: function(t) {
                this.setData({
                    displayGoodsValue: (0, e.formatGoodsValue)(t)
                });
            }
        },
        highlight: {
            type: Boolean,
            value: !1
        },
        placeholder: {
            type: String,
            value: "请选择要配送的物品信息"
        }
    },
    data: {
        _displayWeight: "小于5公斤",
        displayGoodsValue: ""
    },
    methods: {}
});