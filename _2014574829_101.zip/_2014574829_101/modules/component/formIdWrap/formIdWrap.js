!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../api/request"), r = require("../../api/urls.js");

Component({
    properties: {
        openType: {
            type: String,
            value: ""
        }
    },
    methods: {
        handleFormSubmit: function(o) {
            var i = o.detail, t = void 0 === i ? {} : i;
            t.formId && (0, e.postInfo)(r.formIdCollectApi, {
                formId: t.formId
            });
        }
    }
});