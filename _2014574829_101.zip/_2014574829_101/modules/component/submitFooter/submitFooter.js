function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../../libs/regenerator-runtime/runtime-module.js"));

var t = e(require("../../global.js"));

Component({
    properties: {
        label: {
            type: String,
            value: "跑腿费"
        },
        price: {
            type: Number,
            value: 0,
            observer: function(e) {
                e = (e = 100 * (e || 0)).toFixed(0) / 100, this.setData({
                    displayPrice: e
                });
            }
        },
        submitFooterStyle: {
            type: String,
            value: ""
        }
    },
    data: {
        iphonexWrapperStyle: t.default.isIpx ? "height: 176rpx;" : "",
        displayPrice: 0
    },
    methods: {
        onSubmitTap: function(e) {
            this.triggerEvent("submit", e.detail);
        },
        tapPriceBlock: function(e) {
            this.triggerEvent("show-price", e);
        }
    }
});