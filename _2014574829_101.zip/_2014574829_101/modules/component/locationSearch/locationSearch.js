function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, a) {
            function r(n, i) {
                try {
                    var s = e[n](i), o = s.value;
                } catch (t) {
                    return void a(t);
                }
                if (!s.done) return Promise.resolve(o).then(function(t) {
                    r("next", t);
                }, function(t) {
                    r("throw", t);
                });
                t(o);
            }
            return r("next");
        });
    };
}

var a = t(require("../../../libs/regenerator-runtime/runtime-module.js")), r = require("../../../modules/api/request.js"), n = require("../../api/urls.js"), i = require("../../utils/util"), s = t(require("../../global.js")), o = t(require("../../../modules/utils/mafSwitchRequest.js")), u = t(require("../../../modules/utils/map.js")), c = t(require("../../../modules/utils/mafMap.js")), l = require("../../../modules/utils/reportDetailError"), d = require("../../../modules/utils/getCompleteAddress.js");

Component({
    properties: {
        city: {
            type: Object,
            value: null,
            observer: function(t) {
                null !== t && void 0 !== t && this.first();
            }
        },
        isFocus: {
            type: Boolean,
            value: !0
        },
        searchTextInputVal: {
            type: String,
            value: ""
        },
        currentPage: {
            type: Number,
            value: 1,
            observer: function(t) {
                !this.data.isSearch && this.data.city && this.recommend(t);
            }
        }
    },
    data: {
        isSearch: !1,
        tip: ""
    },
    totalCount: -1,
    methods: {
        cityTap: function() {
            this.triggerEvent("citytap");
        },
        inputFocus: function() {
            this.triggerEvent("inputfocus");
        },
        first: function() {
            var t = this, e = this.data.city || {}, a = {
                addressType: 1,
                businessType: 2,
                businessTypeTag: 0,
                longitude: (0, i.locFormat)(1e6 * e.lng),
                latitude: (0, i.locFormat)(1e6 * e.lat)
            };
            return this.recordp = (0, r.postInfo)(n.latestAddressApi, a).then(function(e) {
                return t.data.tip = 0 === e.code && e.data.specialHints, 0 === e.code && e.data.latestAddress ? t._handelAddr(e.data.latestAddress) : [];
            }).catch(function() {
                wx.showToast({
                    title: "网络异常",
                    icon: "none"
                });
            }), this.recommend(1);
        },
        _handelAddr: function(t) {
            return t.forEach(function(t) {
                t.title = t.address, t.address = t.address + (t.houseNumber ? t.houseNumber : ""), 
                (!s.default.actualLocation || 0 === s.default.actualLocation.lat && 0 === s.default.actualLocation.lng) && 0 === t.distance && (t.distance = -1);
            }), t;
        },
        createSearch: function(t) {
            var r = this, n = this.data.city, i = n.lng, s = n.lat;
            return new Promise(function() {
                var n = e(a.default.mark(function e(n, p) {
                    var h, f, m, g;
                    return a.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return h = !1, e.prev = 1, e.next = 4, o.default;

                          case 4:
                            h = e.sent.mafSwitch, e.next = 9;
                            break;

                          case 7:
                            e.prev = 7, e.t0 = e.catch(1);

                          case 9:
                            if (!h) {
                                e.next = 25;
                                break;
                            }
                            return f = {
                                pagesize: 20,
                                page: t,
                                orderby: "DISTANCE",
                                region: "NEARBY",
                                location: i + "," + s,
                                radius: 1e3
                            }, e.prev = 11, e.next = 14, c.default.search(f);

                          case 14:
                            m = e.sent, r.totalCount = m.count && m.count >= 0 ? m.count : 0, n((m.pois || []).map(function(t) {
                                return {
                                    address: (0, d.getCompleteAddress)(t),
                                    _distance: +(t.distance || 0),
                                    title: t.name || "",
                                    location: {
                                        lng: +((t.location || "").split(",")[0] || ""),
                                        lat: +((t.location || "").split(",")[1] || "")
                                    }
                                };
                            })), e.next = 23;
                            break;

                          case 19:
                            e.prev = 19, e.t1 = e.catch(11), p(e.t1), (0, l.reportDetailJsError)("美团地图sdk搜索附近poi失败", {
                                e: e.t1,
                                lng: i,
                                lat: s
                            }, "warn");

                          case 23:
                            e.next = 27;
                            break;

                          case 25:
                            g = {
                                page_size: 20,
                                page_index: t,
                                orderby: "_distance asc",
                                location: {
                                    latitude: s,
                                    longitude: i
                                },
                                success: function(t) {
                                    t && t.data ? (t.count && (r.totalCount = t.count), n(t.data)) : n([]);
                                },
                                fail: function(t) {
                                    p(t);
                                }
                            }, u.default.search(g);

                          case 27:
                          case "end":
                            return e.stop();
                        }
                    }, e, r, [ [ 1, 7 ], [ 11, 19 ] ]);
                }));
                return function(t, e) {
                    return n.apply(this, arguments);
                };
            }());
        },
        recommend: function() {
            var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            if (this.setData({
                searchTextInputVal: ""
            }), !(e > 1 && this.totalCount > 0 && 20 * (e - 1) >= this.totalCount)) {
                var a = this.createSearch(e);
                return Promise.all([ this.recordp, a ]).then(function(a) {
                    return e > 1 ? t.triggerEvent("recommend-append", {
                        data: a
                    }) : t.triggerEvent("recommend", {
                        data: a,
                        tip: t.data.tip
                    }), a;
                }).catch(function() {
                    wx.showToast({
                        title: "网络异常",
                        icon: "none"
                    });
                });
            }
        },
        suggestionRequest: function(t) {
            var r = this;
            return e(a.default.mark(function e() {
                var n, i, s, p;
                return a.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n = r.data.city, i = !1, e.prev = 2, e.next = 5, o.default;

                      case 5:
                        i = e.sent.mafSwitch, e.next = 10;
                        break;

                      case 8:
                        e.prev = 8, e.t0 = e.catch(2);

                      case 10:
                        if (!i) {
                            e.next = 23;
                            break;
                        }
                        return e.prev = 11, e.next = 14, c.default.search({
                            keyword: t,
                            city: n.name || "",
                            citylimit: !0,
                            region: "CITY"
                        });

                      case 14:
                        s = e.sent, r.triggerEvent("suggest", {
                            data: {
                                status: 0,
                                data: (s.pois || []).map(function(t) {
                                    return {
                                        address: (0, d.getCompleteAddress)(t),
                                        title: t.name || "",
                                        location: {
                                            lng: +((t.location || "").split(",")[0] || ""),
                                            lat: +((t.location || "").split(",")[1] || "")
                                        }
                                    };
                                })
                            }
                        }), e.next = 21;
                        break;

                      case 18:
                        e.prev = 18, e.t1 = e.catch(11), (0, l.reportDetailJsError)("美团地图sdk搜索附近poi失败", {
                            e: e.t1,
                            keyword: t
                        }, "warn");

                      case 21:
                        e.next = 26;
                        break;

                      case 23:
                        p = {
                            keyword: t,
                            region_fix: 1,
                            success: function(t) {
                                r.triggerEvent("suggest", {
                                    data: t
                                });
                            }
                        }, n && n.name && (p.region = n.name), u.default.getSuggestion(p);

                      case 26:
                      case "end":
                        return e.stop();
                    }
                }, e, r, [ [ 2, 8 ], [ 11, 18 ] ]);
            }))();
        },
        autoComplete: function(t) {
            var e = this, a = t.detail.value;
            this.setData({
                searchTextInputVal: a
            }), this.data.isSearch = !0, a || this.first().then(function() {
                e.data.isSearch = !1;
            }), this.suggestionRequest(a);
        },
        clearHandle: function() {
            var t = this;
            this.setData({
                searchTextInputVal: ""
            }), this.first().then(function() {
                t.data.isSearch = !1;
            });
        }
    }
});