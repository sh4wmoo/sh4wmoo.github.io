!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

var e = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var r = arguments[t];
        for (var s in r) Object.prototype.hasOwnProperty.call(r, s) && (e[s] = r[s]);
    }
    return e;
};

Component({
    properties: {
        groups: {
            type: Array,
            value: []
        },
        tip: {
            type: String,
            value: ""
        },
        showDis: {
            type: Boolean,
            value: !0
        }
    },
    methods: {
        addressListItemSelectHandler: function(t) {
            var r = t.target.dataset;
            this.triggerEvent("select", e({
                address: this.data.groups[r.groupIndex].list[r.addressIndex]
            }, r));
        }
    }
});