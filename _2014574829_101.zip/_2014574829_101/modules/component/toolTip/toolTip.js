!function(t) {
    t && t.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        direction: {
            type: String,
            value: "top"
        },
        targetText: {
            type: String,
            value: ""
        },
        inner: {
            type: String,
            value: ""
        },
        arrowStyle: {
            type: String,
            value: ""
        },
        contentStyle: {
            type: String,
            value: ""
        }
    },
    data: {
        isShow: !1
    },
    methods: {
        showTip: function() {
            this.setData({
                isShow: !0
            });
        },
        hideTip: function() {
            this.setData({
                isShow: !1
            });
        }
    }
});