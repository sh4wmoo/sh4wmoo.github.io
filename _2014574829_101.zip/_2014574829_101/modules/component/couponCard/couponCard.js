!function(t) {
    t && t.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

var t = function() {
    function t(t, e) {
        var n = [], r = !0, i = !1, o = void 0;
        try {
            for (var u, a = t[Symbol.iterator](); !(r = (u = a.next()).done) && (n.push(u.value), 
            !e || n.length !== e); r = !0) ;
        } catch (t) {
            i = !0, o = t;
        } finally {
            try {
                !r && a.return && a.return();
            } finally {
                if (i) throw o;
            }
        }
        return n;
    }
    return function(e, n) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, n);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}();

Component({
    properties: {
        unit: {
            type: String,
            value: "元"
        },
        amount: {
            type: Number,
            value: 0,
            observer: function(e) {
                if (e > 0) {
                    var n = e.toString().split("."), r = t(n, 2), i = r[0], o = r[1], u = void 0 === o ? "" : o;
                    this.setData({
                        intAmount: i,
                        decimalAmount: u
                    });
                }
            }
        },
        title: {
            type: String,
            value: ""
        },
        titleTag: {
            type: Object,
            value: null
        },
        desc: {
            type: String,
            value: ""
        },
        deadline: {
            type: String,
            value: ""
        },
        needAction: {
            type: String,
            value: "show"
        },
        actionText: {
            type: String,
            value: "去使用"
        }
    },
    data: {
        intAmount: 0,
        decimalAmount: 0
    },
    methods: {
        triggerAction: function(t) {
            this.triggerEvent("action", {
                type: "coupon"
            });
        }
    }
});