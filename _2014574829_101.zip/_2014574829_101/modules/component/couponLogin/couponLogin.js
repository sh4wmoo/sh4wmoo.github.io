function e(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function r(o, a) {
                try {
                    var i = t[o](a), u = i.value;
                } catch (e) {
                    return void n(e);
                }
                if (!i.done) return Promise.resolve(u).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(u);
            }
            return r("next");
        });
    };
}

var t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../libs/regenerator-runtime/runtime-module.js")), n = require("../../api/login");

Component({
    properties: {
        text: {
            type: String,
            value: ""
        },
        btnText: {
            type: String,
            value: "一键登录领取"
        },
        couponImage: {
            type: String,
            value: ""
        },
        avatar: {
            type: String,
            value: ""
        },
        avatarShow: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        slotOption: {
            body: !0,
            footer: !0
        },
        showPhoneNumModal: !1,
        disableNext: !1
    },
    methods: {
        handleInputPhoneInput: function(e) {
            this.phoneNum = e.detail.value, /\d{11}/.test(this.phoneNum) ? this.setData({
                disableNext: !0
            }) : this.setData({
                disableNext: !1
            });
        },
        handleInputPhoneConfirm: function() {
            this.triggerEvent("next", {
                data: {
                    phoneNum: this.phoneNum
                }
            });
        },
        handleInputPhoneCancel: function() {
            this.setData({
                showPhoneNumModal: !1
            });
        },
        wxMobileLoginDirect: function(n) {
            var r = this;
            return e(t.default.mark(function e() {
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        r.triggerEvent("login-click");

                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, e, r);
            }))();
        },
        handleGetUserInfo: function(r) {
            var o = this;
            return e(t.default.mark(function e() {
                var a;
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (r.detail.userInfo) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        return e.next = 4, (0, n.ptLogin)();

                      case 4:
                        (a = e.sent) ? o.triggerEvent("login-done", {
                            loggedIn: a
                        }) : o.toast("登录失败");

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e, o);
            }))();
        }
    }
});