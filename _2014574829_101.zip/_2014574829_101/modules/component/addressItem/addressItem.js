!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        address: {
            type: Object,
            value: {},
            observer: function(e) {
                this.addressInit(e), this.setData({
                    hasAddress: e && void 0 !== e.address
                });
            }
        },
        errorTip: {
            type: String,
            value: ""
        },
        addressStyle: {
            type: String,
            value: ""
        },
        contactStyle: {
            type: String,
            value: ""
        },
        iconType: {
            type: Number,
            value: ""
        },
        hasBorderBottom: {
            type: Boolean,
            value: !1
        },
        showArrow: {
            type: Boolean,
            value: !1
        },
        hasAddressNote: {
            type: Boolean,
            value: !1
        },
        hasAddressNoteBorder: {
            type: Boolean,
            value: !1
        },
        placeholder: {
            type: String,
            value: ""
        },
        showAll: {
            type: Boolean,
            value: !1
        },
        fixedHeight: {
            type: Boolean,
            value: !0
        },
        nearby: {
            type: Boolean,
            value: !1
        },
        encryption: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        sendIcon: "https://p1.meituan.net/paotui/k3ehj1mbish.png",
        receiveIcon: "https://p0.meituan.net/paotui/k3ehirq66c.png",
        hasAddress: !1,
        addressInfo: {}
    },
    ready: function() {
        this.addressInit(this.data.address);
    },
    methods: {
        handleAddressNoteTap: function() {
            this.triggerEvent("tapAddressNote");
        },
        handleAddressContentTap: function() {
            this.triggerEvent("tapAddressContent");
        },
        addressInit: function(e) {
            var t = Object.assign({}, e);
            this.data.encryption && t.phone && (t.phone = t.phone.replace(/^(\d{3})\d{4}(\d+)/, "$1****$2")), 
            this.setData({
                addressInfo: t
            });
        }
    }
});