!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../api/route.js"), t = require("../../../modules/utils/storage.js"), i = require("../../../modules/api/urls.js");

Component({
    properties: {
        businessType: {
            type: Number,
            value: 1
        },
        show: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        textMap: {
            1: {
                title: "帮送服务协议",
                url: i.h5.deliveryshow
            },
            2: {
                title: "帮买服务协议",
                url: i.h5.shopshow
            }
        }
    },
    methods: {
        preventD: function() {},
        onClickCancel: function() {
            this.triggerEvent("click-cancel");
        },
        onClickConfirm: function() {
            this.triggerEvent("click-confirm");
        },
        goWebView: function() {
            (0, t.setItem)("webViewUrl", this.data.textMap[this.properties.businessType].url), 
            (0, e.navigateTo)({
                url: "/pages/webView/webView"
            });
        }
    }
});