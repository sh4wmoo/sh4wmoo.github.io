function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../../libs/regenerator-runtime/runtime-module.js"));

var o = e(require("../../../modules/api/lx.js")), t = require("../../../modules/api/urls.js"), i = require("../../../modules/api/route.js");

Component({
    properties: {
        goodsCodeSwitchChecked: {
            type: Boolean,
            value: !0
        },
        disableGoodsCodeSwitch: {
            type: Boolean,
            value: !1
        },
        canShowTip: {
            type: Boolean,
            value: !1
        }
    },
    methods: {
        goodsCodeSwitchChange: function(e) {
            this.triggerEvent("goods-code-switch-change", {
                value: e.detail.value
            });
        },
        goodsCodeInstruction: function() {
            (0, i.navigateTo)({
                url: "/pages/webView/webView?url=" + encodeURIComponent(t.h5.goodsCodeInstruction)
            }), o.default.click("b_banma_bs1r4rml_mc");
        },
        handleGoodsCodeSwitcTap: function() {
            this.properties.disableGoodsCodeSwitch && wx.showToast({
                icon: "none",
                title: "收件人使用非标准手机号，无法收到收货码"
            });
        },
        closeTip: function() {
            this.triggerEvent("close-goods-code-tip");
        }
    }
});