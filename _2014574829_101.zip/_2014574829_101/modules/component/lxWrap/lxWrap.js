function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../../libs/regenerator-runtime/runtime-module.js"));

var t = e(require("../../../modules/api/lx.js"));

Component({
    properties: {
        pageCId: {
            type: String
        },
        clickBId: {
            type: String
        },
        viewBId: {
            type: String
        },
        lxParams: {
            type: Object
        }
    },
    addGlobalClass: !0,
    methods: {
        reportClickBId: function() {
            var e = this.properties, r = e.clickBId, i = e.lxParams;
            r && t.default.click(r, i);
        }
    },
    attached: function() {
        var e = this.properties, r = e.viewBId, i = e.lxParams, a = e.pageCId;
        r && t.default.view(r, i), a && t.default.pv(a, i);
    }
});