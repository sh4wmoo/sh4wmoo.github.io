!function(t) {
    t && t.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function() {
                this.setData({
                    phoneNumber: "",
                    inputIndex: 0,
                    num1: "",
                    num2: "",
                    num3: "",
                    num4: ""
                });
            }
        },
        inputFocus: {
            type: Boolean,
            value: !1
        },
        validStatus: {
            type: String,
            value: "",
            observer: function(t) {
                "wrong" === t && this.setData({
                    inputIndex: 3
                });
            }
        },
        errorText: {
            type: String,
            value: ""
        }
    },
    data: {
        phoneNumber: "",
        inputIndex: 0,
        num1: "",
        num2: "",
        num3: "",
        num4: ""
    },
    methods: {
        closeHandle: function() {
            this.setData({
                show: !1,
                inputFocus: !1
            }), this.triggerEvent("close-modal");
        },
        preventDefault: function() {},
        setFocus: function() {
            this.setData({
                inputFocus: !0
            });
        },
        inputHandle: function(t) {
            var e = t.detail.value, n = e.length;
            this.setData({
                phoneNumber: e,
                inputIndex: n,
                num1: e.substr(0, 1),
                num2: e.substr(1, 1),
                num3: e.substr(2, 1),
                num4: e.substr(3, 1)
            }), "validing" !== this.data.validStatus && n >= 4 && this.triggerEvent("valid-confirm", {
                phoneNumber: e
            }, {
                bubbles: !0
            });
        }
    }
});