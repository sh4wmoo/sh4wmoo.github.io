!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        avatar: {
            type: String,
            value: "https://p0.meituan.net/paotui/k3ehd0wyuba.png"
        },
        showedTime: {
            type: String,
            value: ""
        },
        name: {
            type: String,
            value: ""
        },
        text: {
            type: String,
            value: ""
        },
        label: {
            type: Object,
            value: {
                src: "",
                width: "128rpx",
                height: "32rpx",
                openType: "",
                data: {}
            }
        }
    },
    methods: {
        handleLabelTap: function(e) {
            this.triggerEvent("tap-label", {
                data: e.target.dataset.value
            });
        }
    }
});