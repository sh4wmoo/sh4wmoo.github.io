!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        externalStyle: {
            type: String,
            value: ""
        },
        modalStyle: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: ""
        },
        message: {
            type: String,
            value: ""
        },
        show: {
            type: Boolean,
            value: !1
        },
        textCancel: {
            type: String,
            value: ""
        },
        textOk: {
            type: String,
            value: ""
        },
        slotOption: {
            type: Object,
            value: {
                body: !1,
                footer: !1
            }
        }
    },
    data: {
        someData: {}
    },
    methods: {
        onClickCancel: function() {
            this.triggerEvent("click-cancel");
        },
        onClickConfirm: function() {
            this.triggerEvent("click-confirm");
        },
        onClickBackground: function(e) {
            this.triggerEvent("click-background");
        },
        handleTouchMove: function(e) {}
    }
});