!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        error: {
            type: Object,
            value: null
        }
    },
    ready: function() {},
    data: {
        loading: !1
    },
    methods: {
        clickBtn: function() {
            this.triggerEvent("clickerrorpagebtn");
        }
    }
});