!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        defaultImage: {
            type: String
        },
        originalImage: {
            type: String
        },
        mode: {
            type: String,
            value: ""
        }
    },
    data: {
        finishLoadFlag: !1
    },
    methods: {
        finishLoad: function() {
            this.setData({
                finishLoadFlag: !0
            });
        }
    }
});