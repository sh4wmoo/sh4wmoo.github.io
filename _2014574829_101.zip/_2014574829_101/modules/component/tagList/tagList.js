!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        tagList: {
            type: Array,
            value: []
        },
        tagWidth: {
            type: String,
            value: "208rpx"
        },
        defaultSelect: {
            type: Object,
            value: {},
            observer: function(e, t) {
                this.setData({
                    selectedItem: Object.assign({}, e)
                });
            }
        }
    },
    data: {
        selectedItem: {}
    },
    methods: {
        chooseItem: function(e) {
            var t = e.target.dataset.value;
            t && !t.disabled && (this.setData({
                selectedItem: e.target.dataset.value
            }), this.triggerEvent("selected", this.data.selectedItem));
        },
        resetToDefault: function() {
            if (this.data.defaultSelect) {
                var e = this.data.defaultSelect;
                this.setData({
                    selectedItem: Object.assign({}, e)
                }), this.triggerEvent("reset", this.data.selectedItem);
            }
        }
    }
});