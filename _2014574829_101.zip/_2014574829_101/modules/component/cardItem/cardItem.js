!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        title: {
            type: String,
            value: ""
        },
        text: {
            type: String,
            value: ""
        },
        textStyle: {
            type: String,
            value: ""
        },
        placeholder: {
            type: String,
            value: ""
        },
        cardItemStyle: {
            type: String,
            value: ""
        },
        borderBottom: {
            type: Boolean,
            value: !1
        }
    }
});