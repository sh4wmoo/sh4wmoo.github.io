!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        rankList: {
            type: Object,
            value: {
                title: "",
                list: []
            }
        }
    }
});