function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function r(i, a) {
                try {
                    var u = t[i](a), o = u.value;
                } catch (e) {
                    return void n(e);
                }
                if (!u.done) return Promise.resolve(o).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(o);
            }
            return r("next");
        });
    };
}

var n = e(require("../../../libs/regenerator-runtime/runtime-module.js")), r = require("../../utils/util"), i = require("../../api/wx"), a = e(require("../../global.js"));

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        textOk: {
            type: String,
            value: ""
        },
        textCancel: {
            type: String,
            value: "确定"
        },
        content: {
            type: String,
            value: ""
        }
    },
    data: {
        slotOption: {
            footer: !0,
            body: !0
        },
        canUseOpenSetting: (0, r.compareVersion)(a.default.systemInfo.SDKVersion, "2.0.7") >= 0
    },
    methods: {
        handleSettingEnd: function(e) {
            this.triggerEvent("set-end", e.detail.authSetting || {});
        },
        handleConfirmTap: function() {
            var e = this;
            return t(n.default.mark(function t() {
                var r;
                return n.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (e.triggerEvent("click-confirm"), !e.data.canUseOpenSetting) {
                            t.next = 3;
                            break;
                        }
                        return t.abrupt("return");

                      case 3:
                        return t.prev = 3, t.next = 6, (0, i.openSetting)();

                      case 6:
                        r = t.sent, e.triggerEvent("set-end", r.authSetting || {}), t.next = 13;
                        break;

                      case 10:
                        t.prev = 10, t.t0 = t.catch(3), e.triggerEvent("set-error");

                      case 13:
                      case "end":
                        return t.stop();
                    }
                }, t, e, [ [ 3, 10 ] ]);
            }))();
        },
        handleCancelTap: function() {
            this.triggerEvent("click-cancel");
        }
    }
});