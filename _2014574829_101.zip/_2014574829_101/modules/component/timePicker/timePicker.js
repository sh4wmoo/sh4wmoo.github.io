!function(t) {
    t && t.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        title: {
            type: String,
            default: ""
        },
        selectTime: {
            type: Number,
            default: 0,
            observer: function(t) {
                var e = void 0, i = new Date(1e3 * t), a = new Date();
                if (0 === t || i.getTime() < a.getTime()) e = [ 0, 0, 0 ], this.getTodayTime(); else if (a.getDate() - i.getDate() > 1) e = [ 1, 23, 5 ], 
                this.getTomorrowTime(); else {
                    var s = i.getDate() > a.getDate() ? 1 : 0;
                    s ? this.getTomorrowTime() : this.getTodayTime();
                    var n = this.data.hours.findIndex(function(t) {
                        return Number(t) === i.getHours();
                    }), u = void 0;
                    e = [ s, n = -1 === n ? 0 : n, u = -1 === (u = n > 1 || !this.data.hasPickupNow && 1 === n ? this.data.defaultMinutes.findIndex(function(t) {
                        return i.getMinutes() - Number(t) < 10;
                    }) : this.data.curMinutes.findIndex(function(t) {
                        return i.getMinutes() - Number(t) < 10;
                    })) ? 0 : u ];
                }
                this.setData({
                    oldSelected: e
                }), this.handleChange(e, "set");
            }
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t !== this.timeSlideShow && (t ? (this.checkHasToday(), this.setData({
                    timeSlideShow: !0,
                    timeSlideStatus: "visible"
                }), 0 === this.data.selected[0] && this.data.hasToday && 0 === this.data.selected[1] && this.getTodayTime()) : (this.setData({
                    timeSlideShow: !1,
                    timeSlideStatus: "hidden"
                }), this.resetToValue(this.data.oldSelected)));
            }
        },
        hasPickupNow: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        value: [ 0, 0, 0 ],
        selected: [ 0, 0, 0 ],
        oldSelected: [ 0, 0, 0 ],
        dates: [ "今天", "明天" ],
        hours: [ "00", "01", "02", "03" ],
        minutes: [ "00", "10", "20", "30", "40", "50" ],
        curMinutes: [],
        defaultMinutes: [ "00", "10", "20", "30", "40", "50" ],
        pickupTime: 0,
        timeSlideShow: !1,
        timeSlideStatus: "hidden",
        hasToday: !0
    },
    ready: function() {
        this.first = !0;
    },
    methods: {
        bindChange: function(t) {
            this.data.hasToday || 0 !== t.detail.value[0] || (t.detail.value[0] = 1), this.handleChange(t.detail.value);
        },
        handleChange: function(t) {
            var e = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "change", a = Object.assign([], this.data.selected), s = Object.assign([], t), n = function() {
                setTimeout(function() {
                    e.setData({
                        selected: Object.assign([], s)
                    });
                }, 100);
            };
            if (s[0] !== a[0]) switch ("change" === i && (s[1] = 0, s[2] = 0), s[0]) {
              case 0:
                this.getTodayTime(), n();
                break;

              case 1:
                this.getTomorrowTime(), n();
            } else if (s[1] !== a[1]) {
                if ("change" === i && (s[2] = 0), 0 === s[0]) if (this.data.hasPickupNow) {
                    if (0 === s[1]) return void this.setData({
                        minutes: []
                    }, n);
                    if (1 === s[1]) return void this.setData({
                        minutes: Object.assign([], this.data.curMinutes)
                    }, n);
                } else if (0 === s[1]) return void this.setData({
                    minutes: Object.assign([], this.data.curMinutes)
                }, n);
                this.setData({
                    minutes: Object.assign([], this.data.defaultMinutes)
                }, n);
            } else s[2] !== a[2] && n();
        },
        getTodayTime: function() {
            var t = this.getStartDateTime(), e = t.hour, i = t.minute, a = this.getHours(e), s = this.getMinutes(i);
            this.data.hasPickupNow ? this.setData({
                hours: a,
                minutes: [],
                curMinutes: Object.assign([], s)
            }) : this.setData({
                hours: a,
                minutes: Object.assign([], s),
                curMinutes: Object.assign([], s)
            });
        },
        getTomorrowTime: function() {
            var t = Object.assign([], this.getHours(0)), e = Object.assign([], this.getMinutes(0));
            this.setData({
                hours: t,
                minutes: e
            });
        },
        getHours: function(t) {
            var e = [];
            t > 0 && this.data.hasPickupNow && e.push("立即取件");
            for (var i = t; i < 24; i++) {
                var a = "";
                a = i < 10 ? "0" + i : i.toString(), e.push(a);
            }
            return e;
        },
        getMinutes: function(t) {
            for (var e = [], i = t; i < 51; i += 10) {
                var a = "";
                a = i < 10 ? "0" + i : i.toString(), e.push(a);
            }
            return e;
        },
        clickCancel: function() {
            this.setData({
                timeSlideShow: !1,
                timeSlideStatus: "hidden"
            }), this.resetToValue(this.data.oldSelected), this.triggerEvent("cancel");
        },
        clickConfirm: function() {
            var t = this.getTimeText(this.data.selected), e = this.getTimeStamp(this.data.selected);
            this.setData({
                oldSelected: Object.assign([], this.data.selected)
            }), this.triggerEvent("confirm", {
                timeText: t,
                timeStamp: e
            });
        },
        getTimeText: function(t) {
            return 0 === t[0] && 0 === t[1] && this.data.hasPickupNow ? "立即取件" : this.data.dates[t[0]] + " " + this.data.hours[t[1]] + ":" + this.data.minutes[t[2]];
        },
        getTimeStamp: function(t) {
            var e = new Date(), i = new Date(e.getFullYear(), e.getMonth(), e.getDate() + 1), a = 0 === t[0] ? e : i, s = 0;
            if (!this.data.hasPickupNow || 0 === t[0] && 0 !== t[1] || 1 === t[0]) {
                var n = a.getFullYear(), u = a.getMonth(), h = a.getDate(), o = this.data.hours[t[1]], d = this.data.minutes[t[2]];
                s = new Date(n, u, h, +o, +d, 0).getTime();
            }
            return s;
        },
        resetToValue: function(t) {
            var e = this, i = Object.assign([], t), a = function() {
                setTimeout(function() {
                    e.setData({
                        selected: i,
                        oldSelected: i
                    });
                }, 100);
            };
            if (0 === i[0] && this.data.hasToday) {
                if (this.getTodayTime(), this.data.hasPickupNow) {
                    if (0 === i[1]) return void this.setData({
                        minutes: []
                    }, a);
                    if (1 === i[1]) return void this.setData({
                        minutes: Object.assign([], this.data.curMinutes)
                    }, a);
                } else if (0 === i[1]) return void this.setData({
                    minutes: Object.assign([], this.data.curMinutes)
                }, a);
                this.setData({
                    minutes: Object.assign([], this.data.defaultMinutes)
                }, a);
            } else this.getTomorrowTime(), a();
        },
        checkHasToday: function() {
            var t = !0;
            this.data.hasPickupNow || this.getStartDateTime().hour >= 24 && (t = !1), this.setData({
                hasToday: t
            });
        },
        getStartDateTime: function() {
            var t = void 0, e = void 0;
            e = (t = new Date()).getHours() + 1;
            var i = 10 * Math.ceil(t.getMinutes() / 10);
            return 60 === i && (i = 0, e += 1), {
                date: t,
                hour: e,
                minute: i
            };
        }
    }
});