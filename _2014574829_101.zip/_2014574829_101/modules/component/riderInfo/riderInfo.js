!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../utils/util.js");

Component({
    properties: {
        data: {
            type: Object,
            value: {},
            observer: function(e) {
                e && this.initRiderInfo(e);
            }
        }
    },
    data: {
        riderName: "",
        riderTag: "",
        showedArrivalTime: "--"
    },
    methods: {
        initRiderInfo: function(e) {
            var r = this.getShowedArrivalTime(1e3 * e.arrivalTime);
            this.setData({
                riderName: e.riderName || "",
                riderTag: e.riderTag || "",
                showedArrivalTime: r
            });
        },
        getShowedArrivalTime: function(r) {
            return r % 3e5 > 0 && (r = 3e5 * (Math.floor(r / 3e5) + 1)), (0, e.timeToDate)(r, {
                needToday: !0,
                needWeekDay: !0
            });
        }
    }
});