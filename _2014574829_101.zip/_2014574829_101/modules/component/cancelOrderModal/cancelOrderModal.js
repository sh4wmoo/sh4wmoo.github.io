!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        cancelOrderModalShow: {
            type: Boolean,
            value: !1
        },
        showModifyOrderInfoEntry: {
            type: Boolean,
            value: !1
        },
        cancelCanUrgeGrab: {
            type: Number,
            value: 2
        }
    },
    data: {
        cancelOrderModalSlotOption: {
            body: !0,
            footer: !0
        }
    },
    methods: {
        closeCancelOrderModal: function() {
            this.triggerEvent("closeCancelOrderModal");
        },
        cancelOrderConfirm: function() {
            this.triggerEvent("cancelOrderConfirm");
        },
        clickModifyOrderInfo: function() {
            this.triggerEvent("clickModifyOrderInfo");
        },
        handleWait: function() {
            1 === this.properties.cancelCanUrgeGrab ? this.triggerEvent("urgeOrder") : this.closeCancelOrderModal();
        }
    }
});