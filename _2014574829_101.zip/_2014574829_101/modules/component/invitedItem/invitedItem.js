!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../utils/util");

Component({
    properties: {
        avatar: {
            type: String,
            value: ""
        },
        timestamp: {
            type: Number,
            value: 0,
            observer: function(t) {
                t > 0 && this.setData({
                    showedTime: (0, e.timeToDate)(1e3 * t, {
                        needToday: !0
                    })
                });
            }
        },
        name: {
            type: String,
            value: "",
            observer: function(e) {
                e.length > 10 ? this.setData({
                    showedName: e.slice(0, 10) + "..."
                }) : this.setData({
                    showedName: e
                });
            }
        },
        text: {
            type: String,
            value: ""
        },
        label: {
            type: String,
            value: ""
        }
    },
    data: {
        showedTime: "--",
        showedName: ""
    },
    methods: {
        handleLabelTap: function() {
            this.triggerEvent("tap-label", this.data.label);
        }
    }
});