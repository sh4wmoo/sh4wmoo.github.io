!function(t) {
    t && t.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        title: {
            type: String,
            value: ""
        },
        content: {
            type: String,
            value: ""
        },
        actionText: {
            type: String,
            value: ""
        }
    },
    methods: {
        triggerAction: function() {
            this.triggerEvent("action", {
                type: "empty"
            });
        }
    }
});