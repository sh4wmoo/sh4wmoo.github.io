!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        city: {
            type: Object,
            value: {}
        },
        title: {
            type: String,
            value: ""
        },
        distance: {
            type: Number,
            value: -2,
            observer: function(e) {
                var t = "";
                t = -1 === e ? "" : e < 10 && e > -1 ? "<10m" : 10 <= e && e <= 1e3 ? e + "m" : (e / 1e3).toFixed(2) + "km", 
                this.setData({
                    _distance: t
                });
            }
        },
        address: {
            type: String,
            value: ""
        },
        showDis: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        _distance: 0
    },
    methods: {}
});