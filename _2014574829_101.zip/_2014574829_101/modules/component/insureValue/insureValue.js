!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        item: {
            type: "Object",
            value: {}
        }
    },
    data: {},
    methods: {}
});