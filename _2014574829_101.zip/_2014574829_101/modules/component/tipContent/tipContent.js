!function(t) {
    t && t.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        tipTags: {
            type: Object,
            value: []
        },
        tipFee: {
            type: Number,
            value: 0
        },
        tipfeeMax: {
            type: Number,
            value: 0
        },
        state: {
            type: Number,
            value: -1,
            observer: function(t, e) {
                var a = this;
                if (0 === t) {
                    var i = this.data.tipTags.reduce(function(t, e) {
                        return e.id === a.data.tipFee ? e : t;
                    }, null), u = {
                        tipValue: this.data.tipFee,
                        tipText: "",
                        tipBtnActive: !1,
                        tipInputFocus: !1,
                        defaultSelect: {}
                    };
                    i ? u.defaultSelect = i : (u.tipBtnActive = !0, u.tipText = this.data.tipFee), this.setData(u);
                } else 1 === t ? this.triggerConfirm() : -1 === t && this.setData({
                    tipText: "",
                    defaultSelect: {}
                });
            }
        }
    },
    data: {
        defaultSelect: {},
        tipBtnActive: !1,
        tipText: "",
        tipInputFocus: !1,
        tipValue: "0",
        tipWarning: !1
    },
    methods: {
        selectedTipType: function(t) {
            this.setData({
                tipBtnActive: !1,
                tipValue: t.detail.id,
                tipText: "",
                defaultSelect: Object.assign({}, t.detail)
            }), this.triggerEvent("overflow", {
                data: {
                    valid: !0,
                    value: this.data.tipValue,
                    max: this.data.tipfeeMax
                }
            });
        },
        clickTipBtn: function(t) {
            this.setData({
                defaultSelect: {},
                tipBtnActive: !0,
                tipInputFocus: !0,
                tipValue: this.data.tipText || ""
            }), this.triggerEvent("overflow", {
                data: {
                    valid: this.data.tipValue && this.data.tipValue <= this.data.tipfeeMax,
                    value: this.data.tipValue,
                    max: this.data.tipfeeMax
                }
            });
        },
        tipInputChange: function(t) {
            this.setData({
                tipText: t.detail.value,
                tipValue: Number(t.detail.value)
            }), this.triggerEvent("overflow", {
                data: {
                    valid: this.data.tipValue && this.data.tipValue <= this.data.tipfeeMax,
                    value: this.data.tipValue,
                    max: this.data.tipfeeMax
                }
            });
        },
        tipInputBlur: function(t) {
            this.setData({
                tipInputFocus: !1
            });
        },
        triggerConfirm: function() {
            var t = this.data.tipfeeMax;
            0 !== this.data.tipValue.length && +this.data.tipValue <= t && this.triggerEvent("confirm", {
                value: this.data.tipValue,
                flag: !0,
                defaultTip: this.data.newDefaultSelect
            });
        }
    }
});