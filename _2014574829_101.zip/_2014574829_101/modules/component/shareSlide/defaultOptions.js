Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getDefaultOptions = void 0;

(function(e) {
    e && e.__esModule;
})(require("../../../libs/regenerator-runtime/runtime-module.js")), exports.getDefaultOptions = function() {
    return [ {
        text: "微信好友",
        openType: "share",
        icon: "https://vfile.meituan.net/paotui/jj5h8spqtkpgb9.png",
        type: "normal"
    }, {
        text: "朋友圈",
        openType: "",
        icon: "https://vfile.meituan.net/paotui/jj5h8xp3nwb3xr.png",
        type: "moments"
    } ];
};