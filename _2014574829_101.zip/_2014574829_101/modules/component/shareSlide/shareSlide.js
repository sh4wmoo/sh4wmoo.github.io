function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../../libs/regenerator-runtime/runtime-module.js"));

var t = require("./defaultOptions"), a = e(require("../../global.js"));

Component({
    properties: {
        shareOptions: {
            type: Array,
            value: (0, t.getDefaultOptions)()
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                this.setData({
                    slideStatus: e ? "visible" : "hidden"
                });
            }
        }
    },
    data: {
        buttonMargin: 56,
        slideStatus: "hidden",
        isIpx: a.default.isIpx
    },
    methods: {
        handleShareButtonTap: function(e) {
            this.setData({
                show: !1
            }), this.triggerEvent("share-tap", {
                type: e.target.dataset.type
            });
        },
        handleCancel: function() {
            this.setData({
                show: !1
            }), this.triggerEvent("share-cancel");
        }
    }
});