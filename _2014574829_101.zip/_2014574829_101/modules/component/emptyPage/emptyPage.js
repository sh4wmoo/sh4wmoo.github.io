!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        message: {
            type: String,
            value: ""
        }
    }
});