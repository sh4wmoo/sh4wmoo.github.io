!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../api/route");

Component({
    properties: {
        insurances: {
            type: Object,
            value: null,
            observer: function(e, t) {
                e.length > 0 && this.setData({
                    selected: e[0]
                });
            }
        },
        isConfirm: {
            type: Boolean,
            value: !1,
            observer: function(e, t) {
                e && this.triggerConfirm();
            }
        },
        hideType: {
            type: Number,
            value: 0,
            observer: function(e, t) {
                if (2 === e) {
                    var a = Object.assign({}, this.data.oldSelected), s = !0;
                    0 === this.data.oldSelected.pkgId && (s = !1), this.setData({
                        selected: a,
                        hasSelected: s
                    });
                }
            }
        }
    },
    data: {
        selected: {
            pkgId: 0,
            name: "未选购",
            desc: "",
            cost: 0
        },
        oldSelected: {
            pkgId: 0,
            name: "未选购",
            desc: "",
            cost: 0
        },
        hasSelected: !1
    },
    methods: {
        selectInsurance: function(e) {
            this.setData({
                selected: Object.assign({}, e.currentTarget.dataset.value)
            }), 0 !== e.currentTarget.dataset.value.pkgId ? this.setData({
                hasSelected: !0
            }) : this.setData({
                hasSelected: !1
            });
        },
        clickRadio: function(e) {
            if (0 !== this.data.selected.pkgId) {
                var t = this.data.hasSelected;
                this.setData({
                    hasSelected: !t
                });
            }
        },
        triggerConfirm: function() {
            if (0 === this.data.selected.pkgId || this.data.hasSelected) {
                var e = Object.assign({}, this.data.selected);
                this.setData({
                    oldSelected: e
                }), this.triggerEvent("confirm", {
                    value: this.data.selected,
                    flag: !0
                });
            } else wx.showToast({
                title: "请先阅读并同意保险说明",
                icon: "none"
            }), this.triggerEvent("confirm", {
                value: this.data.selected,
                flag: !1
            });
        },
        handleProtocolTab: function() {
            (0, e.navigateTo)({
                url: "/pages/webView/webView"
            });
        }
    }
});