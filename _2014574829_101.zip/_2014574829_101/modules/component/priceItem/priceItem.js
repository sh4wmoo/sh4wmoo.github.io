!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

Component({
    properties: {
        stepData: {
            type: Object,
            value: {},
            observer: function(e, t) {
                this.convertData(e);
            }
        }
    },
    data: {
        name: "",
        priceStr: ""
    },
    methods: {
        convertData: function(e) {
            var t = e.price, i = e.stepPrice, a = void 0, s = void 0, n = void 0, r = void 0, p = void 0, o = void 0;
            "distancePlanDetails" === e.stepType ? (s = e.endDistance / 1e3, n = e.startDistance / 1e3, 
            a = e.step / 1e3, p = 1e3, o = 150, r = "公里") : "weightPlanDetails" === e.stepType ? (s = e.endWeight, 
            n = e.startWeight, a = e.step, p = 200, o = 200, r = "公斤") : "timePlanDetails" === e.stepType && (s = e.endTime, 
            n = e.startTime);
            var c = "";
            "timePlanDetails" === e.stepType ? c = n + "-" + s : 0 == t && 0 == i ? c = "" : 0 != i ? c = s > p ? "超过" + (n + r) + "的部分" : n + "-" + (s + r) + "的部分" : 0 != t && (c = s > o ? "超过" + (n + r) + "时" : n + "-" + (s + r) + "时");
            var d = "";
            "timePlanDetails" === e.stepType ? d = "+" + t + "元" : 0 == t && 0 == i ? d = "" : 0 != i ? d = 1 == a ? "每" + r + "+" + i + "元" : "每" + (a + r) + "+" + i + "元" : 0 != t && (d = "+" + t + "元"), 
            this.setData({
                name: c,
                priceStr: d
            });
        }
    }
});