!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

var e = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
    }
    return e;
};

Component({
    properties: {
        couponLists: {
            type: Array,
            value: []
        },
        emptyCoupons: {
            type: Array,
            value: []
        },
        nickname: {
            type: String,
            value: ""
        },
        avatarShow: {
            type: Boolean,
            value: !0
        },
        avatar: {
            type: String,
            value: ""
        },
        message: {
            type: String,
            value: ""
        },
        useBtnText: {
            type: String,
            value: "立即使用"
        },
        inviteBtnText: {
            type: String,
            value: ""
        },
        showInviteBtn: {
            type: Boolean,
            value: !0
        },
        displayPhoneText: {
            type: String,
            value: ""
        },
        canShareMoments: {
            type: Boolean,
            value: !1
        }
    },
    methods: {
        useNow: function() {
            this.triggerEvent("use-now", {});
        },
        inviteNow: function() {
            this.triggerEvent("invite-now", {});
        },
        triggerAction: function(t) {
            var n = t.target, r = t.detail;
            this.triggerEvent("coupon-card-action", e({
                index: n.dataset.index
            }, r));
        }
    }
});