function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../../libs/regenerator-runtime/runtime-module.js"));

var t = e(require("../../global.js"));

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        footSlideStyle: {
            type: String,
            value: ""
        },
        slideControlStyle: {
            type: String,
            value: ""
        },
        backGroundStyle: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: ""
        },
        show: {
            type: Boolean,
            value: !1
        },
        slideStatus: {
            type: String,
            value: "hidden"
        },
        labelLeft: {
            type: String,
            value: "取消"
        },
        labelRight: {
            type: String,
            value: "确定"
        },
        useCustomRight: {
            type: Boolean,
            value: !1
        },
        useCustomLeft: {
            type: Boolean,
            value: !1
        },
        disableLeft: {
            type: Boolean,
            value: !1
        },
        disableRight: {
            type: Boolean,
            value: !1
        },
        needControls: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        isIpx: t.default.isIpx
    },
    methods: {
        preventD: function() {},
        onClickBack: function() {
            this.triggerEvent("click-bg");
        },
        onClickCancel: function() {
            this.data.disableLeft || this.triggerEvent("click-cancel");
        },
        onClickConfirm: function() {
            this.data.disableRight || this.triggerEvent("click-confirm");
        }
    }
});