function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, n) {
            function o(r, a) {
                try {
                    var i = e[r](a), s = i.value;
                } catch (t) {
                    return void n(t);
                }
                if (!i.done) return Promise.resolve(s).then(function(t) {
                    o("next", t);
                }, function(t) {
                    o("throw", t);
                });
                t(s);
            }
            return o("next");
        });
    };
}

function n(t) {
    if (Array.isArray(t)) {
        for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
        return n;
    }
    return Array.from(t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(t) {
    function s() {
        for (;this._beforeHooks && this._beforeHooks.length; ) {
            var t = this._beforeHooks.shift();
            t && t();
        }
    }
    function u() {
        for (;this._afterHooks && this._afterHooks.length; ) {
            var t = this._afterHooks.shift();
            t && t();
        }
    }
    var l = (t = c(t)).onShow;
    t.onShow = function(t) {
        s.call(this, t), l && l.call(this, t), u.call(this, t);
    };
    var f = [];
    t.on = function(t, e) {
        var n = i.default.on(t, e, this);
        return f.push(n), n;
    }, t.emit = function() {
        return i.default.emit.apply(i.default, arguments);
    };
    var h = t.onUnload;
    t.onUnload = function() {
        var t = [].slice.call(arguments, 0);
        for (h && h.call.apply(h, [ this ].concat(n(t))); f && f.length; ) {
            var e = f.shift();
            console.log("unsubscribe " + e.name), e && e();
        }
    }, t.toast = function(t) {
        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "none";
        wx.showToast({
            title: t,
            icon: e
        });
    }, t.modal = function() {
        var t = e(o.default.mark(function t(e) {
            var n = e.title, r = void 0 === n ? "" : n, a = e.content, i = void 0 === a ? "" : a, s = e.showCancel, c = void 0 === s || s, u = e.cancelText, l = void 0 === u ? "取消" : u, f = e.cancelColor, h = void 0 === f ? "#000000" : f, d = e.confirmText, v = void 0 === d ? "确定" : d, _ = e.confirmColor, m = void 0 === _ ? "#ffb000" : _, p = e.complete, g = void 0 === p ? function() {} : p;
            return o.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.abrupt("return", new Promise(function(t, e) {
                        wx.showModal({
                            title: r,
                            content: i,
                            success: function(e) {
                                return t(e.confirm);
                            },
                            showCancel: c,
                            cancelText: l,
                            cancelColor: h,
                            confirmText: v,
                            confirmColor: m,
                            fail: e,
                            complete: g
                        });
                    }));

                  case 1:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(), t.__dataCache = {}, t.__setDataTimer = 0, t.__callbackList = [], t.setDataAsync = function(e, n) {
        var o = this;
        this.__dataCache = Object.assign(this.__dataCache, e), n && t.__callbackList.push(n), 
        this.__setDataTimer || (this.__setDataTimer = setTimeout(function() {
            o.setData(o.__dataCache, function() {
                t.__callbackList.forEach(function(t) {
                    "function" == typeof t && t.call(o);
                }), t.__callbackList = [];
            }), clearTimeout(o.__setDataTimer), o.__setDataTimer = 0, o.__dataCache = {};
        }, 0));
    }, (0, a.page)(t, r.page);
};

var o = t(require("../libs/regenerator-runtime/runtime-module.js")), r = require("../modules/api/cat.js"), a = require("../modules/api/metrics"), i = t(require("../modules/utils/event.js")), s = {
    error: {
        show: !1
    },
    isIpx: t(require("../modules/global.js")).default.isIpx
}, c = function(t) {
    var e = t.data, n = {
        data: Object.assign({}, s, e),
        error: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.toHandle, n = t.imgSrc, o = void 0 === n ? "https://p0.meituan.net/paotui/k3eh8n9cy2e.png" : n, r = t.message, a = void 0 === r ? "当前网络异常，请稍后重试" : r, i = t.showBtn, c = void 0 === i || i, u = t.btnText, l = void 0 === u ? "重新加载" : u;
            e ? this.setData({
                error: {
                    imgSrc: o,
                    message: a,
                    showBtn: c,
                    toHandle: e,
                    btnText: l,
                    show: !0
                }
            }) : this.setData({
                error: s.error
            });
        },
        clickerrorpagebtn: function() {
            this.data.error.toHandle();
        }
    };
    return Object.assign(t, n);
};