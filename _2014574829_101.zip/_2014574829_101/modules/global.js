!function(t) {
    t && t.__esModule;
}(require("../libs/regenerator-runtime/runtime-module.js"));

var t = {
    dev: "paotui.banma.dev.sankuai.com",
    test: "paotui.banma.test.sankuai.com",
    st: "paotui.banma.st.meituan.com",
    online: "paotui.meituan.com"
}, i = "online", e = {
    dev: "activity.web.c.waimai.dev.sankuai.com",
    test: "activity.web.c.waimai.test.sankuai.com",
    st: "activity.waimai.st.meituan.com",
    online: "activity.waimai.meituan.com"
}, a = {
    dev: "F93D7755C4EE4D8B9D25F380E8CA9CF5",
    test: "D1D2458046B24C5FA7C08A28B14FA373",
    st: "F6EBDB4AA7654BA08BEC5ACAF37F750F",
    online: "F6EBDB4AA7654BA08BEC5ACAF37F750F"
}, s = {
    dev: "stable.pay.dev.sankuai.com",
    test: "stable.pay.test.sankuai.com",
    st: "stable-pay.st.meituan.com",
    online: "mpay.meituan.com"
}, n = {
    dev: "https://apis.map.qq.com/ws/",
    test: "https://apis.map.qq.com/ws/",
    st: "https://apis.map.qq.com/ws/",
    online: "https://apis.map.qq.com/ws/"
}, m = {
    dev: "https://peisong.meituan.com/api/collector/",
    test: "https://peisong.meituan.com/api/collector/",
    st: "https://peisong.meituan.com/api/collector/",
    online: "https://peisong.meituan.com/api/collector/"
}, o = {
    dev: "https://maf.meituan.com",
    test: "https://maf.meituan.com",
    st: "https://maf.meituan.com",
    online: "https://maf.meituan.com"
}, c = {
    dev: "https://fe-config.meituan.com",
    test: "https://fe-config.meituan.com",
    st: "https://fe-config.meituan.com",
    online: "https://fe-config.meituan.com"
}, p = wx.getSystemInfoSync();

module.exports = {
    env: i,
    version: "2.23.0",
    appId: "wx84d3c06952bb4072",
    domain: "https://" + t[i],
    h5Domain: "https://" + t[i],
    activityDomain: "https://" + e[i],
    payDomain: "https://" + s[i],
    qqmapPrefix: "" + n[i],
    bmmonitorPrefix: "" + m[i],
    channel_url_key: "" + a[i],
    channel: "wx_miniProgramsDefault",
    channel_activity_id: "",
    isIpx: p.model.indexOf("iPhone X") > -1,
    isAndroid: /android/i.test(p.system),
    isIOS: /ios/i.test(p.system),
    systemInfo: p,
    loginPromise: null,
    clientType: "wx_app_source",
    mafPrefix: "" + o[i],
    feConfigPrefix: "" + c[i]
};