function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e, n) {
    var u = {}, a = e.computed;
    Object.keys(a).forEach(function(o) {
        var i = a[o];
        if ("function" != typeof i) return console.error(o + " 值必须为函数"), null;
        Object.defineProperty(e.state, o, {
            configurable: !0,
            enumerable: !0,
            set: function() {},
            get: function() {
                var u = new r.default(e, i, function() {
                    e.state[o] = u.value, n.setData(t({}, o, u.value));
                });
                return n.data[o] = u.value, function() {
                    return u.value;
                };
            }()
        }), u[o] = e.state[o];
    }), n.setData(u);
};

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = e(require("./watcher"));