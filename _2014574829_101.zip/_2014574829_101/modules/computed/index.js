function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

exports.default = function(e, o) {
    if ("object" !== n(e.computed) || null === e.computed || !Object.keys(e.computed).length) return console.warn("computed及属性必须为对象"), 
    null;
    (0, t.default)(e), (0, r.default)(e, o);
};

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var t = e(require("./observer")), r = e(require("./init")), n = "function" == typeof Symbol && "symbol" === o(Symbol.iterator) ? function(e) {
    return void 0 === e ? "undefined" : o(e);
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : o(e);
};