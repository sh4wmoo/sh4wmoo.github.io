function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function n(e, t) {
    var n = new a.default(), o = e[t], u = r(o);
    Object.defineProperty(e, t, {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return a.default.target && (n.depend(), u && u.dep.depend()), o;
        },
        set: function(e) {
            o = e, n.notify();
        }
    });
}

function r(e) {
    var t = null;
    return "object" === (void 0 === e ? "undefined" : f(e)) && null !== e && (t = Object.prototype.hasOwnProperty.call(e, "__ob__") && e.__ob__ instanceof l ? e.__ob__ : new l(e)), 
    t;
}

function o(e, t, n) {
    Object.defineProperty(e, t, {
        value: n,
        enumerable: !1,
        writable: !0,
        configurable: !0
    });
}

function u() {
    var e = Array.prototype, t = Object.create(e);
    return [ "push", "pop", "shift", "unshift", "splice", "sort", "reverse" ].forEach(function(n) {
        var r = e[n];
        o(t, n, function() {
            for (var e = arguments.length, t = Array(e), o = 0; o < e; o++) t[o] = arguments[o];
            var u = r.apply(this, t), i = this.__ob__, a = void 0;
            switch (n) {
              case "push":
              case "unshift":
                a = t;
                break;

              case "splice":
                a = t.slice(2);
            }
            return a && i.observeArray(a), i.dep.notify(), u;
        });
    }), t;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

exports.default = function(e) {
    new l(e.state);
};

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var a = e(require("./dep")), f = "function" == typeof Symbol && "symbol" === i(Symbol.iterator) ? function(e) {
    return void 0 === e ? "undefined" : i(e);
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : i(e);
}, c = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), l = function() {
    function e(n) {
        t(this, e), this.value = n, this.dep = new a.default(), o(n, "__ob__", this), Array.isArray(n) ? (n.__proto__ = u(), 
        this.observeArray(n)) : this.walk(n);
    }
    return c(e, [ {
        key: "walk",
        value: function(e) {
            for (var t = Object.keys(e), r = 0; r < t.length; r++) n(e, t[r]);
        }
    }, {
        key: "observeArray",
        value: function(e) {
            for (var t = 0, n = e.length; t < n; t++) r(e[t]);
        }
    } ]), e;
}();