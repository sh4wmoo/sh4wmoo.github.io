!function(_) {
    _ && _.__esModule;
}(require("./libs/regenerator-runtime/runtime-module.js"));

module.exports = {
    WX_CODE: "code",
    OPEN_ID: "open_id",
    UUID: "UUID",
    USER_INFO: "userInfo",
    SERVICE_PHONE: "10109777",
    SEND_ADDR_NEW_FLAG: "sendAddrNewFlag",
    RECEIVE_ADDR_NEW_FLAG: "receiveAddrNewFlag",
    BUSINESS_TYPE_DELIVERY: 1,
    BUSINESS_TYPE_BUY: 2,
    BUSINESS_TYPE_TAG_SPECIFIC: 0,
    BUSINESS_TYPE_TAG_NORMAL: 1,
    BUSINESS_TYPE_TAG_DIRECT_DELIVERY: 20,
    SUBMIT_ENTRANCE_NORMAL: 1,
    SUBMIT_ENTRANCE_PRIVACY: 2,
    GOODS_INFO_REFER_INDEX: "A",
    GOODS_INFO_REFER_ORDER_DETAIL: "B",
    COUPON_LIST_TYPE_ORDER: 1,
    COUPON_LIST_TYPE_PERSONAL: 2,
    QQ_MAP_BASE_URL: "https://apis.map.qq.com/ws/"
};