function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var r = require("../../modules/utils/storage.js"), i = e(require("../../modules/page")), t = require("../../modules/utils/reportDetailError.js"), s = require("../../modules/api/request.js"), a = require("../../modules/api/metrics.js");

(0, i.default)({
    data: {
        url: "",
        showWebView: !0
    },
    onLoad: function(e) {
        var i = this, t = void 0;
        t = e.url ? decodeURIComponent(e.url) : (0, r.getItem)("webViewUrl"), this.originUrl = t, 
        this.needParams = "true" === e.need_params, this.needLogin = "true" === e.need_login, 
        this.share = "true" === e.share, this.shareUrl = e.shareUrl && decodeURIComponent(e.shareUrl), 
        this.shareImage = e.shareImage && decodeURIComponent(e.shareImage), this.shareTitle = e.shareTitle && decodeURIComponent(e.shareTitle), 
        this.needLogin && this.on("loginSuccess", function() {
            i.init(), i.reloadWebView();
        }), this.init();
    },
    init: function() {
        var e = this.originUrl;
        if (this.needParams) {
            var r = JSON.stringify((0, s.getCommonInfo)());
            e = -1 === e.indexOf("#") ? e + "#" + encodeURIComponent(r) : -1 === e.split("#")[1].indexOf("?") ? e + "?wx_common_params=" + encodeURIComponent(r) : e + "wx_common_params=" + encodeURIComponent(r);
        }
        this.share ? wx.showShareMenu() : wx.hideShareMenu(), this.setData({
            url: e
        });
    },
    onShareAppMessage: function(e) {
        var r = {};
        return this.shareUrl ? r.path = this.shareUrl : r.path = "/pages/webView/webView?url=" + encodeURIComponent(this.originUrl) + "&need_params=" + this.needParams + "&need_login=" + this.needLogin + "&share=" + this.share + "&shareImage=" + encodeURIComponent(this.shareImage) + "&shareTitle=" + encodeURIComponent(this.shareTitle), 
        this.shareImage && (r.imageUrl = this.shareImage), this.shareTitle && (r.title = this.shareTitle), 
        r;
    },
    reloadWebView: function() {
        var e = this;
        this.setData({
            showWebView: !1
        }), setTimeout(function() {
            e.setData({
                showWebView: !0
            });
        }, 100);
    },
    handleMessage: function(e) {
        this.emit("webViewEvent", e.detail.data);
    },
    handleError: function(e) {
        (0, t.reportDetailResourceError)("resource error: " + e.detail.src, JSON.stringify(e));
    },
    handleLoad: function(e) {
        a.metrics.addWebview(), /https:\/\/mp\.weixin\.qq\.com\/mp\/waerrpage/.test(e.detail.src) && (0, 
        t.reportDetailResourceError)("domain not configured: " + this.data.url, JSON.stringify(e));
    }
});