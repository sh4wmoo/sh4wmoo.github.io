!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

exports.__esModule = !0, exports.authrize = exports.state = exports.config = void 0;

var e = require("./types"), t = {
    dirname: "/authrize",
    pageConfig: {
        tipText: "请完成微信授权以继续使用",
        image: {
            src: "https://p0.meituan.net/codeman/1d662d64d96895705a1d0b9433fd0fa8175649.png",
            mode: "aspectFit"
        }
    }
};

exports.config = t;

var r = {
    cache: null
};

exports.state = r;

exports.authrize = function(i, n) {
    return new Promise(function(a, o) {
        e.AUTH_TYPE[i] ? !1 === n.withCredentials && r.cache ? a(r.cache) : (r.resolve = function(e) {
            wx.navigateBack(), setTimeout(function() {
                r.cache = e, a(e);
            }, 200);
        }, r.reject = o, wx.navigateTo({
            url: t.dirname + "/page/index?type=" + i
        })) : o("API " + i + " is not supported");
    });
};