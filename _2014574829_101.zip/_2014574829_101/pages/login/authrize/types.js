!function(e) {
    e && e.__esModule;
}(require("../../../libs/regenerator-runtime/runtime-module.js"));

exports.__esModule = !0, exports.AUTH_TYPE = void 0;

var e = {
    userInfo: "userInfo"
};

exports.AUTH_TYPE = e;