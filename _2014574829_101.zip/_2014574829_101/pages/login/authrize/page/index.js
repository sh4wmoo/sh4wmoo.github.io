function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function r(u, o) {
                try {
                    var i = t[u](o), a = i.value;
                } catch (e) {
                    return void n(e);
                }
                if (!i.done) return Promise.resolve(a).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(a);
            }
            return r("next");
        });
    };
}

function n(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

var r, u = e(require("../../../../libs/regenerator-runtime/runtime-module.js")), o = e(require("../../../../modules/global.js")), i = require("../index"), a = require("../types"), s = e(require("../../../../modules/api/lx.js")), c = require("../../../../modules/utils/util.js"), l = require("../../../../modules/api/login.js"), f = e(require("../../../../modules/page.js")), d = (r = {}, 
n(r, a.AUTH_TYPE.userInfo, {
    type: a.AUTH_TYPE.userInfo,
    text: "授权微信用户信息",
    openType: "getUserInfo"
}), n(r, "getPhoneNumber", {
    type: "getPhoneNumber",
    text: "授权微信用户信息",
    openType: "getPhoneNumber"
}), n(r, "login", {
    type: "login",
    text: "授权微信用户信息",
    openType: "getUserInfo"
}), r);

(0, f.default)({
    data: {
        AUTH_TYPE: a.AUTH_TYPE,
        btn: {}
    },
    onLoad: function(e) {
        this.url = e.url || "", this.type = e.type, this.setData({
            btn: d[e.type]
        });
    },
    onShow: function() {
        var e = this;
        return t(u.default.mark(function t() {
            return u.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if ("getPhoneNumber" !== e.type) {
                        t.next = 3;
                        break;
                    }
                    return t.next = 3, e.getLoginCode();

                  case 3:
                    s.default.pv("c_nbqao32z");

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t, e);
        }))();
    },
    getuserinfoClick: function(e) {
        var t = this, n = e.detail;
        n && n.iv ? (this.type === a.AUTH_TYPE.userInfo ? i.state.resolve(n) : (0, l.ptLogin)().then(function() {
            t.emit("loginSuccess"), wx.navigateBack();
        }), s.default.click("b_pj9eluj1")) : s.default.click("b_5ckn8sfl");
    },
    requestAuthTap: function() {
        s.default.click("b_jf9w10wo");
    },
    onUnload: function() {
        o.default.loginPromise = null;
    },
    getLoginCode: function() {
        var e = this;
        return new Promise(function(t, n) {
            wx.login({
                success: function(r) {
                    r.code ? (e.code = r.code, t()) : n(r.errMsg);
                }
            });
        });
    },
    getMobile: function(e) {
        var n = this;
        return t(u.default.mark(function t() {
            var r;
            return u.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.detail.encryptedData) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    -1 == (r = decodeURIComponent(n.url)).indexOf("?") && (r += "?"), wx.redirectTo({
                        url: r + "&" + (0, c.jsonToUrl)({
                            jsCode: n.code,
                            phoneEncrypt: e.detail.encryptedData,
                            iv: e.detail.iv
                        })
                    });

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, t, n);
        }))();
    }
});