function e(e) {
    return e && "object" == (void 0 === e ? "undefined" : a(e)) && "default" in e ? e.default : e;
}

function t(e, t) {
    function n() {
        this.constructor = e;
    }
    g(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, 
    new n());
}

function n(e, t) {
    var n = {};
    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var i = 0;
        for (r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && (n[r[i]] = e[r[i]]);
    }
    return n;
}

function r(e, t, n, r) {
    return new (n || (n = Promise))(function(i, o) {
        function s(e) {
            try {
                u(r.next(e));
            } catch (e) {
                o(e);
            }
        }
        function a(e) {
            try {
                u(r.throw(e));
            } catch (e) {
                o(e);
            }
        }
        function u(e) {
            e.done ? i(e.value) : new n(function(t) {
                t(e.value);
            }).then(s, a);
        }
        u((r = r.apply(e, t || [])).next());
    });
}

function i(e, t) {
    function n(n) {
        return function(s) {
            return function(n) {
                if (r) throw new TypeError("Generator is already executing.");
                for (;a; ) try {
                    if (r = 1, i && (o = 2 & n[0] ? i.return : n[0] ? i.throw || ((o = i.return) && o.call(i), 
                    0) : i.next) && !(o = o.call(i, n[1])).done) return o;
                    switch (i = 0, o && (n = [ 2 & n[0], o.value ]), n[0]) {
                      case 0:
                      case 1:
                        o = n;
                        break;

                      case 4:
                        return a.label++, {
                            value: n[1],
                            done: !1
                        };

                      case 5:
                        a.label++, i = n[1], n = [ 0 ];
                        continue;

                      case 7:
                        n = a.ops.pop(), a.trys.pop();
                        continue;

                      default:
                        if (!(o = 0 < (o = a.trys).length && o[o.length - 1]) && (6 === n[0] || 2 === n[0])) {
                            a = 0;
                            continue;
                        }
                        if (3 === n[0] && (!o || n[1] > o[0] && n[1] < o[3])) {
                            a.label = n[1];
                            break;
                        }
                        if (6 === n[0] && a.label < o[1]) {
                            a.label = o[1], o = n;
                            break;
                        }
                        if (o && a.label < o[2]) {
                            a.label = o[2], a.ops.push(n);
                            break;
                        }
                        o[2] && a.ops.pop(), a.trys.pop();
                        continue;
                    }
                    n = t.call(e, a);
                } catch (e) {
                    n = [ 6, e ], i = 0;
                } finally {
                    r = o = 0;
                }
                if (5 & n[0]) throw n[1];
                return {
                    value: n[0] ? n[1] : void 0,
                    done: !0
                };
            }([ n, s ]);
        };
    }
    var r, i, o, s, a = {
        label: 0,
        sent: function() {
            if (1 & o[0]) throw o[1];
            return o[1];
        },
        trys: [],
        ops: []
    };
    return s = {
        next: n(0),
        throw: n(1),
        return: n(2)
    }, "function" == typeof Symbol && (s[Symbol.iterator] = function() {
        return this;
    }), s;
}

function o() {}

var s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, a = (function(e) {
    e && e.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js")), "function" == typeof Symbol && "symbol" === s(Symbol.iterator) ? function(e) {
    return void 0 === e ? "undefined" : s(e);
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : s(e);
}), u = require("./config.js").promise;

u && (Promise = u);

var c = require("./config.js").promise;

c && (Promise = c), Object.defineProperty(exports, "__esModule", {
    value: !0
});

var d = require("npm/@mtfe/mt-weapp-url/stringify.js"), l = require("authrize/index.js"), f = require("authrize/types.js"), p = e(require("npm/@mtfe/wx-rc-finger/dist/finger.js")), h = e(require("npm/@mtfe/wxapp-rohr/dist/rohr.js")), v = require("npm/@mtfe/mt-weapp-url/parse.js");

String.prototype.startsWith || (String.prototype.startsWith = function(e, t) {
    return this.substr(!t || t < 0 ? 0 : +t, e.length) === e;
});

var m, g = function(e, t) {
    return (g = Object.setPrototypeOf || {
        __proto__: []
    } instanceof Array && function(e, t) {
        e.__proto__ = t;
    } || function(e, t) {
        for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n]);
    })(e, t);
}, w = function() {
    return (w = Object.assign || function(e) {
        for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
        return e;
    }).apply(this, arguments);
}, b = function(e) {
    function n(t, n) {
        var r = e.call(this, "Wechat API " + t + " get error result: [msg]" + n) || this;
        return r.api = t, r.msg = n, Object.setPrototypeOf(r, x.prototype), r;
    }
    return t(n, e), n;
}(Error), y = function(e) {
    function n(t, r, i) {
        void 0 === i && (i = "");
        var o = e.call(this, "Request " + r + " failed: " + t + ". " + i) || this;
        return o.errType = "WxRequestError", Object.setPrototypeOf(o, n.prototype), o;
    }
    return t(n, e), n;
}(Error), x = function(e) {
    function n(t, r, i) {
        void 0 === i && (i = !1);
        var o = this, s = r || {
            code: 0,
            message: "自定义未知错误，可能是数据返回格式错误"
        }, a = s.code, u = s.message;
        return (o = e.call(this, "API " + t + " return error result: " + u) || this).errType = "MtAPIError", 
        o.code = a, o.tip = u, o.show = i, Object.setPrototypeOf(o, n.prototype), o;
    }
    return t(n, e), n;
}(Error), k = function(e) {
    function n(t, r, i) {
        void 0 === i && (i = !0);
        var o = e.call(this, t + (null != r ? "[" + r + "]" : "")) || this;
        return o.show = i, o.code = r, o.tip = t, o.errType = "SDKError", Object.setPrototypeOf(o, n.prototype), 
        o;
    }
    return t(n, e), n;
}(Error), _ = void 0, I = function(e) {
    return r(_, void 0, void 0, function() {
        return i(this, function(t) {
            switch (t.label) {
              case 0:
                return null != e ? [ 3, 2 ] : [ 4, (void 0 === n && (n = {}), new Promise(function(e, t) {
                    wx.login({
                        success: function(n) {
                            n ? e(n.code) : t(new b("wx.login", "null login result"));
                        },
                        fail: function(e) {
                            t(new b("wx.login", "fail to request login"));
                        }
                    });
                })) ];

              case 1:
                return [ 2, m = t.sent() ];

              case 2:
                return [ 2, m = e ];
            }
            var n;
        });
    });
}, P = function(e) {
    return new Promise(function(t, n) {
        wx.getStorage({
            key: e,
            success: function(e) {
                e && e.data ? t(e.data) : n(new b("getStorage", "null result"));
            },
            fail: function(e) {
                n(new b("getStorage", "fail to request getStorage"));
            }
        });
    });
}, C = function(e, t) {
    return new Promise(function(n, r) {
        wx.setStorage({
            key: e,
            data: t,
            success: function(e) {
                n(e);
            },
            fail: function(e) {
                r(new b("setStorage", "fail to request setStorage"));
            }
        });
    });
}, S = function(e, t) {
    var n = void 0 === t ? {} : t, r = n.title, i = void 0 === r ? "提示" : r, o = n.showCancel, s = void 0 !== o && o, a = n.confirmText, u = void 0 === a ? "确定" : a, c = n.cancelText, d = void 0 === c ? "取消" : c;
    return new Promise(function(t, n) {
        wx.showModal({
            title: i,
            content: e || "",
            showCancel: s,
            confirmText: u,
            cancelText: d,
            success: function(e) {
                t(!s || e && e.confirm);
            },
            fail: function() {
                n();
            }
        });
    });
}, T = function(e, t, n) {
    void 0 === t && (t = "success"), void 0 === n && (n = 2e3), e && e.length && wx.showToast({
        title: e,
        mask: !0,
        icon: t,
        duration: n
    });
}, E = function() {
    return new Promise(function(e, t) {
        wx.checkSession({
            success: function() {
                e(!0);
            },
            fail: function() {
                e(!1);
            }
        });
    });
}, O = !1, N = function(e, t, n, o) {
    return void 0 === t && (t = e.replace(/^\/|\?.*$/g, "")), void 0 === n && (n = !1), 
    void 0 === o && (o = !1), r(_, void 0, void 0, function() {
        return i(this, function(r) {
            return O ? [ 2 ] : [ 2, new Promise(function(r, i) {
                var s, a, u;
                O = !0, setTimeout(function() {
                    O = !1;
                }, 200), o ? wx.reLaunch({
                    url: e,
                    success: r,
                    fail: i
                }) : n || (s = t, (u = (a = getCurrentPages())[a.length - 1]) && (u.route || u.__route__) === s) ? wx.redirectTo({
                    url: e,
                    success: r,
                    fail: i
                }) : wx.navigateTo({
                    url: e,
                    success: r,
                    fail: i
                });
            }) ];
        });
    });
}, D = require("./config.js").request || function(e, t) {
    return void 0 === t && (t = {}), new Promise(function(n, r) {
        var i = t.data, o = t.header, s = void 0 === o ? {} : o, a = t.method, u = t.query, c = t.type;
        c && "form" === c.toLocaleLowerCase() && (s["content-type"] = "application/x-www-form-urlencoded"), 
        u && (e += (~e.indexOf("?") ? "&" : "?") + d.stringify(u)), wx.request({
            url: e,
            data: i,
            header: s,
            method: a,
            success: function(t) {
                t && t.data ? n(t.data) : r(new y("No data in response.", e, JSON.stringify(t)));
            },
            fail: function(t) {
                r(new y("May be due to network.", e, JSON.stringify(t)));
            }
        });
    });
}, A = require("./config.js") || {}, L = "2.2.1", U = {
    env: A ? A.env : ""
}, q = function() {
    return U.env;
}, R = q, B = "https://portal-portm.meituan.com/weapp/loginsdk/api/", V = A, j = V.appConfig, H = {
    loginRoute: "",
    bindRoute: "",
    smsVerifyRoute: "",
    changeBindPhoneRoute: "",
    _route: "",
    set sdkRoute(e) {
        this._route = e, this.loginRoute = e + "/subpages/entry/index", this.bindRoute = e + "/subpages/bind/index", 
        this.smsVerifyRoute = e + "/subpages/sms-verify/index", this.changeBindPhoneRoute = e + "/subpages/change-bind-phone/index";
    },
    get sdkRoute() {
        return this._route;
    }
};

H.sdkRoute = V.route;

var W, M, G, K = V.entryPageOption, Y = V.bindPageOption, F = V.authrizePageOption, X = V.tips;

(M = exports.API_TYPE || (exports.API_TYPE = {})).WX_MOBILE = "wxMobileLogin", M.WXV2 = "wxLogin", 
M.MOBILE = "mobileLogin", M.LOGIN = "login", M.CHANGE_BIND = "changeBind", (G || (G = {})).create = "createSession";

var z, $, J, Q = function(e) {
    return e && "string" == typeof e && 64 === e.length;
}, Z = function e(t) {
    return r(void 0, void 0, void 0, function() {
        var n;
        return i(this, function(r) {
            switch (r.label) {
              case 0:
                return [ 4, D("portm" === A.api ? B + "uuid" : "https://i.meituan.com/uuid/register").catch(function(e) {
                    return console.log(e);
                }) ];

              case 1:
                return n = r.sent(), Q(n) ? [ 3, 3 ] : 0 < t ? [ 4, e(t - 1) ] : [ 3, 3 ];

              case 2:
                return [ 2, r.sent() ];

              case 3:
                return [ 2, n || "" ];
            }
        });
    });
}, ee = function(e, t) {
    return void 0 === t && (t = 1), r(void 0, void 0, void 0, function() {
        var n, r;
        return i(this, function(i) {
            switch (i.label) {
              case 0:
                return Q(e) ? [ 2, z = e ] : Q(z) ? [ 2, z ] : [ 4, j.persistKey ? P(j.persistKey).then(function(e) {
                    return e && e.uuid;
                }).catch(function(e) {
                    return "";
                }) : "" ];

              case 1:
                return n = i.sent(), Q(n) ? [ 2, z = n ] : [ 4, Z(t) ];

              case 2:
                return r = i.sent(), [ 2, z = r ];
            }
        });
    });
}, te = function(e) {
    return e && e.iv ? e : null;
}, ne = function(e) {
    return void 0 === e && (e = {}), r(void 0, void 0, void 0, function() {
        var t, n, r;
        return i(this, function(i) {
            switch (i.label) {
              case 0:
                return [ 4, new Promise(function(e, t) {
                    wx.getSetting({
                        success: function(t) {
                            e(t);
                        },
                        fail: function(e) {
                            t(null);
                        }
                    });
                }) ];

              case 1:
                return (t = i.sent().authSetting) && t["scope.userInfo"] ? (!0 === (n = e.withCredentials) && I(m), 
                [ 4, (o = {
                    withCredentials: n
                }, new Promise(function(e, t) {
                    wx.getUserInfo(w({}, o, {
                        success: function(t) {
                            e(t);
                        },
                        fail: function() {
                            t(null);
                        }
                    }));
                })) ]) : [ 3, 3 ];

              case 2:
                if (r = i.sent(), !n || te(r)) return [ 2, r ];
                i.label = 3;

              case 3:
                return wx.hideToast(), l.config.dirname = A.authRoute || H.sdkRoute + "/authrize", 
                l.config.pageConfig = Object.assign(l.config.pageConfig, {
                    tipText: F.tipText,
                    image: {
                        src: F.imageSrc,
                        mode: F.imageMode
                    }
                }), [ 2, l.authrize(f.AUTH_TYPE.userInfo, e).catch(function(e) {
                    throw console.error(e), new Error(X.refuseUserInfoAuth);
                }) ];
            }
            var o;
        });
    });
};

($ = exports.SessionState || (exports.SessionState = {})).AUTH = "auth", $.BINDING = "bind", 
$.DESTORY = "destory", $.ABORT = "abort", (J = exports.SessionEvent || (exports.SessionEvent = {})).CLICK = "click", 
J.SMSCLICK = "smsclick", J.LOGINCLICK = "loginclick", J.BINDPAGEONSHOW = "bindpageonshow", 
J.ENTRYPAGEONSHOW = "entrypageonshow", J.CHANGEPHONEPAGEONSHOW = "changebindpageonshow", 
J.ALLOWPHONE = "allowphone", J.REFUSEPHONE = "refusephone", J.CHANGEPHONEGETNEWCODE = "changephonegetnewcode";

var re, ie, oe, se = function() {
    function e(e, t, n) {
        void 0 === t && (t = exports.SessionState.AUTH), this._callbacks = {}, this.type = e, 
        this.state = t, n && (this.expire = new Date().getTime() + n);
    }
    return Object.defineProperty(e.prototype, "expired", {
        get: function() {
            return !!this.expire && this.expire < new Date().getTime();
        },
        enumerable: !0,
        configurable: !0
    }), e.prototype._state = function(e, t) {
        this.state = e, t && (this.data = t), this._emit(e, t);
    }, e.prototype._emit = function(e, t) {
        var n = this, r = this._callbacks[e];
        r && r.forEach(function(e) {
            return e.call(n, t);
        });
    }, e.prototype.on = function(e, t) {
        (this._callbacks[e] = this._callbacks[e] || []).push(t);
    }, e.prototype.clean = function() {
        this._callbacks = {}, this.resolve = null;
    }, e.prototype.abort = function() {
        this._state(exports.SessionState.ABORT);
    }, e;
}(), ae = {}, ue = {}, ce = {
    get session() {
        return re;
    },
    set session(e) {
        re && re._state(exports.SessionState.DESTORY), re = e;
    }
}, de = function() {
    ce.session = null;
}, le = void 0, fe = [ function(e) {
    if ("MtAPIError" === e.errType) return e.show ? S(e.tip) : (console.error("MtAPIError: " + e.message + ", " + e.tip), 
    !0);
}, function(e) {
    if ("WxRequestError" === e.errType) return console.error(e.message), S(X.networkTimeout);
}, function(e) {
    if (e instanceof b) return console.error("调用" + e.api + "出错！" + e.msg), !0;
}, function(e) {
    if ("SDKError" === e.errType) return console.log("SDKError: " + e.message), !e.show || S("" + e.tip);
} ], pe = function(e) {
    return r(le, void 0, void 0, function() {
        var t, n;
        return i(this, function(r) {
            switch (r.label) {
              case 0:
                wx.hideToast(), t = 0, n = fe, r.label = 1;

              case 1:
                return t < n.length ? [ 4, (0, n[t])(e) ] : [ 3, 4 ];

              case 2:
                if (r.sent()) return [ 2 ];
                r.label = 3;

              case 3:
                return t++, [ 3, 1 ];

              case 4:
                return console.error(e.message), [ 2 ];
            }
        });
    });
}, he = function(e) {
    return r(le, void 0, void 0, function() {
        return i(this, function(t) {
            switch (t.label) {
              case 0:
                return e && e.token && e.userId ? (ce.authInfo = e, j.persistKey ? [ 4, C(j.persistKey, e).catch(function(e) {
                    console.error(e);
                }) ] : [ 3, 2 ]) : [ 3, 4 ];

              case 1:
                t.sent(), t.label = 2;

              case 2:
                return [ 4, ge() ];

              case 3:
                return t.sent(), [ 2, e ];

              case 4:
                throw new k(X.illegalAuthInfo);
            }
        });
    });
}, ve = function() {
    return r(le, void 0, void 0, function() {
        var e, t;
        return i(this, function(n) {
            switch (n.label) {
              case 0:
                return (e = ce.authInfo) && e.token ? [ 2, e ] : j.persistKey ? [ 4, P(j.persistKey).catch(function() {
                    return null;
                }) ] : [ 3, 2 ];

              case 1:
                if ((t = n.sent()) && t.token) return [ 2, t ];
                n.label = 2;

              case 2:
                return [ 2, null ];
            }
        });
    });
}, me = function() {
    return r(le, void 0, void 0, function() {
        return i(this, function(e) {
            switch (e.label) {
              case 0:
                return ce.authInfo = null, j.persistKey ? [ 4, (t = j.persistKey, new Promise(function(e, n) {
                    wx.removeStorage({
                        key: t,
                        success: function(t) {
                            e(t);
                        },
                        fail: function(e) {
                            n(new b("removeStorage", "fail to request removeStorage"));
                        }
                    });
                })).catch(o) ] : [ 3, 2 ];

              case 1:
                e.sent(), e.label = 2;

              case 2:
                return [ 2 ];
            }
            var t;
        });
    });
}, ge = function(e) {
    return r(le, void 0, void 0, function() {
        var t, n, r, o;
        return i(this, function(i) {
            switch (i.label) {
              case 0:
                return (t = ce.session) ? (n = t.resolve, r = t.redirectUrl, o = t.waitBack, ce.session = null, 
                o ? [ 4, we(r) ] : [ 3, 2 ]) : [ 3, 4 ];

              case 1:
                return i.sent(), [ 3, 3 ];

              case 2:
                we(r), i.label = 3;

              case 3:
                "function" == typeof n && n(e || ve()), i.label = 4;

              case 4:
                return [ 2 ];
            }
        });
    });
}, we = function(e) {
    return r(le, void 0, void 0, function() {
        var t, n, r, o, s;
        return i(this, function(i) {
            return t = getCurrentPages(), n = H.sdkRoute.replace(/^\//, ""), r = t[0].route ? "route" : "__route__", 
            o = t.findIndex(function(e) {
                return e[r].startsWith(n);
            }), e ? 0 < o && o === t.length - 1 ? [ 2, N(e, "", !0) ] : [ 2, N(e) ] : -1 === o ? [ 2 ] : 0 < (s = 0 < o ? t.length - o : t.length - o - 1) ? [ 2, new Promise(function(e) {
                wx.navigateBack({
                    delta: s
                });
                var n = t.length - s;
                !function t() {
                    setTimeout(function() {
                        getCurrentPages().length === n ? e() : t();
                    }, 100);
                }();
            }) ] : [ 2 ];
        });
    });
}, be = function(e, t) {
    return r(le, void 0, void 0, function() {
        var n;
        return i(this, function(r) {
            switch (r.label) {
              case 0:
                return [ 4, he(Object.assign(e, t)) ];

              case 1:
                return n = r.sent(), T(X.loginSuccess), [ 2, n ];
            }
        });
    });
}, ye = function(e) {
    return r(le, void 0, void 0, function() {
        return i(this, function(t) {
            switch (t.label) {
              case 0:
                return W ? [ 4, W(e) ] : [ 3, 2 ];

              case 1:
                if (!t.sent()) throw new k("loginCheck failed", 3, !1);
                t.label = 2;

              case 2:
                return [ 2 ];
            }
        });
    });
}, xe = function(e, t) {
    var n = ce.session;
    return n && !n.expired ? (n.clean(), n) : ce.session = new se(e, exports.SessionState.AUTH, t);
}, ke = {
    getLoginCode: I,
    getUserInfo: ne,
    getUUID: ee,
    getStorage: P,
    setStorage: C,
    showTip: S,
    showToast: T,
    request: D,
    stringify: d.stringify,
    navigate: N
}, _e = function e(t) {
    return r(void 0, void 0, void 0, function() {
        var n, r, o, s;
        return i(this, function(i) {
            switch (i.label) {
              case 0:
                return r = !0, (t = t || {}) instanceof se ? n = t : (n = t.session || e[G.create](), 
                !1 === t.bind && (r = !1)), n.data = n.data || {}, n.redirectUrl = t.redirectUrl, 
                n.waitBack = t.waitBack, n.data.wxUserInfoData = t.wxUserInfoData, o = H.loginRoute, 
                s = n.type === exports.API_TYPE.LOGIN ? o + "?bind=" + r + "&redirectUrl=" + (n.redirectUrl || "") : o + "?type=" + n.type + "&bind=" + r + "&redirectUrl=" + (n.redirectUrl || ""), 
                t.code && n.data.wxUserInfoData && (s = s + "code=" + t.code), [ 4, N(s, o.substr(1)) ];

              case 1:
                return i.sent(), [ 4, new Promise(function(e, t) {
                    n.resolve = e;
                }) ];

              case 2:
                return [ 2, i.sent() ];
            }
        });
    });
};

_e[G.create] = function() {
    return xe(exports.API_TYPE.LOGIN);
}, (oe = ie || (ie = {})).navigateTo = "navigateTo", oe.redirectTo = "redirectTo", 
oe.reLaunch = "reLaunch";

var Ie, Pe, Ce = function(e, t) {
    return r(void 0, void 0, void 0, function() {
        var n, r, o, s;
        return i(this, function(i) {
            switch (i.label) {
              case 0:
                return n = e || Se[G.create](), r = "" + H.bindRoute, o = t === ie.redirectTo, s = t === ie.reLaunch, 
                [ 4, N(r, H.bindRoute.substr(1), o, s) ];

              case 1:
                return i.sent(), [ 2, n ];
            }
        });
    });
}, Se = function(e) {
    return void 0 === e && (e = {}), r(void 0, void 0, void 0, function() {
        var t;
        return i(this, function(n) {
            switch (n.label) {
              case 0:
                return [ 4, Ce(e.session, e.navType) ];

              case 1:
                return t = n.sent(), [ 4, new Promise(function(e, n) {
                    t.resolve = e;
                }) ];

              case 2:
                return [ 2, n.sent() ];
            }
        });
    });
};

Se[G.create] = function() {
    return xe(exports.API_TYPE.MOBILE);
}, (Pe = Ie || (Ie = {})).loginApplyUrl = "mobileloginapply", Pe.mobileLoginUrl = "mobilelogin", 
Pe.verifyloginUrl = "verifylogin", Pe.wxMobileLoginApiV2 = "wxmobilelogin", Pe.wxLoginApiV2 = "wxlogin", 
Pe.wxSlientLoginApiV2 = "wxslientlogin", Pe.wxMobileBindApplyApiV2 = "wxbindapply", 
Pe.wxMobileBindLoginApiV2 = "wxbind", Pe.wxTicketLoginApiV2 = "wxticketlogin", Pe.updateWxUserApi = "updatewxuserinfo", 
Pe.getWxUserApi = "getwxuserinfo", Pe.smartCheckApi = "smartcheck", Pe.sendNewcodeApi = "sendnewcode", 
Pe.verifyNewApi = "verifynew", Pe.logoutUrl = "logout", Pe.islogoutUrl = "islogout";

var Te, Ee = function(e) {
    var t = require("./urls.js")[q() || "prod"];
    return ("portm" === A.api ? Object.keys(t).reduce(function(e, t) {
        return e[t] = B + (q() ? q() + "/" : "") + t, e;
    }, {}) : t)[e];
}, Oe = Ie.verifyloginUrl, Ne = function() {
    return Te || new Promise(function(e, t) {
        p.g(e);
    }).then(function(e) {
        return Te = e;
    }).catch(function(e) {
        throw new k("获取指纹信息失败：" + (e && e.message));
    });
}, De = function(e, t, n, r, i) {
    var o = n.risk_platform, s = n.risk_partner, a = n.risk_app, u = n.version_name, c = {
        uuid: t,
        risk_platform: o,
        risk_partner: s,
        sdkVersion: L,
        risk_app: a,
        version_name: u
    };
    return void 0 !== n.risk_smsPrefixId && (c.risk_smsPrefixId = n.risk_smsPrefixId), 
    void 0 !== n.risk_smsTemplateId && (c.risk_smsTemplateId = n.risk_smsTemplateId), 
    D(e, {
        method: "POST",
        query: c,
        type: "form",
        data: r
    });
}, Ae = void 0, Le = Ie.wxLoginApiV2, Ue = Ie.wxMobileLoginApiV2, qe = Ie.wxMobileBindApplyApiV2, Re = Ie.wxMobileBindLoginApiV2, Be = Ie.wxTicketLoginApiV2, Ve = Ie.wxSlientLoginApiV2, je = Ie.loginApplyUrl, He = Ie.mobileLoginUrl, We = function(e, t, n, o, s) {
    return void 0 === n && (n = !0), void 0 === o && (o = null), r(void 0, void 0, void 0, function() {
        var a, u, c, d, l, f, p, h, v, m, g, b, y;
        return i(this, function(k) {
            switch (k.label) {
              case 0:
                s || xe(exports.API_TYPE.WX_MOBILE), k.label = 1;

              case 1:
                return k.trys.push([ 1, 6, , 7 ]), a = j.appName, u = j.risk_partner, c = j.risk_platform, 
                d = j.uuid, l = j.risk_app, f = j.version_name, "string" == typeof t ? [ 3, 3 ] : (console.log("wxMobileLogin get code inside"), 
                [ 4, I() ]);

              case 2:
                t = k.sent(), k.label = 3;

              case 3:
                return p = {
                    phoneNumberData: e,
                    uuid: d,
                    appName: a,
                    risk_partner: u,
                    risk_platform: c,
                    risk_app: l,
                    version_name: f,
                    loginCode: t,
                    bind: n,
                    wxUserInfoData: te(o)
                }, [ 4, (_ = p, r(Ae, void 0, void 0, function() {
                    var e, t, n, r, o, s, a, u, c, d, l, f, p, h, v, m, g, w, b, y, k, P, C;
                    return i(this, function(i) {
                        switch (i.label) {
                          case 0:
                            return e = _.appName, n = _.loginCode, r = _.uuid, o = _.bind, s = _.wxUserInfoData, 
                            a = (t = _.phoneNumberData).iv, u = t.encryptedData, [ 4, Promise.all([ ee(r), I(n), Ne() ]) ];

                          case 1:
                            return c = i.sent(), d = c[0], l = c[1], f = c[2], p = {
                                appName: e,
                                code: l,
                                iv: a,
                                encryptedData: u,
                                bind: !!o,
                                wechatFingerprint: f
                            }, h = {
                                code: l,
                                uuid: d
                            }, o ? (k = te(s)) ? [ 3, 3 ] : [ 4, ne() ] : [ 3, 4 ];

                          case 2:
                            k = i.sent(), i.label = 3;

                          case 3:
                            m = (v = k).userInfo, g = v.rawData, w = v.signature, b = v.iv, y = v.encryptedData, 
                            Object.assign(p, {
                                rawData: g,
                                signature: w,
                                encryptedData2: y,
                                iv2: b
                            }), h.userInfo = m, i.label = 4;

                          case 4:
                            return [ 4, De(Ee(Ue), d, _, p) ];

                          case 5:
                            if (P = i.sent(), C = P.error) throw new x(Ee(Ue), C, !0);
                            return h.loginInfo = P, [ 2, h ];
                        }
                    });
                })) ];

              case 4:
                return h = k.sent(), v = h.loginInfo, m = h.uuid, g = h.code, b = w({
                    type: exports.API_TYPE.WX_MOBILE
                }, v.data, {
                    uuid: m,
                    code: g
                }), n && (b.wxUserInfo = h.userInfo), [ 4, he(b) ];

              case 5:
                return [ 2, k.sent() ];

              case 6:
                return y = k.sent(), console.log("error", y), [ 2, pe(y) ];

              case 7:
                return [ 2 ];
            }
            var _;
        });
    });
}, Me = function e(t) {
    return void 0 === t && (t = {}), r(void 0, void 0, void 0, function() {
        var n, o, s, a, u, c, l, f, p, h, v, m, g, b, y, k, _, P, C, S, E, O;
        return i(this, function(D) {
            switch (D.label) {
              case 0:
                u = a = !(s = o = !0), (n = t.session || e[G.create]()).redirectUrl = t.redirectUrl, 
                n.waitBack = t.waitBack, !1 === t.bind && (o = !1), !1 === t.slient && (s = !1), 
                n.redirectUrl && o && (a = t.navType === ie.redirectTo, u = t.navType === ie.reLaunch), 
                s || T("登录中...", "loading", 5e3), D.label = 1;

              case 1:
                return D.trys.push([ 1, 11, , 12 ]), c = j.appName, l = j.risk_app, f = j.risk_partner, 
                p = j.risk_platform, h = j.uuid, v = j.version_name, m = n.data, s ? [ 4, (L = {
                    appName: c,
                    risk_partner: f,
                    risk_platform: p,
                    risk_app: l,
                    version_name: v,
                    uuid: h
                }, r(Ae, void 0, void 0, function() {
                    var e, t, n, r, o, s, a, u, c;
                    return i(this, function(i) {
                        switch (i.label) {
                          case 0:
                            return e = L.appName, t = L.uuid, [ 4, I() ];

                          case 1:
                            return n = i.sent(), [ 4, Promise.all([ ee(t), Ne() ]) ];

                          case 2:
                            return r = i.sent(), o = r[0], s = r[1], a = {
                                appName: e,
                                code: n,
                                wechatFingerprint: s
                            }, [ 4, De(Ee(Ve), o, L, a) ];

                          case 3:
                            if (u = i.sent(), (c = u.error) && 101155 !== c.code) throw new x(Ee(Ve), c);
                            return [ 2, {
                                loginInfo: u,
                                code: n,
                                uuid: o
                            } ];
                        }
                    });
                })) ] : [ 3, 3 ];

              case 2:
                return m = D.sent(), [ 3, 5 ];

              case 3:
                return [ 4, (A = {
                    appName: c,
                    risk_partner: f,
                    risk_platform: p,
                    risk_app: l,
                    version_name: v,
                    uuid: h,
                    wxUserInfoData: t.wxUserInfoData
                }, r(Ae, void 0, void 0, function() {
                    var e, t, n, r, o, s, a, u, c, d, l, f, p, h, v, m, g;
                    return i(this, function(i) {
                        switch (i.label) {
                          case 0:
                            return e = A.appName, t = A.uuid, n = A.wxUserInfoData, [ 4, I(A.loginCode) ];

                          case 1:
                            return r = i.sent(), (l = te(n)) ? [ 3, 3 ] : [ 4, ne({
                                withCredentials: !0
                            }) ];

                          case 2:
                            l = i.sent(), i.label = 3;

                          case 3:
                            return s = (o = l).userInfo, a = o.rawData, u = o.signature, c = o.iv, d = o.encryptedData, 
                            [ 4, Promise.all([ ee(t), Ne() ]) ];

                          case 4:
                            return f = i.sent(), p = f[0], h = f[1], v = {
                                appName: e,
                                code: r,
                                iv: c,
                                encryptedData: d,
                                rawData: a,
                                signature: u,
                                wechatFingerprint: h,
                                admitLogout: !0
                            }, [ 4, De(Ee(Le), p, A, v) ];

                          case 5:
                            if (m = i.sent(), (g = m.error) && 101155 !== g.code) throw new x(Ee(Le), g);
                            return [ 2, {
                                loginInfo: m,
                                userInfo: s,
                                code: r,
                                uuid: p
                            } ];
                        }
                    });
                })) ];

              case 4:
                m = D.sent(), D.label = 5;

              case 5:
                return g = m.loginInfo, b = m.code, y = m.uuid, k = m.userInfo, _ = g.openId, P = g.unionId, 
                C = g.data, S = g.error, E = {
                    code: b,
                    uuid: y,
                    openId: _,
                    unionId: P,
                    wxUserInfo: null
                }, s || (E.wxUserInfo = k), S ? (n._state(exports.SessionState.BINDING, m), o ? [ 4, N(H.bindRoute + "?" + d.stringify({
                    openId: _
                }), H.bindRoute.substr(1), a, u) ] : [ 2, w({}, E, {
                    error: S
                }) ]) : [ 3, 8 ];

              case 6:
                return D.sent(), wx.hideToast(), [ 4, new Promise(function(e, t) {
                    n.resolve = e;
                }) ];

              case 7:
                return [ 2, D.sent() ];

              case 8:
                return wx.hideToast(), C ? [ 4, he(w({}, E, C)) ] : [ 3, 10 ];

              case 9:
                return [ 2, D.sent() ];

              case 10:
                return [ 3, 12 ];

              case 11:
                return O = D.sent(), [ 2, pe(O) ];

              case 12:
                return [ 2 ];
            }
            var A, L;
        });
    });
};

Me[G.create] = function() {
    var e = xe(exports.API_TYPE.WXV2);
    return e.type === exports.API_TYPE.WXV2 ? e : ce.session = new se(exports.API_TYPE.WXV2, exports.SessionState.AUTH, 6e5);
};

var Ge = Ie.updateWxUserApi, Ke = Ie.getWxUserApi, Ye = function(e) {
    return t = j.appName, n = e || {}, r(void 0, void 0, void 0, function() {
        var e, r, o, s, a, u, c, d, l;
        return i(this, function(i) {
            switch (i.label) {
              case 0:
                return e = n.code, [ 4, I(e) ];

              case 1:
                return r = i.sent(), [ 4, ne({
                    withCredentials: !0
                }) ];

              case 2:
                return o = i.sent(), s = o.rawData, a = o.signature, u = o.iv, c = o.encryptedData, 
                d = {
                    appName: t,
                    code: r,
                    iv: u,
                    encryptedData: c,
                    rawData: s,
                    signature: a
                }, [ 4, D(Ee(Ge), {
                    method: "POST",
                    type: "form",
                    data: d
                }) ];

              case 3:
                if ((l = i.sent()).uniqueid) return [ 2, l ];
                throw new x(Ee(Ge), l.error);
            }
        });
    });
    var t, n;
}, Fe = function e(t) {
    return void 0 === t && (t = {}), r(void 0, void 0, void 0, function() {
        var n, r, o, s;
        return i(this, function(i) {
            switch (i.label) {
              case 0:
                return (n = t.token) ? (r = t.uuid, (o = t.session || e[G.create]()).waitBack = !0, 
                s = H.changeBindPhoneRoute + "?token=" + n + "&uuid=" + r, [ 4, N(s) ]) : (console.error("changeBindPhone方法中token参数是必须的"), 
                [ 2 ]);

              case 1:
                return i.sent(), [ 4, new Promise(function(e, t) {
                    o.resolve = e;
                }) ];

              case 2:
                return [ 2, i.sent() ];
            }
        });
    });
};

Fe[G.create] = function() {
    return de(), xe(exports.API_TYPE.CHANGE_BIND);
};

var Xe = function() {
    function e() {
        var e, t, n, r, i, o;
        this.data = (e = K.title, t = K.wxLoginText, n = K.mobileLoginText, r = K.imageSrc, 
        i = K.imageMode, o = K.imageStyle, {
            API_TYPE: exports.API_TYPE,
            type: exports.API_TYPE.MOBILE,
            title: e,
            wxLoginText: t,
            mobileLoginText: n,
            image: {
                src: r,
                mode: i,
                style: o
            }
        });
    }
    return e.prototype.onLoad = function(e) {
        return r(this, void 0, void 0, function() {
            var t, n;
            return i(this, function(r) {
                switch (r.label) {
                  case 0:
                    return e.type && this.setData({
                        type: e.type
                    }), t = this, (n = e.code) ? [ 3, 2 ] : [ 4, I() ];

                  case 1:
                    n = r.sent(), r.label = 2;

                  case 2:
                    return t.loginCode = n, this.bind = e.bind, this.redirectUrl = e.redirectUrl, [ 2 ];
                }
            });
        });
    }, e.prototype.onReady = function() {
        wx.setNavigationBarTitle({
            title: this.data.title
        });
    }, e.prototype.onShow = function() {
        ce.session && ce.session._emit(exports.SessionEvent.ENTRYPAGEONSHOW, ce.session);
    }, e.prototype.getLoginCode = function() {
        return r(this, void 0, void 0, function() {
            var e;
            return i(this, function(t) {
                switch (t.label) {
                  case 0:
                    return e = this, [ 4, I() ];

                  case 1:
                    return e.loginCode = t.sent(), [ 2 ];
                }
            });
        });
    }, e.prototype.wxMobileLoginClick = function(e) {
        return r(this, void 0, void 0, function() {
            var t, n, r, o;
            return i(this, function(i) {
                switch (i.label) {
                  case 0:
                    return (t = ce.session) && t._emit(exports.SessionEvent.CLICK, exports.API_TYPE.WX_MOBILE), 
                    null == (n = e.detail).iv ? (t && t._emit(exports.SessionEvent.REFUSEPHONE, t), 
                    S(X.refusePhoneNumberAuth), [ 2 ]) : (t && t._emit(exports.SessionEvent.ALLOWPHONE, t), 
                    [ 4, ye("wechat") ]);

                  case 1:
                    return i.sent(), T(X.logining, "loading", 5e3), r = null, t && t.data && (r = t.data.wxUserInfoData), 
                    [ 4, We(n, this.loginCode, this.bind, r, t) ];

                  case 2:
                    return o = i.sent(), wx.hideToast(), o && T(X.loginSuccess), [ 2 ];
                }
            });
        });
    }, e.prototype.mobileLoginClick = function() {
        ce.session && ce.session._emit(exports.SessionEvent.CLICK, ce.session.type);
        var e = this.redirectUrl ? ie.redirectTo : ie.navigateTo;
        Ce(ce.session, e);
    }, e.prototype.wxLoginClick = function(e) {
        ce.session && ce.session._emit(exports.SessionEvent.CLICK, ce.session.type);
        var t = e.detail;
        if (null != t.iv) {
            var n = ce.session, r = n.resolve || function() {
                return new k("Login session destroyed!");
            }, i = this.redirectUrl ? ie.redirectTo : ie.navigateTo;
            Me({
                session: n,
                wxUserInfoData: t,
                slient: !1,
                redirectUrl: this.redirectUrl,
                navType: i
            }).then(r);
        } else S(X.refuseUserInfoAuth);
    }, e;
}(), ze = "http://verify.inf.dev.meituan.com", $e = "https://verify.meituan.com", Je = "dev" === A.env ? ze : $e, Qe = function() {
    return "dev" === R() ? ze : "test" === R() ? "http://verify.inf.test.meituan.com" : $e;
}, Ze = function() {
    return Qe() + "/v2/ext_api/page_data";
}, et = function(e) {
    return Qe() + "/v2/ext_api/" + e + "/info";
}, tt = function(e) {
    return Qe() + "/v2/ext_api/" + e + "/verify";
}, nt = Object.freeze({
    baseUrl: Je,
    getYodaBaseUrl: Qe,
    getPageDataUrl: Ze,
    getInfoUrl: et,
    getVerifyUrl: tt
}), rt = function(e) {
    return D(Ze(), {
        method: "POST",
        data: {
            requestCode: e
        },
        type: "form"
    }).then(function(e) {
        var t = e.status, n = e.error;
        if (0 === t && n) throw new x(Ze(), n, !0);
        return e;
    });
}, it = function(e, t) {
    var n = Object.assign(t, {
        _token: h.r(t)
    });
    return 4 === n.id && (n.moduleEnable = !0), D(et(e), {
        method: "POST",
        data: n,
        type: "form"
    });
}, ot = function(e, t) {
    var n = Object.assign(t, {
        _token: h.r(t)
    }), r = tt(e);
    return D(r, {
        method: "POST",
        data: n,
        type: "form"
    }).then(function(e) {
        var t = e.status, n = e.error;
        if (0 === t && n) throw new x(r, n, !0);
        return e;
    });
}, st = void 0, at = function(e) {
    if (/^1[0-9]\d{9}$/.test(e)) return e;
    throw new k(X.illegalPhoneNumber, 1);
}, ut = function(e, t, o) {
    return r(st, void 0, void 0, function() {
        var r;
        return i(this, function(i) {
            switch (i.label) {
              case 0:
                return a = t, u = (s = e).id, c = s.token, d = n(s, [ "id", "token" ]), r = {
                    type: exports.API_TYPE.MOBILE,
                    userId: u,
                    token: c,
                    mobileUserInfo: d,
                    uuid: a
                }, o && (r.mobile = o), [ 4, be(r) ];

              case 1:
                return i.sent(), [ 2 ];
            }
            var s, a, u, c, d;
        });
    });
}, ct = function(e, t, n, o) {
    return r(st, void 0, void 0, function() {
        var s, a, u, c, d, l, f, p, h, m, g, w, b, y, x, k, _;
        return i(this, function(I) {
            switch (I.label) {
              case 0:
                return s = ce.uuid, a = j.risk_platform, u = j.risk_partner, c = j.version_name, 
                d = j.risk_app, [ 4, (P = {
                    uuid: s,
                    risk_platform: a,
                    risk_partner: u,
                    version_name: c,
                    risk_app: d
                }, C = {
                    responseCode: t,
                    requestCode: e,
                    mobile: n,
                    code: o
                }, r(void 0, void 0, void 0, function() {
                    var e, t, n;
                    return i(this, function(r) {
                        switch (r.label) {
                          case 0:
                            return [ 4, ee((e = P).uuid) ];

                          case 1:
                            return e.uuid = r.sent(), P.sdkVersion = L, t = C, [ 4, Ne() ];

                          case 2:
                            return t.wechatFingerprint = r.sent(), [ 4, D(Ee(He), {
                                method: "post",
                                type: "form",
                                query: P,
                                data: C
                            }) ];

                          case 3:
                            return n = r.sent(), [ 2, {
                                uuid: P.uuid,
                                loginInfo: n
                            } ];
                        }
                    });
                })) ];

              case 1:
                return l = I.sent(), f = l.uuid, p = void 0 === f ? "" : f, h = l.loginInfo, wx.hideToast(), 
                h.error ? (m = h.error, g = m.code, w = m.data, b = m.message, [ 4, S(b) ]) : [ 3, 3 ];

              case 2:
                return I.sent(), 101157 === g && (y = w.param, x = w.userTicket, ae.userTicket = x, 
                ae.mobile = n, k = v.parse(y), _ = k.requestCode, wx.navigateTo({
                    url: H.smsVerifyRoute + "?requestCode=" + _ + "&success=" + H.bindRoute + "&fail=" + H.bindRoute
                })), [ 3, 5 ];

              case 3:
                return [ 4, ut(h.user, p, n) ];

              case 4:
                I.sent(), I.label = 5;

              case 5:
                return [ 2 ];
            }
            var P, C;
        });
    });
}, dt = function(e, t, o, s, a, u, c) {
    return r(st, void 0, void 0, function() {
        var s, d, l, f, p, h, v, m, g, b, y, k, _, I, P, C, S;
        return i(this, function(T) {
            switch (T.label) {
              case 0:
                return s = j.appName, d = j.risk_platform, l = j.risk_partner, f = j.risk_app, p = j.version_name, 
                [ 4, (O = {
                    risk_app: f,
                    version_name: p,
                    appName: s,
                    risk_platform: d,
                    risk_partner: l,
                    requestCode: e,
                    responseCode: t,
                    mobile: o,
                    openId: a,
                    wxUserInfoData: c && c.detail
                }, r(Ae, void 0, void 0, function() {
                    var e, t, r, o, s, a, u, c, d, l, f, p, h, v, m, g;
                    return i(this, function(i) {
                        switch (i.label) {
                          case 0:
                            return e = O.uuid, t = O.wxUserInfoData, r = n(O, [ "uuid", "wxUserInfoData" ]), 
                            (l = te(t)) ? [ 3, 2 ] : [ 4, ne() ];

                          case 1:
                            l = i.sent(), i.label = 2;

                          case 2:
                            return s = (o = l).userInfo, a = o.rawData, u = o.signature, c = o.iv, d = o.encryptedData, 
                            [ 4, Promise.all([ ee(e), Ne() ]) ];

                          case 3:
                            return f = i.sent(), p = f[0], h = f[1], v = w({}, r, {
                                iv: c,
                                encryptedData: d,
                                rawData: a,
                                signature: u,
                                wechatFingerprint: h
                            }), [ 4, De(Ee(Re), p, O, v) ];

                          case 4:
                            if (m = i.sent(), (g = m.error) && 101188 !== g.code) throw new x(Ee(Re), g);
                            return [ 2, {
                                loginInfo: m,
                                userInfo: s,
                                uuid: p
                            } ];
                        }
                    });
                })) ];

              case 1:
                return h = T.sent(), v = h.loginInfo, m = h.userInfo, g = h.uuid, b = v.error, y = Object.assign({
                    openId: a,
                    wxUserInfo: m,
                    uuid: g,
                    type: exports.API_TYPE.WXV2
                }, {
                    code: u
                }), b ? (S = b.data, k = S.userInfos, _ = k[1], I = _.ticket, P = _.userid, [ 4, (E = {
                    ticket: I,
                    userid: P
                }, r(Ae, void 0, void 0, function() {
                    var e, t, n, r;
                    return i(this, function(i) {
                        switch (i.label) {
                          case 0:
                            return [ 4, ee(E.uuid) ];

                          case 1:
                            return e = i.sent(), [ 4, D(Ee(Be), {
                                method: "POST",
                                query: {
                                    uuid: e
                                },
                                type: "form",
                                data: E
                            }) ];

                          case 2:
                            if (t = i.sent(), n = t.error, r = t.data, n) throw new x(Ee(Be), n);
                            if (r) return [ 2, r ];
                            throw new x(Ee(Be));
                        }
                    });
                })) ]) : [ 3, 4 ];

              case 2:
                return C = T.sent(), [ 4, be(Object.assign(y, C)) ];

              case 3:
                return [ 2, T.sent() ];

              case 4:
                return (S = v.data) ? [ 4, be(Object.assign(y, S)) ] : [ 3, 6 ];

              case 5:
                return [ 2, T.sent() ];

              case 6:
                return [ 2 ];
            }
            var E, O;
        });
    });
}, lt = {
    data: {
        configData: Y,
        mobileCode: "",
        phoneNumber: "",
        countdown: {
            limit: 60,
            hidden: !0
        },
        sendCodeBtn: {
            active: !1
        },
        submitBtn: {
            active: !1
        }
    },
    onReady: function() {
        var e = this.data.configData;
        wx.setNavigationBarTitle({
            title: e && e.title || "绑定手机"
        }), this.Slider = this.selectComponent("#slider"), console.log("this.Slider", this.Slider);
    },
    onLoad: function(e) {
        return r(this, void 0, void 0, function() {
            var t, n, o;
            return i(this, function(s) {
                switch (s.label) {
                  case 0:
                    return (t = ce.session) && t.type === exports.API_TYPE.WXV2 && (n = t.data, this.preData = n, 
                    o = this.openId = n.loginInfo.openId, this.setData({
                        openId: o
                    })), console.log("options", e), e && "1" === e.status ? (a = e, r(st, void 0, void 0, function() {
                        var e, t, n, r, o, s, u, c;
                        return i(this, function(i) {
                            switch (i.label) {
                              case 0:
                                if (e = ae.userTicket, t = ae.mobile, n = a.requestCode, r = a.responseCode, !(e && n && r)) return [ 3, 5 ];
                                i.label = 1;

                              case 1:
                                return i.trys.push([ 1, 4, , 5 ]), o = ce.uuid, s = void 0 === o ? "" : o, [ 4, (d = {
                                    requestCode: n,
                                    responseCode: r,
                                    userTicket: e
                                }, D(Ee(Oe), {
                                    method: "POST",
                                    data: d,
                                    type: "form"
                                }).then(function(e) {
                                    if (e.error) throw new x(Ee(Oe), e.error);
                                    return e;
                                })) ];

                              case 2:
                                return u = i.sent().user, [ 4, ut(u, s, t) ];

                              case 3:
                                return i.sent(), [ 3, 5 ];

                              case 4:
                                return c = i.sent(), [ 2, pe(c) ];

                              case 5:
                                return ae.userTicket = "", ae.mobile = "", [ 2 ];
                            }
                            var d;
                        });
                    }), [ 3, 3 ]) : [ 3, 1 ];

                  case 1:
                    return e && "0" === e.status ? (wx.navigateBack({
                        delta: 1
                    }), [ 4, S("" + X.twiceVerifyFail + e.msg + "(" + e.code + ")") ]) : [ 3, 3 ];

                  case 2:
                    s.sent(), s.label = 3;

                  case 3:
                    return [ 2 ];
                }
                var a;
            });
        });
    },
    onShow: function() {
        ce.session && ce.session._emit(exports.SessionEvent.BINDPAGEONSHOW, ce.session);
    },
    phoneInputHandler: function(e) {
        var t = e && e.detail;
        if (t) {
            var n = t.value;
            this.setData({
                phoneNumber: n,
                sendCodeBtn: {
                    active: 11 === n.length
                }
            });
        }
    },
    mobileCodeInputHandler: function(e) {
        var t = e && e.detail;
        if (t) {
            var n = t.value;
            this.setData({
                mobileCode: n,
                submitBtn: {
                    active: 11 === this.data.phoneNumber.length && 6 === n.length
                }
            });
        }
    },
    getLoginCode: function() {
        return r(this, void 0, void 0, function() {
            var e, t, n, r;
            return i(this, function(i) {
                switch (i.label) {
                  case 0:
                    return t = (e = console).log, n = [ "checkSession" ], [ 4, E() ];

                  case 1:
                    return t.apply(e, n.concat([ i.sent() ])), [ 4, E() ];

                  case 2:
                    return i.sent() ? [ 3, 4 ] : (this.updateSessionKey = !0, r = this, [ 4, I() ]);

                  case 3:
                    r.loginCode = i.sent(), i.label = 4;

                  case 4:
                    return [ 2 ];
                }
            });
        });
    },
    sendVerifyCodeClick: function(e) {
        return r(this, void 0, void 0, function() {
            var t, n, r, o;
            return i(this, function(i) {
                switch (i.label) {
                  case 0:
                    if (!this.data.sendCodeBtn.active) return [ 2 ];
                    ce.session && ce.session._emit(exports.SessionEvent.SMSCLICK, ce.session.type), 
                    i.label = 1;

                  case 1:
                    return i.trys.push([ 1, 6, , 7 ]), t = at(this.data.phoneNumber), r = ce, [ 4, ee(j.uuid) ];

                  case 2:
                    return n = r.uuid = i.sent(), this.updateSessionKey ? (this.updateSessionKey = !1, 
                    [ 4, Ye({
                        code: this.loginCode
                    }) ]) : [ 3, 4 ];

                  case 3:
                    i.sent(), i.label = 4;

                  case 4:
                    return [ 4, this.sendVerifyCodeHandler(t, n, e) ];

                  case 5:
                    return i.sent(), [ 3, 7 ];

                  case 6:
                    return o = i.sent(), [ 2, pe(o) ];

                  case 7:
                    return [ 2 ];
                }
            });
        });
    },
    yodaVerifyAndSendCode: function(e, t) {
        return r(this, void 0, void 0, function() {
            var n, r, o, s, a;
            return i(this, function(i) {
                switch (i.label) {
                  case 0:
                    return [ 4, rt(t) ];

                  case 1:
                    return n = i.sent().data, r = this.pageData = n, o = r.action, s = r.type, a = parseInt(s), 
                    isNaN(a) ? (S(X.illegalVerifyType + "(" + s + ")"), [ 2 ]) : (this.extInfoParam = {
                        id: a,
                        request_code: t,
                        fingerprint: "",
                        mobile: "" + e
                    }, [ 4, this.requestExtInfo(o, this.extInfoParam) ]);

                  case 2:
                    return i.sent(), [ 2 ];
                }
            });
        });
    },
    requestExtInfo: function(e, t) {
        return r(this, void 0, void 0, function() {
            var n, r;
            return i(this, function(i) {
                switch (i.label) {
                  case 0:
                    return [ 4, it(e, t) ];

                  case 1:
                    if (1 === (n = i.sent()).status) return this.startCountdown(), [ 2 ];
                    switch ((r = n.error).code) {
                      case 121048:
                        S("暂不支持图片验证");
                        break;

                      case 121060:
                        this.Slider.showSlider({
                            requestCode: r.request_code
                        });
                        break;

                      default:
                        S(r.message);
                    }
                    return [ 2 ];
                }
            });
        });
    },
    onSliderEnd: function(e) {
        return r(this, void 0, void 0, function() {
            var t;
            return i(this, function(n) {
                switch (n.label) {
                  case 0:
                    return 1 !== (t = e.detail.status) ? [ 3, 2 ] : [ 4, this.requestExtInfo(this.pageData.action, this.extInfoParam) ];

                  case 1:
                    return n.sent(), [ 3, 3 ];

                  case 2:
                    0 === t && S("验证失败，请稍后重试"), n.label = 3;

                  case 3:
                    return [ 2 ];
                }
            });
        });
    },
    loginClick: function(e) {
        return r(this, void 0, void 0, function() {
            var t, n, r, o, s, a;
            return i(this, function(i) {
                switch (i.label) {
                  case 0:
                    if (!this.data.submitBtn.active) return [ 2 ];
                    ce.session && ce.session._emit(exports.SessionEvent.LOGINCLICK, ce.session.type), 
                    i.label = 1;

                  case 1:
                    return i.trys.push([ 1, 5, , 6 ]), [ 4, ye("mobile") ];

                  case 2:
                    if (i.sent(), t = this.data.phoneNumber, at(t), n = function(e) {
                        if (/^.{6}$/.test(e)) return e;
                        throw new k(X.illegalSmsCode, 1);
                    }(this.data.mobileCode), !this.extInfoParam || !this.pageData) throw new k(X.loginParamLoss);
                    return T(X.logining, "loading", 1e4), [ 4, ot(this.pageData.action, w({}, this.extInfoParam, {
                        smscode: n
                    })) ];

                  case 3:
                    return r = i.sent(), o = r.data.response_code, s = this.extInfoParam.request_code, 
                    [ 4, this.loginHandler(s, o, t, n, this.openId, this.preData && this.preData.code, e) ];

                  case 4:
                    return i.sent(), [ 3, 6 ];

                  case 5:
                    return a = i.sent(), wx.hideToast(), [ 2, pe(a) ];

                  case 6:
                    return [ 2 ];
                }
            });
        });
    },
    startCountdown: function() {
        var e = this, t = this.data.countdown;
        t.hidden = !1, t.limit = 60;
        var n = function() {
            t.limit--, t.limit < 0 && (t.limit = 60, t.hidden = !0, clearInterval(r)), e.setData({
                countdown: t
            });
        }, r = setInterval(n, 1e3);
        n(), T(X.smsCodeSent);
    }
}, ft = (Object.assign(lt, {
    sendVerifyCodeHandler: function(e, t, n) {
        return r(this, void 0, void 0, function() {
            return i(this, function(o) {
                switch (o.label) {
                  case 0:
                    return this.openId ? [ 4, (Object.assign(lt, {
                        sendVerifyCodeHandler: function(e, t, n) {
                            return r(this, void 0, void 0, function() {
                                var o, s, a, u, c, d, l, f, p;
                                return i(this, function(h) {
                                    switch (h.label) {
                                      case 0:
                                        if (!this.openId) throw new k("null openId for wxlogin");
                                        return o = j.appName, s = j.risk_platform, a = j.risk_partner, u = j.specialRiskCode, 
                                        c = j.risk_smsTemplateId, d = j.risk_smsPrefixId, l = j.version_name, f = j.risk_app, 
                                        [ 4, (v = {
                                            version_name: l,
                                            risk_app: f,
                                            mobile: e,
                                            uuid: t,
                                            openId: this.openId,
                                            appName: o,
                                            wxUserInfoData: n.detail,
                                            risk_platform: s,
                                            risk_partner: a,
                                            specialRiskCode: u,
                                            risk_smsTemplateId: c,
                                            risk_smsPrefixId: d
                                        }, r(Ae, void 0, void 0, function() {
                                            var e, t, n, r, o, s, a, u, c, d, l, f, p, h, m, g;
                                            return i(this, function(i) {
                                                switch (i.label) {
                                                  case 0:
                                                    return e = v.mobile, t = v.openId, n = v.uuid, (c = te(v.wxUserInfoData)) ? [ 3, 2 ] : [ 4, ne({
                                                        withCredentials: !0
                                                    }) ];

                                                  case 1:
                                                    c = i.sent(), i.label = 2;

                                                  case 2:
                                                    return o = (r = c).rawData, s = r.signature, a = r.iv, u = r.encryptedData, [ 4, Promise.all([ ee(n), Ne() ]) ];

                                                  case 3:
                                                    return d = i.sent(), l = d[0], f = d[1], p = {
                                                        openId: t,
                                                        mobile: e,
                                                        iv: a,
                                                        encryptedData: u,
                                                        rawData: o,
                                                        signature: s,
                                                        wechatFingerprint: f
                                                    }, [ 4, De(Ee(qe), l, v, p) ];

                                                  case 4:
                                                    if (h = i.sent(), m = h.error, g = h.data, m) throw new x(Ee(qe), m, !0);
                                                    if (g) return [ 2, g.requestCode ];
                                                    throw new x(Ee(qe));
                                                }
                                            });
                                        })) ];

                                      case 1:
                                        return p = h.sent(), [ 4, lt.yodaVerifyAndSendCode.call(this, e, p) ];

                                      case 2:
                                        return h.sent(), [ 2 ];
                                    }
                                    var v;
                                });
                            });
                        },
                        loginHandler: function() {
                            return dt.apply(this, arguments);
                        }
                    }), lt).sendVerifyCodeHandler.call(this, e, t, n) ] : [ 3, 2 ];

                  case 1:
                    return o.sent(), [ 3, 4 ];

                  case 2:
                    return [ 4, (Object.assign(lt, {
                        sendVerifyCodeHandler: function(e, t) {
                            return r(this, void 0, void 0, function() {
                                var n, o, s, a, u, c, d, l;
                                return i(this, function(f) {
                                    switch (f.label) {
                                      case 0:
                                        return n = j.risk_platform, o = j.risk_partner, s = j.specialRiskCode, a = j.risk_smsTemplateId, 
                                        u = j.risk_smsPrefixId, c = j.risk_app, d = j.version_name, [ 4, (p = {
                                            mobile: e,
                                            uuid: t,
                                            risk_app: c,
                                            risk_platform: n,
                                            risk_partner: o,
                                            specialRiskCode: s,
                                            risk_smsTemplateId: a,
                                            risk_smsPrefixId: u,
                                            version_name: d
                                        }, r(void 0, void 0, void 0, function() {
                                            var e, t, n, r, o, s, a, u, c;
                                            return i(this, function(i) {
                                                switch (i.label) {
                                                  case 0:
                                                    return e = p.mobile, n = void 0 === (t = p.verifyLevel) ? 2 : t, r = p.specialRiskCode, 
                                                    a = {
                                                        uuid: p.uuid,
                                                        risk_app: p.risk_app,
                                                        risk_platform: p.risk_platform,
                                                        risk_partner: p.risk_partner,
                                                        sdkVersion: L,
                                                        risk_smsTemplateId: void 0 === (o = p.risk_smsTemplateId) ? 0 : o,
                                                        risk_smsPrefixId: void 0 === (s = p.risk_smsPrefixId) ? 0 : s,
                                                        version_name: p.version_name
                                                    }, [ 4, Ne() ];

                                                  case 1:
                                                    return u = i.sent(), c = {
                                                        mobile: e,
                                                        verifyLevel: n,
                                                        wechatFingerprint: u
                                                    }, r && (c.specialRiskCode = r), [ 2, D(Ee(je), {
                                                        method: "post",
                                                        type: "form",
                                                        query: a,
                                                        data: c
                                                    }).then(function(e) {
                                                        var t = e.error;
                                                        if (!t) throw new x(Ee(je));
                                                        var n = t.data;
                                                        if (n) return n.requestCode;
                                                        throw new x(Ee(je), t, !0);
                                                    }) ];
                                                }
                                            });
                                        })) ];

                                      case 1:
                                        return l = f.sent(), [ 4, lt.yodaVerifyAndSendCode.call(this, e, l) ];

                                      case 2:
                                        return f.sent(), [ 2 ];
                                    }
                                    var p;
                                });
                            });
                        },
                        loginHandler: function() {
                            return ct.apply(this, arguments);
                        }
                    }), lt).sendVerifyCodeHandler.call(this, e, t) ];

                  case 3:
                    o.sent(), o.label = 4;

                  case 4:
                    return [ 2 ];
                }
            });
        });
    },
    loginHandler: function() {
        return this.openId ? dt.apply(this, arguments) : ct.apply(this, arguments);
    }
}), lt), pt = function(e) {
    return r(void 0, void 0, void 0, function() {
        var t, n, r, o, s, a, u, c, d, l;
        return i(this, function(i) {
            switch (i.label) {
              case 0:
                return t = e.risk_platform, n = e.risk_partner, r = e.risk_app, o = e.token, s = e.uuid, 
                a = e.sdkVersion, u = e.version_name, c = {
                    risk_platform: t,
                    risk_partner: n,
                    risk_app: r,
                    version_name: u,
                    sdkVersion: a
                }, l = {
                    token: o
                }, [ 4, ee(s) ];

              case 1:
                return l.uuid = i.sent(), [ 4, Ne() ];

              case 2:
                return l.wechatFingerprint = i.sent(), d = l, [ 2, D(Ee(Ie.smartCheckApi), {
                    method: "post",
                    type: "form",
                    query: c,
                    data: d
                }).then(function(e) {
                    var t = e.error;
                    if (t.data) return t.data;
                    throw new x(Ee(Ie.smartCheckApi), t, !0);
                }) ];
            }
        });
    });
}, ht = {
    rotateDeg: 20,
    data: {
        title: "更换手机号",
        pageState: "checking",
        checkImage: {
            succSrc: "https://p1.meituan.net/codeman/4425def0f660e5ea550909ad6f9c6f269881.png",
            shieldSrc: "https://p1.meituan.net/codeman/bb9ff1fc8ab8da0f4241399e4f29376c4681.png",
            rotateSrc: "https://p1.meituan.net/codeman/d10f442abb65b5f816ffc98acdd914bd6992.png"
        },
        checkText: "正在进行智能安全检测...",
        canGetNewCode: !1,
        countdown: {
            limit: 60,
            hidden: !0
        },
        focus: !0
    },
    onLoad: function(e) {
        return r(this, void 0, void 0, function() {
            var t, n, r, o, s, a, u, c = this;
            return i(this, function(i) {
                switch (i.label) {
                  case 0:
                    return console.log("changeBindPhoneState", ue), "1" === e.status && e.requestCode && e.responseCode ? (ue.responseCode = e.responseCode, 
                    this.setData({
                        checkText: "您的账户当前处于安全环境，可直接输入要更换的新手机号",
                        pageState: "checkSucc"
                    }), [ 2 ]) : (this.uuid = e.uuid || "", t = wx.createAnimation({
                        duration: 100
                    }), this.animationIntervalId = setInterval(function() {
                        t.rotate(2 * - ++c.rotateDeg).step(), c.setData({
                            animationData: t.export()
                        });
                    }, 10), [ 4, this.changeCheckText("正在检测您的账户环境...") ]);

                  case 1:
                    return i.sent(), [ 4, this.changeCheckText("正在检测当前账号状态...") ];

                  case 2:
                    return i.sent(), r = pt, o = {}, [ 4, this.getToken(e.token || "") ];

                  case 3:
                    return [ 4, r.apply(void 0, [ (o.token = i.sent(), o.risk_partner = j.risk_partner, 
                    o.risk_platform = j.risk_platform, o.risk_app = j.risk_app, o.version_name = j.version_name, 
                    o.sdkVersion = L, o.uuid = this.uuid, o) ]).catch(function(e) {
                        pe(e).then(function() {
                            we();
                        });
                    }) ];

                  case 4:
                    return (n = i.sent()) && (s = n.requestCode, a = n.ticket, ue.ticket = a, s ? (ue.smartRequestCode = s, 
                    wx.redirectTo({
                        url: H.smsVerifyRoute + "?requestCode=" + s + "&success=" + H.changeBindPhoneRoute + "&fail=" + H.changeBindPhoneRoute
                    })) : u = setTimeout(function() {
                        clearTimeout(u), u = null, c.setData({
                            checkText: "您的账户当前处于安全环境，可直接输入要更换的新手机号",
                            pageState: "checkSucc"
                        });
                    }, 500)), [ 2 ];
                }
            });
        });
    },
    onReady: function() {
        wx.setNavigationBarTitle({
            title: this.data.title
        }), this.Slider = this.selectComponent("#slider");
    },
    onShow: function() {
        ce.session && ce.session._emit(exports.SessionEvent.CHANGEPHONEPAGEONSHOW, ce.session);
    },
    getToken: function(e) {
        return r(this, void 0, void 0, function() {
            var t;
            return i(this, function(n) {
                switch (n.label) {
                  case 0:
                    if (e || !j.persistKey) return [ 3, 5 ];
                    t = void 0, n.label = 1;

                  case 1:
                    return n.trys.push([ 1, 3, , 4 ]), [ 4, P(j.persistKey) ];

                  case 2:
                    return t = n.sent(), [ 3, 4 ];

                  case 3:
                    return n.sent(), t = "", [ 3, 4 ];

                  case 4:
                    e = t && t.token || "", n.label = 5;

                  case 5:
                    return [ 2, ue.token = e ];
                }
            });
        });
    },
    clearAnimation: function() {
        this.animationIntervalId && (clearInterval(this.animationIntervalId), this.animationIntervalId = null, 
        this.setData({
            animationData: null
        }));
    },
    changeCheckText: function(e) {
        var t = this;
        return new Promise(function(n, r) {
            var i = setTimeout(function() {
                clearTimeout(i), i = null, t.setData({
                    checkText: e
                }), n(e);
            }, 900);
        });
    },
    onChangePhoneClick: function() {
        this.setData({
            pageState: "changePhone"
        });
    },
    phoneInputHandler: function(e) {
        var t = e && e.detail;
        if (t) {
            var n = t.value;
            this.newPhoneNumber = n, this.setData({
                canGetNewCode: /^1[0-9]\d{9}$/.test(this.newPhoneNumber)
            });
        }
    },
    onGetNewCodeClick: function() {
        return r(this, void 0, void 0, function() {
            return i(this, function(e) {
                return this.data.canGetNewCode && (ce.session && ce.session._emit(exports.SessionEvent.CHANGEPHONEGETNEWCODE, ce.session), 
                this.getNewSmsCode(0)), [ 2 ];
            });
        });
    },
    getNewSmsCode: function(e) {
        return r(this, void 0, void 0, function() {
            var t, n, o = this;
            return i(this, function(s) {
                switch (s.label) {
                  case 0:
                    return [ 4, (a = {
                        mobile: this.newPhoneNumber,
                        token: ue.token || "",
                        requestCode: ue.smartRequestCode,
                        responseCode: ue.responseCode,
                        ticket: ue.ticket || "",
                        confirm: e,
                        uuid: this.uuid
                    }, r(void 0, void 0, void 0, function() {
                        var e, t, n, r, o, s, u, c, d, l, f, p;
                        return i(this, function(i) {
                            switch (i.label) {
                              case 0:
                                return e = a.mobile, n = void 0 === (t = a.countryCode) ? 86 : t, r = a.token, s = void 0 === (o = a.confirm) ? 0 : o, 
                                u = a.requestCode, c = a.ticket, d = a.responseCode, f = {}, [ 4, ee(a.uuid) ];

                              case 1:
                                return f.uuid = i.sent(), l = f, p = {
                                    mobile: e,
                                    countryCode: n,
                                    token: r,
                                    confirm: s,
                                    ticket: c
                                }, u && (p.requestCode = u), u && (p.responseCode = d), [ 2, D(Ee(Ie.sendNewcodeApi), {
                                    method: "post",
                                    type: "form",
                                    query: l,
                                    data: p
                                }).then(function(e) {
                                    console.log("res===>", e);
                                    var t = e.error;
                                    if (t.data) return t.data;
                                    throw new x(Ee(Ie.sendNewcodeApi), t, !0);
                                }) ];
                            }
                        });
                    })).catch(function(e) {
                        e && 101055 === e.code ? S(e.tip, {
                            showCancel: !0
                        }).then(function(e) {
                            if (e) return o.getNewSmsCode(1);
                        }) : pe(e);
                    }) ];

                  case 1:
                    return (t = s.sent()) && (n = t.requestCode, this.getPageData(n)), [ 2 ];
                }
                var a;
            });
        });
    },
    getPageData: function(e) {
        return r(this, void 0, void 0, function() {
            var t, n, r, o, s;
            return i(this, function(i) {
                switch (i.label) {
                  case 0:
                    return i.trys.push([ 0, 3, , 4 ]), [ 4, rt(e) ];

                  case 1:
                    return t = i.sent().data, n = this.pageData = t, r = n.action, o = n.type, this.extInfoParam = {
                        id: parseInt(o),
                        request_code: e,
                        fingerprint: "",
                        mobile: "" + this.newPhoneNumber
                    }, [ 4, this.requestExtInfo(r, this.extInfoParam) ];

                  case 2:
                    return i.sent(), [ 3, 4 ];

                  case 3:
                    return s = i.sent(), pe(s), [ 3, 4 ];

                  case 4:
                    return [ 2 ];
                }
            });
        });
    },
    requestExtInfo: function(e, t) {
        return r(this, void 0, void 0, function() {
            var n, r;
            return i(this, function(i) {
                switch (i.label) {
                  case 0:
                    return [ 4, it(e, t) ];

                  case 1:
                    if (1 === (n = i.sent()).status) return this.setData({
                        pageState: "bindNewPhone"
                    }), this.startCountdown(), [ 2 ];
                    switch ((r = n.error).code) {
                      case 121048:
                        S("暂不支持图片验证");
                        break;

                      case 121060:
                        this.Slider.showSlider({
                            requestCode: r.request_code
                        });
                        break;

                      default:
                        S(r.message);
                    }
                    return [ 2 ];
                }
            });
        });
    },
    onSliderEnd: function(e) {
        return r(this, void 0, void 0, function() {
            var t;
            return i(this, function(n) {
                switch (n.label) {
                  case 0:
                    return 1 !== (t = e.detail.status) ? [ 3, 2 ] : [ 4, this.requestExtInfo(this.pageData.action, this.extInfoParam) ];

                  case 1:
                    return n.sent(), [ 3, 3 ];

                  case 2:
                    0 === t && S("验证失败，请稍后重试"), n.label = 3;

                  case 3:
                    return [ 2 ];
                }
            });
        });
    },
    startCountdown: function() {
        var e = this, t = this.data.countdown;
        t.hidden = !1, t.limit = 60;
        var n = function() {
            t.limit--, t.limit < 0 && (t.limit = 60, t.hidden = !0, clearInterval(r)), e.setData({
                countdown: t
            });
        }, r = setInterval(n, 1e3);
        n(), T("验证码已发送");
    },
    codeInputHandler: function(e) {
        var t = e && e.detail;
        if (t) {
            var n = t.value;
            if (n && 6 === n.length) return void this.verifyNewPhone(n);
        }
    },
    verifyNewPhone: function(e) {
        return r(this, void 0, void 0, function() {
            var t, n, o, s;
            return i(this, function(a) {
                switch (a.label) {
                  case 0:
                    return a.trys.push([ 0, 3, , 4 ]), [ 4, ot(this.pageData.action, w({}, this.extInfoParam, {
                        smscode: e
                    })) ];

                  case 1:
                    return t = a.sent(), n = t.data.response_code, [ 4, (u = {
                        mobile: this.newPhoneNumber,
                        token: ue.token || "",
                        requestCode: this.extInfoParam.request_code,
                        responseCode: n,
                        ticket: ue.ticket || "",
                        risk_partner: j.risk_partner,
                        risk_platform: j.risk_platform,
                        risk_app: j.risk_app,
                        version_name: j.version_name,
                        sdkVersion: L,
                        uuid: this.uuid
                    }, r(void 0, void 0, void 0, function() {
                        var e, t, n, r, o, s, a, c, d, l, f, p, h, v;
                        return i(this, function(i) {
                            switch (i.label) {
                              case 0:
                                return e = u.mobile, t = u.token, n = u.requestCode, r = u.responseCode, o = u.ticket, 
                                s = u.risk_platform, a = u.risk_partner, c = u.risk_app, d = u.version_name, l = u.sdkVersion, 
                                p = {}, [ 4, ee(u.uuid) ];

                              case 1:
                                return p.uuid = i.sent(), p.risk_platform = s, p.risk_partner = a, p.risk_app = c, 
                                p.version_name = d, p.sdkVersion = l, f = p, v = {
                                    mobile: e,
                                    requestCode: n,
                                    token: t,
                                    ticket: o
                                }, [ 4, Ne() ];

                              case 2:
                                return v.wechatFingerprint = i.sent(), h = v, r && (h.responseCode = r), [ 2, D(Ee(Ie.verifyNewApi), {
                                    method: "post",
                                    type: "form",
                                    query: f,
                                    data: h
                                }).then(function(e) {
                                    console.log("res===>", e);
                                    var t = e.data, n = e.error;
                                    if (t) return t;
                                    throw new x(Ee(Ie.sendNewcodeApi), n, !0);
                                }) ];
                            }
                        });
                    })) ];

                  case 2:
                    return o = a.sent(), this.changeComplete(o), [ 3, 4 ];

                  case 3:
                    return s = a.sent(), pe(s), [ 3, 4 ];

                  case 4:
                    return [ 2 ];
                }
                var u;
            });
        });
    },
    changeComplete: function(e) {
        return r(this, void 0, void 0, function() {
            var t;
            return i(this, function(n) {
                switch (n.label) {
                  case 0:
                    return 0 != e.success ? [ 3, 2 ] : [ 4, ve() ];

                  case 1:
                    return (t = n.sent()) && t.token && (t.token = e.token, t.mobile = this.newPhoneNumber, 
                    this.setData({
                        focus: !1
                    }, function() {
                        he(t);
                    })), [ 3, 4 ];

                  case 2:
                    return [ 4, S("换绑失败，请稍后重试") ];

                  case 3:
                    n.sent(), we(), n.label = 4;

                  case 4:
                    return [ 2 ];
                }
            });
        });
    },
    sendVerifyCodeClick: function() {
        this.getNewSmsCode(1);
    }
};

exports.finger = p, exports.yodaConfig = nt, exports.EntryPage = Xe, exports.BindPage = ft, 
exports.changeBind = ht, exports.setAppConfig = function(e) {
    Object.assign(j, e);
}, exports.setSdkRoute = function(e) {
    e.startsWith("/") || (e = "/" + e), H.sdkRoute = e;
}, exports.setBindPageOption = function(e) {
    Object.assign(Y, e);
}, exports.setLoginPageOption = function(e) {
    Object.assign(K, e);
}, exports.setAuthrizePageOption = function(e) {
    Object.assign(F, e);
}, exports.setLoginCheck = function(e) {
    W = e;
}, exports.config = V, exports.mobileLogin = Se, exports.utils = ke, exports.SDKError = k, 
exports.WxAPIError = b, exports.WxRequestError = y, exports.authState = ce, exports.destroySession = de, 
exports.getAuthInfo = ve, exports.removeAuthInfo = me, exports.version = L, exports.login = _e, 
exports.cleanLogin = function(e) {
    return me().then(function() {
        return _e(e);
    });
}, exports.wxMobileLogin = We, exports.wxLogin = Me, exports.updateWxUserInfo = Ye, 
exports.getWxUserInfo = function(e) {
    return r(void 0, void 0, void 0, function() {
        var t;
        return i(this, function(n) {
            switch (n.label) {
              case 0:
                return [ 4, D(Ee(Ke), {
                    method: "GET",
                    data: w({}, e, {
                        thirdType: "weixin"
                    })
                }) ];

              case 1:
                if ((t = n.sent()).uniqueid) return [ 2, t ];
                throw new x(Ee(Ke), t.error);
            }
        });
    });
}, exports.getSdkEnv = q, exports.setEnv = function(e) {
    U.env = e;
}, exports.getEnv = R, exports.changeBindPhone = Fe, exports.logout = function(e, t) {
    if (void 0 === t && (t = j.appName), e) return D(Ee(Ie.logoutUrl), {
        method: "post",
        type: "form",
        data: {
            token: e,
            appName: t
        }
    }).then(function(e) {
        return me(), e.result;
    }).catch(function(e) {
        return console.log(e), me(), !1;
    });
    console.error("token is required");
}, exports.isLogout = function(e, t) {
    return void 0 === t && (t = j.appName), D(Ee(Ie.islogoutUrl), {
        method: "post",
        type: "form",
        data: {
            userId: e,
            appName: t
        }
    }).then(function(e) {
        if (e.error) throw new x(Ee(Ie.islogoutUrl), e.error);
        return e.result;
    }).catch(function(e) {
        console.log(e);
    });
};