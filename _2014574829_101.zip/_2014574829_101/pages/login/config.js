function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var i = require("../../modules/utils/uuid.js"), t = e(require("../../modules/global.js")), n = function() {
    var e = t.default.env;
    return "dev" === e ? "dev" : "test" === e ? "test" : "";
};

console.log("login env: " + n()), module.exports = {
    route: "/pages/login",
    env: n(),
    api: "portm",
    promise: null,
    appConfig: {
        appName: "paotui",
        risk_platform: 13,
        risk_partner: 103,
        persistKey: "sdkLoginInfo",
        uuid: i.uuid
    },
    authrizePageOption: {
        tipText: "",
        imageMode: "aspectFit",
        imageSrc: "https://p0.meituan.net/codeman/1d662d64d96895705a1d0b9433fd0fa8175649.png"
    },
    entryPageOption: {
        title: "微信授权登录",
        imageSrc: "https://p0.meituan.net/codeman/1d662d64d96895705a1d0b9433fd0fa8175649.png",
        imageMode: "aspectFit",
        wxLoginText: "微信用户一键登录",
        mobileLoginText: "手机号码登录/注册"
    },
    bindPageOption: {
        title: "微信授权登录",
        sendCodeActiveStyle: "color: #06C1AE",
        loginActiveStyle: "background: #06C1AE; color: #FFF"
    },
    tips: {
        smsCodeSent: "验证码已发送",
        logining: "登录中...",
        loginSuccess: "登录成功",
        loginParamLoss: "请重新获取验证码！",
        relogin: "您已登录，是否重新登录？",
        refuseUserInfoAuth: "您已拒绝授权用户信息，请重新点击并授权！",
        refusePhoneNumberAuth: "需要允许授权才能继续，请重新点击并授权",
        verifyFailed: "验证失败",
        networkTimeout: "网络连接超时，请重试",
        illegalVerifyType: "验证方式id不合法，请重试或联系客服",
        illegalPhoneNumber: "请输入正确的11位手机号",
        illegalSmsCode: "请输入正确的6位验证码",
        illegalAuthInfo: "获取的授权信息不正确，请重试",
        twiceVerifyFail: "二次验证失败，",
        changeBindFail: "换绑失败，请稍后重试",
        changeBindSucc: "换绑成功！"
    }
};