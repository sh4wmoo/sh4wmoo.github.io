function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function a(i, n) {
                try {
                    var o = t[i](n), s = o.value;
                } catch (e) {
                    return void r(e);
                }
                if (!o.done) return Promise.resolve(s).then(function(e) {
                    a("next", e);
                }, function(e) {
                    a("throw", e);
                });
                e(s);
            }
            return a("next");
        });
    };
}

var r = e(require("../../libs/regenerator-runtime/runtime-module.js")), a = require("../../modules/utils/user.js"), i = require("../../modules/api/route.js"), n = e(require("../../modules/global.js")), o = require("../../modules/api/request.js"), s = require("../../modules/api/urls.js"), d = e(require("../../modules/api/lx.js")), c = require("../../constants.js"), u = require("../../modules/utils/util.js"), l = require("../../modules/utils/share.js"), p = require("../../modules/utils/pay.js"), h = e(require("../../modules/page.js")), f = require("../../modules/api/login"), w = require("../../modules/utils/storage"), v = require("../../modules/utils/reportDetailError"), g = require("../../modules/utils/util"), x = e(require("../../modules/utils/bmMonitor")), b = require("../../modules/api/cat"), m = require("../../modules/utils/subscribeMessage.js"), _ = require("../../modules/utils/abtest.js"), S = !1, I = {
    data: {
        overflow: "auto",
        isShowDelBtn: [],
        orders: {},
        pageFlag: !0,
        currentOrderId: 0,
        showEmptyPage: !1,
        channel: !1,
        actPoint: {
            lng: 0,
            lat: 0
        },
        tipSlide: {
            tipFeeOrderViewId: "",
            orderToken: "",
            show: !1,
            state: -1,
            disableRight: !1,
            slideStatus: "hidden",
            tipTags: [ {
                id: 0,
                text: "不加了"
            }, {
                id: 5,
                text: "¥ 5"
            }, {
                id: 10,
                text: "¥ 10"
            }, {
                id: 15,
                text: "¥ 15"
            }, {
                id: 20,
                text: "¥ 20"
            }, {
                id: 25,
                text: "¥ 25"
            } ],
            tipFee: 0,
            tipFeeMax: 200
        },
        isShowReturnIndexBtn: !1,
        cancelOrderModalShow: !1,
        showModifyOrderInfoEntry: !1,
        cancelCanUrgeGrab: 2
    },
    touchStartX: 0,
    touchStartY: 0,
    onLoad: function(e) {
        var o = this;
        return t(r.default.mark(function t() {
            var s, d, c, u;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    l.getHomeShareData.call(o), s = n.default, e && e.channel && (s.channel = e.channel, 
                    x.default.updateBaseParams({
                        channel: e.channel
                    })), "wx_wmorderlist_miniPrograms" === e.channel && ((0, g.checkLoc)(e.lng) && (0, 
                    g.checkLoc)(e.lat) ? (o.setData({
                        actPoint: {
                            lng: e.lng / 1e6 || 0,
                            lat: e.lat / 1e6 || 0
                        }
                    }), (0, w.setItem)("actPoint", o.data.actPoint)) : (0, v.reportDetailError)("经纬度错误：外卖传入的经纬度错误，channel:" + o.data.channel, e), 
                    o.setData({
                        channel: e.channel
                    }), d = (0, a.getUserInfo)(), c = e.mtuserid, u = e.token, d && u && c && d.userId !== c && (d.userId = c, 
                    d.token = u, (0, w.setItem)("loginInfo", d), (0, f.updateUserInfo)(d).catch(function(e) {
                        console.log(e);
                    }))), (0, i.checkIsFirstPage)() && o.setData({
                        isShowReturnIndexBtn: !0
                    });

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, t, o);
        }))();
    },
    onShow: function() {
        (0, f.checkIsLogin)() ? this._fetchList() : this.loginAndRequest(), d.default.pv("paotui_c_ordlst_sw"), 
        (0, b.reportMetric)("order_list_pv");
    },
    tipFeePreview: function(e, t) {
        var r = {
            orderViewId: e,
            orderToken: t
        };
        return (0, o.postInfo)(s.tipFeePreviewApi, r);
    },
    openTipSlide: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var i, n, c, u, l, p, h, f, w, v, g, x, b, m;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = e.detail || {}, n = i || {}, c = n.orderViewId, u = n.orderStatus, l = n.businessType, 
                    p = {
                        orderViewId: c,
                        orderToken: a.data.tipSlide.orderToken
                    }, a.lxTipSlideCustomData = {
                        order_id: c,
                        order_status: u.value,
                        businessType: l
                    }, d.default.click("b_vhjmju0c", a.lxTipSlideCustomData), t.prev = 5, t.next = 8, 
                    (0, o.postInfo)(s.tipFeePreviewApi, p);

                  case 8:
                    0 === (h = t.sent).code ? (f = h.data || {}, w = f.tipFees, v = f.tipFeeMax, g = f.tipFeeTotal, 
                    x = void 0, b = void 0, h.data && h.data.tipFees ? (b = v - g, x = w.map(function(e) {
                        return {
                            id: e,
                            text: "￥" + e,
                            disabled: e > b
                        };
                    })) : x = a.data.tipSlide.tipTags, m = a.data.tipSlide || {}, m = Object.assign({}, m, {
                        tipTags: x,
                        state: 0,
                        tipFee: a.data.tipSlide.tipFee || x[0].id,
                        tipFeeMax: b,
                        tipFeeTotal: g,
                        orderToken: h.data.orderToken || "",
                        tipFeeOrderViewId: h.data.orderViewId,
                        show: !0,
                        slideStatus: "visible"
                    }), a.setData({
                        tipSlide: m
                    })) : a.handleTipFeePreviewException(h.code, h.message), t.next = 15;
                    break;

                  case 12:
                    t.prev = 12, t.t0 = t.catch(5), a.handleTipFeePreviewException();

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, t, a, [ [ 5, 12 ] ]);
        }))();
    },
    handleTipFeePreviewException: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : -1, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "当前网络异常，请稍后重试";
        switch (e) {
          case 11603:
          case 11604:
            wx.showToast({
                title: t,
                icon: "none"
            }), this._fetchList();
            break;

          default:
            wx.showToast({
                title: t,
                icon: "none"
            });
        }
    },
    handleTipFeeSubmitException: function() {
        arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "当前网络异常，请稍后重试";
        this._fetchList(), wx.showToast({
            title: e,
            icon: "none"
        });
    },
    clickTipCancel: function() {
        this.setData({
            "tipSlide.state": -1,
            "tipSlide.show": !1,
            "tipSlide.slideStatus": "hidden"
        });
    },
    tipConfirm: function(e) {
        this.setData({
            "tipSlide.show": !1,
            "tipSlide.slideStatus": "hidden",
            "tipSlide.state": 1
        }), d.default.click("b_2u6n9160", this.lxTipSlideCustomData || {});
    },
    setTipValue: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var i, n, c, u, l, h;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!a.tipFeeSubmitting) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return a.tipFeeSubmitting = !0, i = e.detail.value, a.setData({
                        "tipSlide.tipFee": i
                    }), n = {
                        orderViewId: a.data.tipSlide.tipFeeOrderViewId,
                        orderToken: a.data.tipSlide.orderToken,
                        tipFee: i,
                        clientType: "wx_app_source"
                    }, t.prev = 6, t.next = 9, (0, o.postInfo)(s.tipFeeSubmitApi, n);

                  case 9:
                    c = t.sent, u = c.code, l = c.message, h = c.data, 0 === u ? (d.default.order("b_xuu6rimp", h.orderViewId, Object.assign({}, a.lxTipSlideCustomData, {
                        order_id: h.orderViewId
                    })), (0, p.ptPay)({
                        orderViewId: h.orderViewId,
                        pay_success_url: "/pages/orderDetail/orderDetail?orderViewId=" + a.data.tipSlide.tipFeeOrderViewId,
                        success: function() {
                            a.toast("小费支付成功，已优先为您通知骑手，请耐心等待"), a._fetchList();
                        }
                    })) : a.handleTipFeeSubmitException(u, l), t.next = 19;
                    break;

                  case 16:
                    t.prev = 16, t.t0 = t.catch(6), a.handleTipFeeSubmitException(-1, "当前网络异常，请稍后重试");

                  case 19:
                    return t.prev = 19, a.tipFeeSubmitting = !1, t.finish(19);

                  case 22:
                  case "end":
                    return t.stop();
                }
            }, t, a, [ [ 6, 16, 19, 22 ] ]);
        }))();
    },
    setTipValueOverflow: function(e) {
        this.setData({
            "tipSlide.disableRight": !e.detail.data.valid
        });
    },
    _fetchList: function() {
        var e = this;
        return t(r.default.mark(function t() {
            var a, i, n;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, o.postInfo)(s.riderShareApi, {});

                  case 3:
                    a = t.sent, i = a.code, n = a.data, 0 === i && e.setData({
                        riderShareCfg: {
                            shareTitle: n.shareTitle,
                            shareIcon: n.shareIcon,
                            shareContent: n.shareContent
                        }
                    }), t.next = 12;
                    break;

                  case 9:
                    t.prev = 9, t.t0 = t.catch(0), console.error(t.t0);

                  case 12:
                    e._init();

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 0, 9 ] ]);
        }))();
    },
    loginAndRequest: function() {
        var e = this;
        return t(r.default.mark(function t() {
            var a;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (a = void 0, S) {
                        t.next = 6;
                        break;
                    }
                    return S = !0, t.next = 5, (0, f.silentLogin)();

                  case 5:
                    a = t.sent;

                  case 6:
                    if (a) {
                        t.next = 10;
                        break;
                    }
                    return t.next = 9, (0, f.ptLogin)();

                  case 9:
                    a = t.sent;

                  case 10:
                    a && e._fetchList();

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t, e);
        }))();
    },
    _init: function() {
        var e = this;
        return (0, o.postInfo)(s.orderList, {
            pageFlag: "",
            pageSize: 25,
            currentOrderId: 0
        }).then(function(t) {
            if (e.error(), 0 === t.code) {
                var r = t.data;
                if (r.resultList && 0 !== r.resultList.length) {
                    var a = [], i = r.resultList;
                    e.setData({
                        orders: i || []
                    }), e.data.orders.forEach(function() {
                        a.push(!1);
                    }), e.setData({
                        isShowDelBtn: a,
                        pageFlag: r.pageFlag || "",
                        currentOrderId: r.currentOrderId || 0
                    }), e._isBottom();
                } else e.setData({
                    showEmptyPage: !0
                });
            } else wx.showToast({
                title: t.message,
                icon: "none"
            });
        }).catch(function(t) {
            var r = e;
            e.error({
                toHandle: function() {
                    r._init();
                }
            });
        });
    },
    onShareAppMessage: function(e) {
        if ("button" === e.from) {
            var t = e.target.dataset, r = t.orderviewid, a = t.sig, i = {
                orderStatus: {
                    value: t.st
                },
                businessType: t.bt,
                orderViewId: r
            };
            return this._lxReport("b_nwytbasv", i), l.shareApp.call(this, {
                type: "button",
                orderViewId: r,
                sig: a
            });
        }
        return l.shareApp.call(this, {
            type: "menu"
        });
    },
    onPullDownRefresh: function() {
        this._init().then(function() {
            wx.stopPullDownRefresh();
        });
    },
    _isBottom: function() {
        var e = wx.createSelectorQuery();
        e.selectViewport().boundingClientRect(), e.select(".orderList").boundingClientRect(), 
        e.exec(function(e) {
            e[0] && e[1] && e[0].height === e[1].bottom && wx.pageScrollTo({
                scrollTop: -e[1].top - 90
            });
        });
    },
    onReachBottom: function() {
        var e = this, t = this.data;
        t.pageFlag && (0, o.postInfo)(s.orderList, {
            pageFlag: t.pageFlag,
            pageSize: 25,
            currentOrderId: this.data.currentOrderId
        }).then(function(t) {
            if (0 === t.code) {
                var r = t.data, a = [];
                e.setData({
                    orders: e.data.orders.concat(r.resultList),
                    pageFlag: r.pageFlag || "",
                    currentOrderId: r.currentOrderId || 0
                }), e.data.orders.forEach(function() {
                    a.push(!1);
                }), e.setData({
                    isShowDelBtn: a
                });
            } else wx.showToast({
                title: t.message,
                icon: "none"
            });
        }).catch(function(e) {
            wx.showToast({
                title: "网络异常",
                icon: "none"
            });
        });
    },
    getTouchStartInfo: function(e) {
        var t = e.touches[0];
        this.touchStartX = t.clientX, this.touchStartY = t.clientY, this.setData({
            overflow: "hidden"
        }), this.data.isShowDelBtn.find(function(e) {
            return !0 === e;
        }) && this.setData({
            isShowDelBtn: this.data.isShowDelBtn.map(function() {
                return !1;
            })
        });
    },
    showDelete: function(e) {
        var t = e.changedTouches[0], r = t.clientX, a = t.clientY, i = e.target.dataset.index, n = this.touchStartX - r > 50 && this.touchStartY - a < 20;
        n && (this.data.isShowDelBtn = this.data.isShowDelBtn.map(function() {
            return !1;
        }), this.data.isShowDelBtn.splice(i, 1, n), this.setData({
            isShowDelBtn: this.data.isShowDelBtn,
            overflow: "auto"
        }));
    },
    handleLongPress: function(e) {
        if (n.default.isAndroid) {
            var t = e.target.dataset.index;
            this.data.orders[t] && this.deleteOrder({
                detail: {
                    index: t,
                    orderViewId: this.data.orders[t].orderViewId,
                    orderStatus: this.data.orders[t].orderStatus
                }
            });
        }
    },
    deleteOrder: function(e) {
        var t = [ 5, 6, 8, 9, 10 ], r = this, a = [ e.detail ], i = a[0], n = a[1], d = void 0 === n ? i.index : n, c = a[2], l = void 0 === c ? i.orderViewId : c, p = a[3], h = void 0 === p ? i.orderStatus.value : p;
        t.includes(h) ? (this._lxReport("b_vjukkaxn", e.detail, "view"), (0, u.ptShowModal)({
            content: "确定要删除该订单吗？",
            confirmText: "删除",
            confirm: function() {
                r._lxReport("b_u7owkpgq", e.detail), (0, o.postInfo)(s.orderDel, {
                    orderid: l
                }).then(function(e) {
                    if (0 === e.code) {
                        var t = r.data;
                        t.isShowDelBtn.splice(d, 1), t.orders.splice(d, 1), r.setData({
                            orders: t.orders,
                            isShowDelBtn: t.isShowDelBtn
                        }), 0 === t.orders.length && r._init();
                    } else wx.showToast({
                        title: e.message,
                        icon: "none"
                    });
                }).catch(function(e) {
                    wx.showToast({
                        title: "网络异常",
                        icon: "none"
                    });
                });
            },
            cancel: function() {
                r._lxReport("b_q8afyg9e", e.detail);
            }
        })) : wx.showToast({
            title: "进行中的订单不能删哦~",
            icon: "none"
        });
    },
    hideDelBtn: function() {
        this.data.isShowDelBtn = this.data.isShowDelBtn.map(function() {
            return !1;
        }), this.setData({
            isShowDelBtn: this.data.isShowDelBtn
        });
    },
    handleCancel: function(e, a) {
        var i = this;
        return t(r.default.mark(function t() {
            var n, d, c;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, m.subscribeOnCancel)({
                        businessType: a.businessType,
                        orderViewId: e
                    });

                  case 3:
                    return t.next = 5, (0, o.postInfo)(s.cancelApi, {
                        orderViewId: e,
                        code: 0,
                        reason: "",
                        orderStatus: (a.orderStatus || {}).value || 0
                    });

                  case 5:
                    if (n = t.sent, d = n.code, c = n.message, 0 !== d) {
                        t.next = 11;
                        break;
                    }
                    i._init(), t.next = 13;
                    break;

                  case 11:
                    return i.handleCancelException(d, c, a), t.abrupt("return", !1);

                  case 13:
                    t.next = 18;
                    break;

                  case 15:
                    t.prev = 15, t.t0 = t.catch(0), i.handleCancelException(-1, "当前网络异常，请稍后重试");

                  case 18:
                  case "end":
                    return t.stop();
                }
            }, t, i, [ [ 0, 15 ] ]);
        }))();
    },
    handleCancelException: function(e, t, r) {
        var a = this;
        if (10337 === e) return this._lxReport("b_bu3wn5vr", r, "view", {
            cancorder_exception_type: e
        }), void (0, u.ptShowModal)({
            title: "提示",
            content: t,
            showCancel: !1,
            confirmText: "我知道了",
            confirm: function() {
                a._init();
            }
        });
        this.toast(t);
    },
    urgeOrder: function() {
        var e = this;
        return t(r.default.mark(function t() {
            var a, i, n, d, c, u, l, p;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.setData({
                        cancelOrderModalShow: !1
                    }), a = e.currentOrder.orderViewId, t.prev = 2, t.next = 5, (0, o.postInfo)(s.urgeOrderApi, {
                        orderId: a
                    });

                  case 5:
                    (i = t.sent) && 0 === i.code && i.data ? (n = i.data, d = n.urgeGrabCode, c = n.urgeGrabTitle, 
                    u = n.urgeGrabTimes, l = n.urgeGrabShowType, p = n.waitGrabTime, 1 === d ? 1 === l && (e.toast(c), 
                    1 === u && e._init()) : 2 === d || 3 === d ? (e.toast(c), e._init()) : 4 === d && e.toast(c), 
                    e._lxReport("b_banma_os807755_mc", e.currentOrder, "click", {
                        is_urge_grab_success: 1 === d ? 1 : 0,
                        urge_grab_pay_time: p,
                        urge_grab_times: u
                    })) : e.toast(i.message || "操作失败，请稍后再试"), t.next = 12;
                    break;

                  case 9:
                    t.prev = 9, t.t0 = t.catch(2), e.toast("操作失败，请稍后再试");

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 2, 9 ] ]);
        }))();
    },
    previewCancelOrder: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var i, n;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if ("B" !== _.globalConfig.testIdMapping.urge_grab) {
                        t.next = 15;
                        break;
                    }
                    return t.prev = 1, t.next = 4, (0, o.postInfo)(s.cancelCanUrgeOrderApi, {
                        orderId: e
                    });

                  case 4:
                    return i = t.sent, n = 2, i && 0 === i.code && i.data && (1 !== i.data.cancelCanUrgeGrab && 2 !== i.data.cancelCanUrgeGrab || (n = i.data.cancelCanUrgeGrab)), 
                    t.abrupt("return", n);

                  case 10:
                    return t.prev = 10, t.t0 = t.catch(1), t.abrupt("return", 2);

                  case 13:
                    t.next = 16;
                    break;

                  case 15:
                    return t.abrupt("return", 2);

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t, a, [ [ 1, 10 ] ]);
        }))();
    },
    cancelOrder: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var n, o, s, d, c, l, p, h, f;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n = e.detail, o = n.orderViewId, s = n.orderStatus, d = n.businessType, c = n.prebook, 
                    l = n.modifyStatus, p = s.value, a._lxReport("paotui_c_ordlst_cnclord_ck", e.detail), 
                    1 != p) {
                        t.next = 8;
                        break;
                    }
                    a._lxReport("b_dix4joth", e.detail, "view"), (0, u.ptShowModal)({
                        content: "确认取消订单吗？",
                        cancelText: "放弃",
                        confirmText: "确定",
                        confirm: function() {
                            return a.handleCancel(o, e.detail);
                        }
                    }), t.next = 22;
                    break;

                  case 8:
                    if (2 != p && 21 != p) {
                        t.next = 21;
                        break;
                    }
                    return h = void 0, h = (2 !== d || 1 !== c) && (1 === l || 3 === l), t.next = 13, 
                    a.previewCancelOrder(o);

                  case 13:
                    f = t.sent, a.setData({
                        cancelCanUrgeGrab: f,
                        cancelOrderModalShow: !0,
                        showModifyOrderInfoEntry: h
                    }), a.currentOrder = e.detail, 1 === f && a._lxReport("b_banma_0gob2wll_mv", e.detail, "view"), 
                    h && a._lxReport("b_banma_1sitp4vy_mv", e.detail, "view"), a._lxReport("b_dix4joth", e.detail, "view"), 
                    t.next = 22;
                    break;

                  case 21:
                    (0, i.navigateTo)({
                        url: "/cancel/pages/cancelOrder/cancelOrder?orderViewId=" + o + "&orderStatus=" + p + "&businessType=" + d
                    });

                  case 22:
                  case "end":
                    return t.stop();
                }
            }, t, a);
        }))();
    },
    payOrder: function(e) {
        var a = this;
        (0, p.ptPay)({
            orderViewId: e.detail.orderViewId,
            pay_success_url: "/pages/orderDetail/orderDetail?orderViewId=" + e.detail.orderViewId,
            success: function() {
                var i = t(r.default.mark(function t() {
                    return r.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return t.next = 2, (0, m.subscribeOnPay)({
                                businessType: e.detail.businessType,
                                orderViewId: e.detail.orderViewId
                            });

                          case 2:
                            self._init();

                          case 3:
                          case "end":
                            return t.stop();
                        }
                    }, t, a);
                }));
                return function() {
                    return i.apply(this, arguments);
                };
            }()
        }), this._lxReport("b_n12nyy2x", e.detail);
    },
    oneMoreOrder: function(e) {
        this._lxReport("paotui_c_ordlst_omrord_ck", e.detail);
        var t = e.detail;
        t.businessType === c.BUSINESS_TYPE_BUY && (0, i.navigateTo)({
            url: "/order/pages/orderBuy/orderBuy?oneMoreOrderId=" + e.detail.orderViewId
        }), t.businessType === c.BUSINESS_TYPE_DELIVERY && (0, i.navigateTo)({
            url: "/order/pages/orderConfirm/orderConfirm?originType=list&oneMoreOrderId=" + e.detail.orderViewId
        });
    },
    commentOrder: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            detail: {}
        }, t = e.detail, r = t.orderViewId, a = t.businessType, n = t.orderStatus.value;
        d.default.click("b_k0ueaqvx", {
            order_id: r,
            businessType: a,
            order_status: n
        }), (0, i.navigateTo)({
            url: "/comment/pages/commentEdit/commentEdit?orderViewId=" + e.detail.orderViewId
        });
    },
    _lxReport: function(e, t) {
        var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "click", a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {}, i = {
            order_status: t.orderStatus.value,
            businessType: t.businessType,
            order_id: t.orderViewId
        };
        d.default[r](e, Object.assign({}, i, a));
    },
    closeCancelOrderModal: function() {
        this.setData({
            cancelOrderModalShow: !1
        }), this._lxReport("b_hc3s4zyt", this.currentOrder);
    },
    cancelOrderConfirm: function() {
        this.setData({
            cancelOrderModalShow: !1
        });
        var e = [ this.currentOrder ], t = e[0], r = e[1], a = void 0 === r ? t.orderViewId : r;
        this.handleCancel(a, t), this._lxReport("b_66g1w4ja", t);
    },
    clickModifyOrderInfo: function() {
        var e = this;
        return t(r.default.mark(function t() {
            var a, n;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = void 0, n = e.currentOrder.orderViewId, t.prev = 2, t.next = 5, (0, o.postInfo)(s.getModifyInfoApi, {
                        orderViewId: n
                    }, {
                        showLoading: !0
                    });

                  case 5:
                    a = t.sent, t.next = 11;
                    break;

                  case 8:
                    t.prev = 8, t.t0 = t.catch(2), e.toast("网络异常");

                  case 11:
                    e.setData({
                        cancelOrderModalShow: !1
                    }), 0 === a.code ? (0, i.navigateTo)({
                        url: "/order/pages/orderModify/orderModify?orderViewId=" + n
                    }) : (0, u.ptShowModal)({
                        content: "订单只能修改一次",
                        showCancel: !1,
                        confirmText: "我知道了",
                        confirm: function() {
                            e._init();
                        }
                    }), e._lxReport("b_banma_1sitp4vy_mc", e.currentOrder);

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 2, 8 ] ]);
        }))();
    },
    returnIndex: function() {
        (0, i.redirectTo)({
            url: "/pages/index/index"
        });
    }
};

(0, h.default)(I);