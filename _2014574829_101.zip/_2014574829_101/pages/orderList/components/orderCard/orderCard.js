!function(e) {
    e && e.__esModule;
}(require("../../../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../../../modules/api/route.js"), t = require("../../../../modules/utils/orderStatus.js"), r = require("../../../../modules/utils/util.js");

Component({
    properties: {
        orderInfo: {
            type: Object,
            value: {},
            observer: function(e) {
                var o = e.orderStatus.value, s = e.businessType, i = (0, t.statusConfig)(s)[o], n = i.operations;
                this.setData({
                    recipientAddress: e.recipientAddress,
                    fetchAddress: e.fetchAddress,
                    orderDate: (0, r.timeFormat)("yyyy-MM-dd", new Date(1e3 * e.orderDate)),
                    nearby: 1 === e.businessTypeTag,
                    orderLabel: e.orderStatus.text,
                    orderStatusColor: i.color,
                    isShowCancleBtn: n && n.isShowCancleBtn || !1,
                    isShowPayBtn: n && n.isShowPayBtn || !1,
                    isShowShareBtn: n && n.isShowShareBtn || !1,
                    isShowTipFeeBtn: n && n.isShowTipFeeBtn || !1,
                    isShowAgainBtn: i.hasAgain || !1,
                    isShowCommentBtn: n && n.isShowCommentBtn && e.canComment || !1
                });
            }
        },
        index: {
            type: Number,
            value: 0
        },
        isShowDelBtn: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e ? this.setData({
                    transform: "transform: translateX(-20%)"
                }) : this.setData({
                    transform: ""
                });
            }
        }
    },
    data: {
        transform: "",
        orderLabel: "",
        orderStatusColor: "",
        isShowCancleBtn: !1,
        isShowPayBtn: !1,
        isShowShareBtn: !1,
        isShowAgainBtn: !1,
        fetchAddress: {},
        recipientAddress: {},
        orderDate: ""
    },
    methods: {
        recover: function() {
            this.setData({
                isShowDelBtn: !1
            });
        },
        cancelOrder: function() {
            this.triggerEvent("cancelorder", this.data.orderInfo);
        },
        pay: function() {
            this.triggerEvent("pay", this.data.orderInfo);
        },
        goToOrderDetail: function() {
            var t = this.data.orderInfo;
            (0, e.navigateTo)({
                url: "/pages/orderDetail/orderDetail?orderViewId=" + t.orderViewId + "&businessType=" + t.businessType + "&orderStatus=" + t.orderStatus.value
            });
        },
        deleteOrder: function(e) {
            var t = this.data.orderInfo;
            this.triggerEvent("deleteorder", Object.assign({
                index: this.properties.index
            }, t), {
                bubbles: !0
            });
        },
        oneMoreOrder: function() {
            this.triggerEvent("onemoreorder", this.data.orderInfo);
        },
        pickTipFee: function() {
            this.triggerEvent("pick-tip-fee", this.data.orderInfo);
        },
        commentOrder: function() {
            this.triggerEvent("commentorder", this.data.orderInfo);
        }
    }
});