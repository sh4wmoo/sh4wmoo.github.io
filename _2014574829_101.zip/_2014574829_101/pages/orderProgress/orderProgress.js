function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var t = require("../../modules/api/route.js"), i = require("../../modules/utils/util.js"), a = require("../../constants.js"), r = require("../../modules/api/urls.js"), s = require("../../modules/utils/share.js"), o = require("../orderDetail/mapPoints.js"), n = e(require("../../modules/page.js")), d = e(require("../../modules/api/lx.js")), l = {
    full: "https://p0.meituan.net/paotui/j81idqpwtro1or.png",
    half: "https://p0.meituan.net/paotui/j81idtsha1nhfr.png",
    empty: "https://p1.meituan.net/paotui/j81ids2giz4cxr.png"
}, u = null, c = 1, h = {
    data: {
        animation: "",
        pageShow: !1,
        orderViewId: "",
        sig: "",
        orderStatus: 0,
        orderStatusMark: "",
        validOrder: !1,
        mapShow: !0,
        fillBlockShow: !1,
        validModalShow: !1,
        inputFocus: !1,
        validStatus: "input",
        errorText: "",
        orderInfo: {
            timeStr: ""
        },
        riderInfo: {
            name: "",
            phone: "",
            score: 1,
            starArr: [],
            tag: ""
        },
        fetchAddress: {
            lng: 0,
            lat: 0
        },
        recipientAddress: {
            lng: 0,
            lat: 0
        },
        riderPoints: {
            lng: 0,
            lat: 0,
            distance: 0
        },
        pickupTime: 0,
        estimateArrivalTime: 0,
        homeText: "去首页",
        markers: [],
        sendMarker: {},
        receiveMarker: {},
        riderMarker: {},
        includePoints: [],
        goodsCode: "",
        needGoodsCode: 0,
        noNeedGoodsCodeDoc: "",
        pickupImages: [],
        statusText: ""
    },
    _filterArr: function(e) {
        return e.filter(function(e) {
            if ("[object Object]" === Object.prototype.toString.call(e)) return e;
        });
    },
    _innerStatus: function(e) {
        var t = 2 === e.businessType && 0 === e.businessTypeTag && "hasAddr", i = 2 === e.businessType && 1 === e.businessTypeTag && "noAddr", a = 1 === e.businessType && e.pickupTime && "order", r = 1 === e.businessType && 0 === e.pickupTime && "now";
        return t || i || a || r;
    },
    _setMap: function(e) {
        var t = this._innerStatus(e), i = e.orderStatus.value, a = (0, o.mapPoints)(e), r = this._filterArr(a[i][t].points);
        this.setData({
            markers: this._filterArr(a[i][t].markers)
        }), this.mapDetail.includePoints({
            padding: [ 100, 100, 100, 100 ],
            points: r
        });
    },
    initPage: function(e) {
        var t = e.orderView || {}, i = e.orderTraceConfig;
        this.setData({
            orderStatus: t.orderStatus && t.orderStatus.value || 0,
            validOrder: e.expiry || !1,
            hasRiderInfo: !!t.rider && !t.rider.expired,
            riderInfo: {
                name: t.rider && t.rider.name || "-",
                phone: "",
                score: t.rider && parseInt(100 * t.rider.satisfactionRatio),
                star: t.rider && t.rider.star || 0,
                starArr: [],
                tag: t.rider && t.rider.tag || ""
            },
            fetchAddress: {
                lng: t.fetchAddress && t.fetchAddress.lng || 0,
                lat: t.fetchAddress && t.fetchAddress.lat || 0
            },
            recipientAddress: {
                lng: t.recipientAddress && t.recipientAddress.lng || 0,
                lat: t.recipientAddress && t.recipientAddress.lat || 0
            },
            riderPoints: {
                lng: t.latestRiderPoint && t.latestRiderPoint.lng || 0,
                lat: t.latestRiderPoint && t.latestRiderPoint.lat || 0,
                distance: t.latestRiderPoint && t.latestRiderPoint.distance || 0
            },
            pickupTime: 1e3 * Number(t.pickupTime) || 0,
            estimateArrivalTime: 1e3 * Number(t.estimateArrivalTime) || 0,
            homeText: i && i.homeText || "去首页",
            goodsCode: t.goodsCode || "",
            needGoodsCode: t.needGoodsCode || 0,
            noNeedGoodsCodeDoc: t.noNeedGoodsCodeDoc || ""
        }), 4 === this.data.orderStatus && this.setData({
            pickupImages: (t.pickupImages || "").toString().replace(/[[\]]/g, "").replace(/"/g, "").split(",")
        }), this.orderStatusMarkSetting(this.data.orderStatus, this.data.validOrder), "expired" === this.data.orderStatusMark ? this.setData({
            statusText: "订单信息已过期"
        }) : this.setData({
            statusText: t.orderStatus && t.orderStatus.text || ""
        }), this.orderInfoSetting(), this.starPicHandle(this.data.riderInfo.star), "picking" !== this.data.orderStatusMark && "sending" !== this.data.orderStatusMark && "reject" !== this.data.orderStatusMark || (this.mapDetail = this.mapDetail || wx.createMapContext("mapDetail"), 
        this.setData({
            mapShow: !1
        }), this._setMap(t), this.setData({
            mapShow: !0
        }));
    },
    getData: function(e) {
        var t = this, i = {
            orderViewId: this.data.orderViewId,
            sig: this.data.sig
        };
        return void 0 !== this.sigVersion && (i.sigVersion = this.sigVersion), new Promise(function(a, s) {
            wx.showNavigationBarLoading(), wx.request({
                url: r.riderTraceApi,
                method: "POST",
                header: {
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                },
                data: i,
                success: function(i) {
                    t.setData({
                        pageShow: !0,
                        mapShow: !0
                    }), t.error(), wx.hideNavigationBarLoading(), a(i);
                    var r = i.data;
                    if (r && 0 === r.code) {
                        var s = r.data;
                        t.initPage(s), e && e("位置信息已更新");
                    } else e ? e("刷新失败，请重试") : (t.setData({
                        mapShow: !1
                    }), t.error({
                        message: r.message || "请求出错，请稍后重试",
                        toHandle: function() {
                            t.getData();
                        }
                    }));
                },
                fail: function(e) {
                    t.setData({
                        pageShow: !0,
                        mapShow: !1
                    }), wx.hideNavigationBarLoading(), s(e), t.error({
                        message: "当前网络异常，请稍后重试",
                        toHandle: function() {
                            t.getData();
                        }
                    });
                }
            });
        });
    },
    orderStatusMarkSetting: function(e, t) {
        var i = this, a = "";
        t ? a = "expired" : 3 === e ? a = "picking" : 4 === e ? a = "sending" : 5 === e ? a = "done" : [ 6, 7, 8, 9, 10, 61 ].indexOf(e) > -1 ? a = "cancel" : 62 === e || 64 === e ? a = "reject" : this.error({
            message: "未能获得骑手信息，请稍后再试",
            toHandle: function() {
                i.getData();
            }
        }), this.setData({
            orderStatusMark: a
        }), this.lxHandle("pv", "c_z392ilsc"), "expired" !== a && this.data.hasRiderInfo && this.lxHandle("view", "b_x1s1wnc6"), 
        "done" !== a && "cancel" !== a && "expired" !== a || this.lxHandle("view", "b_edf03m3l");
    },
    orderInfoSetting: function() {
        var e = {
            timeStr: ""
        };
        e.timeStr = (0, i.timeToDate)(this.data.estimateArrivalTime), this.setData({
            orderInfo: {
                timeStr: e.timeStr
            }
        });
    },
    contactService: function() {
        this.lxHandle("click", "b_w9m6tvw2"), wx.makePhoneCall({
            phoneNumber: a.SERVICE_PHONE
        });
    },
    showValidModal: function() {
        var e = this;
        this.lxHandle("click", "b_7knlgxn3");
        var t = this.data.orderStatusMark;
        "picking" === t || "sending" === t || "reject" === t ? (this.setData({
            fillBlockShow: !0
        }), wx.createSelectorQuery().select(".fill-block").boundingClientRect(function(t) {
            wx.pageScrollTo({
                scrollTop: t.height,
                duration: 300
            }), e.setData({
                validModalShow: !0,
                inputFocus: !0,
                validStatus: "input",
                errorText: ""
            }), e.lxHandle("view", "b_h4dgw0w0");
        }).exec()) : (this.setData({
            validModalShow: !0,
            inputFocus: !0
        }), this.lxHandle("view", "b_h4dgw0w0")), this.lxHandle("view", "b_h4dgw0w0");
    },
    validPhone: function(e) {
        var t = this;
        this.setData({
            validStatus: "validing",
            errorText: ""
        });
        var i = {
            orderViewId: this.data.orderViewId,
            recipientPhone: e.detail.phoneNumber,
            sig: this.data.sig
        };
        void 0 !== this.sigVersion && (i.sigVersion = this.sigVersion), wx.request({
            url: r.riderPhoneApi,
            method: "POST",
            header: {
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
            },
            data: i,
            success: function(e) {
                var i = e.data;
                i && 0 === i.code ? (t.checkResult("success"), t.setData({
                    validStatus: "success",
                    inputFocus: !1
                }), i.data && i.data.phone ? setTimeout(function() {
                    t.closeValidModal(), wx.makePhoneCall({
                        phoneNumber: i.data.phone
                    });
                }, 0) : wx.showToast({
                    icon: "none",
                    title: "接口没返回骑手号码"
                })) : (t.checkResult("fail"), t.setData({
                    validStatus: "wrong",
                    inputFocus: !0,
                    errorText: i.message
                }));
            },
            fail: function() {
                t.setData({
                    validStatus: "wrong",
                    inputFocus: !0,
                    errorText: "当前网络异常，请稍后重试"
                });
            }
        });
    },
    lxHandle: function(e, t, i) {
        var a = {
            picking: 0,
            sending: 1,
            done: 2,
            cancel: 3,
            expired: 4
        }, r = this.data.orderStatusMark;
        d.default[e](t, Object.assign({}, {
            page_status: a[r] || ""
        }, i || {}));
    },
    goHomePage: function() {
        this.lxHandle("click", "b_ddtwmxgs"), (0, t.redirectTo)({
            url: "/pages/index/index?channel=wx_miniProgramsShare"
        });
    },
    closeValidModal: function() {
        var e = this;
        this.setData({
            validModalShow: !1,
            fillBlockShow: !1,
            inputFocus: !1
        });
        var t = this.data.orderStatusMark;
        "picking" !== t && "sending" !== t && "reject" !== t || wx.pageScrollTo({
            scrollTop: 0,
            duration: 300
        }), setTimeout(function() {
            e.setData({
                inputFocus: !1
            });
        }, 400);
    },
    checkResult: function(e) {
        this.lxHandle("click", "b_pukfjk5v", {
            phoneverify_result: "success" === e ? 0 : 1
        });
    },
    starPicHandle: function(e) {
        for (var t = [], i = 0; i < 5; i++) t[i] = e <= 0 ? l.empty : e - 1 < 0 ? l.half : l.full, 
        e--;
        this.setData({
            "riderInfo.starArr": t
        });
    },
    reloadData: function() {
        this.getData(function(e) {
            wx.showToast({
                icon: "none",
                title: e
            });
        }), u.rotate(180 * c).step(), this.setData({
            animation: u.export()
        }), c++;
    },
    onLoad: function(e) {
        this.setData({
            orderViewId: e.orderViewId || "",
            sig: e.sig || ""
        }), void 0 !== e.sigVersion && (this.sigVersion = e.sigVersion);
    },
    onReady: function() {},
    onShow: function() {
        this.getData(), u = wx.createAnimation({
            duration: 1e3,
            timingFunction: "linear",
            delay: 0,
            transformOrigin: "50% 50% 0",
            success: function(e) {}
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.getData().then(function() {
            wx.stopPullDownRefresh();
        });
    },
    onShareAppMessage: function() {
        return s.shareApp.call(this, {
            type: "button",
            orderViewId: this.data.orderViewId,
            sig: this.data.sig
        });
    }
};

(0, n.default)(h);