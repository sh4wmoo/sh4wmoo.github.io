function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return {
        state: {
            actualLocation: {
                lat: 0,
                lng: 0
            },
            actPoint: {
                lat: 0,
                lng: 0
            },
            sendAddress: {
                lat: 0,
                lng: 0
            },
            receiveAddress: {
                lat: 0,
                lng: 0
            },
            addressHasChanged: !1,
            pageMode: "delivery"
        },
        computed: {
            mapPoint: function() {
                var e = this.state.actPoint, t = (0, a.getItem)("actPoint"), r = this.state.sendAddress, n = {
                    lat: 39.908821,
                    lng: 116.397469
                };
                return "delivery" === this.state.pageMode ? r.lng && r.lat ? Object.assign(n, {
                    lat: r.lat,
                    lng: r.lng
                }) : e.lng && e.lat ? Object.assign(n, e) : t.lng && t.lat && Object.assign(n, t) : t.lng && t.lat && Object.assign(n, t), 
                n;
            }
        },
        actions: {
            wxLocation: function(e) {
                e.state;
                return (0, r.getLocation)().then(function(e) {
                    if (e.latitude && e.longitude) return t.default.actualLocation = {
                        lat: (0, s.locFormat)(e.latitude, !0),
                        lng: (0, s.locFormat)(e.longitude, !0)
                    }, Promise.resolve({
                        actualLocation: {
                            lat: e.latitude,
                            lng: e.longitude
                        }
                    });
                    (0, n.reportDetailJsError)("index-store-wxLocation", e, "warn");
                });
            },
            updateActPoint: function(e) {
                e.state;
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                    lat: 39.908821,
                    lng: 116.397469
                };
                return (0, a.setItem)("actPoint", t), {
                    actPoint: t
                };
            },
            cityToActPoint: function(e, t) {
                e.state;
                var r = "北京" === t ? "北京市天安门" : t + "市政府";
                return new Promise(function(e, s) {
                    d.default.geocoder({
                        address: r,
                        success: function(r) {
                            if (!r.status && r.result && r.result.location) {
                                var a = r.result.location;
                                e({
                                    actPoint: {
                                        lat: a.lat,
                                        lng: a.lng
                                    }
                                });
                            } else "北京" === t ? e({
                                actPoint: {
                                    lat: 39.908821,
                                    lng: 116.397469
                                }
                            }) : s(r.message), (0, n.reportDetailJsError)("腾讯地图sdk获取城市中心经纬度错误", {
                                cityName: t,
                                res: r
                            });
                        },
                        fail: function(r) {
                            "北京" === t ? e({
                                actPoint: {
                                    lat: 39.908821,
                                    lng: 116.397469
                                }
                            }) : s("切换城市失败，请您稍后重试"), (0, n.reportDetailJsError)("腾讯地图sdk获取城市中心经纬度失败", {
                                cityName: t,
                                error: r
                            });
                        }
                    });
                });
            },
            getCenterLocation: function(e, t) {
                e.state;
                return new Promise(function(e, r) {
                    t.getCenterLocation({
                        success: function(t) {
                            var n = t.latitude, s = t.longitude;
                            n && s ? ((0, a.setItem)("actPoint", {
                                lat: n,
                                lng: s
                            }), e({
                                actPoint: {
                                    lat: n,
                                    lng: s
                                }
                            })) : r("经纬度错误：获取地图组件中心点参数错误");
                        },
                        fail: function(e) {
                            r("经纬度错误：获取地图组件中心点参数失败");
                        }
                    });
                });
            },
            changeAddr: function(e, t) {
                e.state;
                var r = t.data || {};
                return 1 === t.addressType ? {
                    sendAddress: r
                } : 2 === t.addressType ? {
                    receiveAddress: r
                } : void 0;
            },
            changePageMode: function(e, t) {
                e.state;
                return {
                    pageMode: t
                };
            },
            addrListDelete: function(e, t) {
                var r = e.state, n = t.id, s = !1;
                return n === r.sendAddress.id ? (n === (0, a.getItem)("sendAddr").id && (s = !0, 
                (0, a.removeItem)("sendAddr")), {
                    addressHasChanged: s,
                    sendAddress: {}
                }) : n === r.receiveAddress.id ? (n === (0, a.getItem)("receiveAddr").id && (s = !0, 
                (0, a.removeItem)("receiveAddr")), {
                    addressHasChanged: s,
                    receiveAddress: {}
                }) : void 0;
            },
            clearAddress: function(e) {
                e.state;
                return arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                    sendAddress: {},
                    receiveAddress: {}
                };
            },
            tapRecommendAddress: function(e, t) {
                e.state;
                return (0, a.setItem)("sendAddr", t), {
                    sendAddress: t
                };
            }
        }
    };
};

e(require("../../libs/regenerator-runtime/runtime-module.js"));

var t = e(require("../../modules/global.js")), r = require("../../modules/api/wx.js"), n = require("../../modules/utils/reportDetailError"), s = require("../../modules/utils/util.js"), a = require("../../modules/utils/storage"), d = e(require("../../modules/utils/map.js"));