function t(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, r) {
            function n(a, i) {
                try {
                    var o = e[a](i), u = o.value;
                } catch (t) {
                    return void r(t);
                }
                if (!o.done) return Promise.resolve(u).then(function(t) {
                    n("next", t);
                }, function(t) {
                    n("throw", t);
                });
                t(u);
            }
            return n("next");
        });
    };
}

function e(t) {
    return (t = t || "").length > 4 ? t.substr(0, 3) + "..." : t;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.initIndexLocation = void 0, exports.cutCityName = e;

var r = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../libs/regenerator-runtime/runtime-module.js")), n = (exports.initIndexLocation = function() {
    var a = t(r.default.mark(function t(a, i) {
        var o, u, c, s = this;
        return r.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.prev = 0, t.next = 3, n(a, i);

              case 3:
                o = t.sent, u = o.lat, c = o.lng, this.reverseCity(u, c).then(function(t) {
                    s.setData({
                        cityName: t,
                        userCityName: t,
                        cityNameDisplayed: e(t)
                    });
                }), this.setData({
                    scale: 16
                }), a.dispatch("updateActPoint", {
                    lat: u,
                    lng: c
                }), t.next = 17;
                break;

              case 11:
                return t.prev = 11, t.t0 = t.catch(0), this.getCenterLocationAndUpdate(), this.pageMetricsHandler && this.pageMetricsHandler.end(), 
                t.next = 17, this.showLocationAuthModalIfNeeded();

              case 17:
              case "end":
                return t.stop();
            }
        }, t, this, [ [ 0, 11 ] ]);
    }));
    return function(t, e) {
        return a.apply(this, arguments);
    };
}(), function() {
    var e = t(r.default.mark(function t(e, n) {
        var a;
        return r.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if (a = void 0, t.prev = 1, n || !e.actPoint.lat) {
                    t.next = 6;
                    break;
                }
                a = e.actPoint, t.next = 9;
                break;

              case 6:
                return t.next = 8, e.dispatch("wxLocation");

              case 8:
                a = e.actualLocation;

              case 9:
                t.next = 14;
                break;

              case 11:
                return t.prev = 11, t.t0 = t.catch(1), t.abrupt("return", Promise.reject(new Error("get location error")));

              case 14:
                return t.abrupt("return", Promise.resolve({
                    lat: a.lat,
                    lng: a.lng
                }));

              case 15:
              case "end":
                return t.stop();
            }
        }, t, void 0, [ [ 1, 11 ] ]);
    }));
    return function(t, r) {
        return e.apply(this, arguments);
    };
}());