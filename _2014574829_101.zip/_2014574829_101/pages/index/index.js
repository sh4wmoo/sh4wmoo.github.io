function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, a) {
            function r(n, i) {
                try {
                    var s = t[n](i), o = s.value;
                } catch (e) {
                    return void a(e);
                }
                if (!s.done) return Promise.resolve(o).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(o);
            }
            return r("next");
        });
    };
}

var a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, r = e(require("../../libs/regenerator-runtime/runtime-module.js")), n = require("../../modules/utils/user.js"), i = require("../../modules/api/route.js"), s = e(require("../../modules/global.js")), o = require("../../constants.js"), d = require("../../modules/api/urls.js"), c = require("../../modules/utils/share.js"), u = require("../../modules/api/wx.js"), l = require("../../modules/utils/util.js"), p = require("../../modules/api/login"), g = require("../../modules/api/request.js"), h = require("../../modules/utils/storage"), f = e(require("../../modules/api/lx.js")), m = e(require("../../modules/page.js")), v = e(require("../../modules/utils/debounce.js")), y = require("../../modules/utils/reportDetailError"), b = require("../../modules/utils/waitQueue.js"), k = require("../../modules/utils/goodsValue"), A = e(require("./storeConfig")), x = e(require("../../modules/utils/store")), w = e(require("../../modules/utils/bmMonitor.js")), I = require("../../modules/api/cat.js"), P = require("../../modules/api/metrics.js"), T = e(require("../../modules/utils/map.js")), D = require("../../modules/utils/abtest.js"), C = require("./location.js"), _ = e(require("../../modules/utils/mafMap.js")), M = e(require("../../modules/utils/mafSwitchRequest.js")), L = require("../../modules/utils/getCityAndDistrict.js"), S = "function" == typeof Symbol && "symbol" === a(Symbol.iterator) ? function(e) {
    return void 0 === e ? "undefined" : a(e);
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : a(e);
}, F = new b.WaitQueue(), O = null, N = !1;

(0, m.default)({
    data: {
        isIpx: s.default.isIpx,
        cityName: "",
        cityNameDisplayed: "",
        userCityName: "",
        scale: 16,
        markers: [],
        nearbyRiderPointList: [],
        ongoingOrderIds: [],
        waitForPaidOrderIds: [],
        pinText: "",
        pinTextVisible: !0,
        recommendAddress: {},
        showRecommendAddress: !0,
        goodsInfoText: "",
        goodsInfo: {},
        deliveryOrderToken: "",
        deliveryBindPhone: "",
        sendAddressErrorTip: "",
        receiveAddressErrorTip: "",
        hasAddressError: !1,
        buyTabBadge: "",
        buyEditingDescription: "",
        buyDescription: "",
        buyEditTip: "",
        buyInputTip: "",
        buyInputFocus: !1,
        buyCategories: [],
        buyCategorySelected: null,
        buyFullWindow: !1,
        couponModalVisible: !1,
        couponModalStyle: "",
        couponLayerStyle: "display: none",
        couponList: [],
        couponBanner: "",
        couponStyle: {
            homeButtonBg: "FFCE65",
            homeButtonText: "进入首页",
            homeButtonTextBg: "333333",
            popupBg: "F30025"
        },
        locationAuthModalVisible: !1,
        locationAuthModalSlotOption: {
            body: !0,
            footer: !0
        },
        canUseOpenSetting: !0,
        showInvite: !1,
        inviteIconUrl: "",
        fullWindowBuyEditing: !1,
        modalMarketingVisible: !1,
        modalMarketing: null,
        modalMarketingOption: {
            body: !0,
            footer: !0
        },
        suspendMarketing: null,
        topMarketing: null,
        isAddressDegrade: !1,
        nearPoiAddress: null,
        nearPoiWarn: !1,
        noNearPoi: !1,
        isLogin: !1,
        mapPoint: {
            lat: 39.908821,
            lng: 116.397469
        },
        certificationTestStrategy: "",
        certificationFlag: 0
    },
    deliveryCategories: null,
    pageMetricsHandler: null,
    lxTappedBuyTags: [],
    onLoad: function(e) {
        var t = this;
        this.pageMetricsHandler = (0, P.startMetricsPagePoint)(this, "index_page_load_full", {
            num: 4
        }), (O = new x.default((0, A.default)())).mapSetData(this, [ "actPoint", "sendAddress", "receiveAddress", "pageMode" ]), 
        O.mapComputed(this);
        var a = s.default;
        if (e.channel && (a.channel = e.channel, w.default.updateBaseParams({
            channel: e.channel
        })), "wx_wmjg_miniPrograms" === e.channel || "wx_wmmidbanner_miniPrograms" === e.channel) {
            if ((0, l.checkLoc)(e.lat) && (0, l.checkLoc)(e.lng)) {
                var r = {
                    lat: e.lat / 1e6,
                    lng: e.lng / 1e6
                };
                O.dispatch("updateActPoint", r);
            } else (0, y.reportDetailJsError)("经纬度错误：外卖传入的经纬度错误，channel:" + a.channel, O.actPoint);
            var i = (0, n.getUserInfo)(), d = e.mtuserid, u = e.token;
            i && u && d && i.userId !== d && (i.userId = d, i.token = u, (0, h.setItem)("loginInfo", i), 
            (0, p.updateUserInfo)(i).catch(function(e) {
                console.log(e);
            }));
        } else if ("wx_wmorderlist_miniPrograms" === e.channel) {
            var g = (0, h.getItem)("actPoint") || {};
            if ((0, l.checkLoc)(g.lat) && (0, l.checkLoc)(g.lng)) {
                var f = {
                    lat: f.lat,
                    lng: f.lng
                };
                O.dispatch("updateActPoint", f);
            }
        }
        (0, h.getItem)("actPoint") || (N = !0, O.dispatch("updateActPoint", {
            lat: 39.908821,
            lng: 116.397469
        })), e.channel_activity_id && (a.channel_activity_id = e.channel_activity_id), this.mapSDK = T.default, 
        c.getHomeShareData.call(this), this.firstLoad = !0, this.on("goodsInfo.save", function(e) {
            var a = e.data || {};
            t.updateGoodsInfo(a.goodsType, a.goodsTypeName, a.goodsWeight, a.minGoodsValue, a.maxGoodsValue), 
            e.refer === o.GOODS_INFO_REFER_INDEX && t.data.goodsInfo.goodsType && void 0 !== O.sendAddress.id && void 0 !== O.receiveAddress.id && t.navigateTo("delivery-order-edit");
        }), this.on("addrEdit.save", function(e) {
            "delivery-order-edit" !== t.lastPage && "buy-order-edit" !== t.lastPage && t.changeAddr(e);
        }), this.on("addrList.select", function(e) {
            "delivery-order-edit" !== t.lastPage && "buy-order-edit" !== t.lastPage && t.changeAddr(e);
        }), this.on("switchAccount.switch", function() {
            t.clearAddress();
        }, this), this.on("addrList.delete", function(e) {
            var a = e.data.deletedAddr;
            O.dispatch("addrListDelete", a), O.addressHasChanged && t.onDeliveryFormChange();
        }, this), this.pageMetricsHandler && this.pageMetricsHandler.add({
            step: "params_init_finish"
        });
    },
    onShow: function() {
        var e = t(r.default.mark(function e() {
            var t, a = this;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return this.setDataAsync({
                        isLogin: (0, p.checkIsLogin)()
                    }), this.myMap = wx.createMapContext("homeMap"), e.next = 4, D.configPromise;

                  case 4:
                    if (e.prev = 4, !this.firstLoad) {
                        e.next = 10;
                        break;
                    }
                    this.renderFirstLoad(), this.firstLoad = !1, e.next = 32;
                    break;

                  case 10:
                    if (this.lastPage && !([ "user-center", "order-detail", "order-list" ].indexOf(this.lastPage) > -1)) {
                        e.next = 15;
                        break;
                    }
                    this.updateIndexPage(), (0, p.checkIsLogin)() ? this.showFallingCoupons().then(function() {
                        a.requestAndShowMarketingInfo();
                    }) : this.requestAndShowMarketingInfo(), e.next = 32;
                    break;

                  case 15:
                    if ("city-list" !== this.lastPage) {
                        e.next = 31;
                        break;
                    }
                    if (t = (0, h.getItem)("cityData"), (0, h.removeItem)("cityData"), !t.name || t.name === this.data.cityName) {
                        e.next = 29;
                        break;
                    }
                    return e.prev = 19, e.next = 22, this.changeCity(t.name);

                  case 22:
                    this.updateMapArea({
                        nearbyRiderPointList: this.data.nearbyRiderPointList,
                        ongoingOrderIds: this.data.ongoingOrderIds,
                        waitForPaidOrderIds: this.data.waitForPaidOrderIds,
                        bubbleText: ""
                    }), this.updateIndexPage(), e.next = 29;
                    break;

                  case 26:
                    e.prev = 26, e.t0 = e.catch(19), this.toast(e.t0);

                  case 29:
                    e.next = 32;
                    break;

                  case 31:
                    "delivery-order-edit" === this.lastPage ? (O.dispatch("clearAddress"), this.setData({
                        markers: [],
                        scale: 16,
                        recommendAddress: {},
                        deliveryOrderToken: "",
                        deliveryBindPhone: ""
                    }), this.reverseCity(O.actPoint.lat, O.actPoint.lng).then(function(e) {
                        return a.setData({
                            cityName: e,
                            cityNameDisplayed: (0, C.cutCityName)(e)
                        });
                    }), this.updateMapArea({
                        nearbyRiderPointList: this.data.nearbyRiderPointList,
                        ongoingOrderIds: this.data.ongoingOrderIds,
                        waitForPaidOrderIds: this.data.waitForPaidOrderIds,
                        bubbleText: ""
                    }), this.updateIndexPage()) : "buy-order-edit" === this.lastPage && (O.dispatch("clearAddress"), 
                    this.setData({
                        buyFullWindow: !1,
                        buyEditingDescription: "",
                        buyDescription: ""
                    }), this.lxTappedBuyTags = [], this.updateIndexPage());

                  case 32:
                    e.next = 37;
                    break;

                  case 34:
                    e.prev = 34, e.t1 = e.catch(4), console.error(e.t1);

                  case 37:
                    this.lastPage = "", f.default.pv("c_ghvr0xev"), (0, I.reportMetric)("index_pv");

                  case 40:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 4, 34 ], [ 19, 26 ] ]);
        }));
        return function() {
            return e.apply(this, arguments);
        };
    }(),
    onHide: function() {
        this.stopRefreshProcessingOrder();
    },
    goToCertificationInstruction: function(e) {
        (0, i.navigateTo)({
            url: "/preference/pages/certificationInstruction/certificationInstruction?certificationTestStrategy=" + this.data.certificationTestStrategy
        }), "weakCertificationTip" === e.target.id && f.default.click("b_banma_f7cert72_mc", {
            businessType: 1
        }), "strongCertificationTip" === e.target.id && f.default.click("b_banma_t52qkdjr_mc", {
            businessType: 1
        });
    },
    getCertificationStatus: function() {
        var e = this;
        return t(r.default.mark(function t() {
            var a, n, i, s;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, a = {}, void 0 !== O.sendAddress.id && (a.longitude = (0, l.locFormat)(O.sendAddress.lng), 
                    a.latitude = (0, l.locFormat)(O.sendAddress.lat)), t.next = 5, (0, g.postInfo)(d.getCertificationStatusApi, a).catch(function() {
                        return Promise.reject(function() {});
                    });

                  case 5:
                    if (!(n = t.sent) || 0 !== n.code || !n.data) {
                        t.next = 14;
                        break;
                    }
                    return i = n.data.certificationTest || "", s = n.data.certificationFlag || 0, e.setData({
                        certificationTestStrategy: i,
                        certificationFlag: s
                    }), t.next = 12, D.configPromise;

                  case 12:
                    D.globalConfig.testIdMapping.certification_test = i, 2 === s && ("B" === i && f.default.view("b_banma_f7cert72_mv", {
                        businessType: 1
                    }), "C" === i && f.default.view("b_banma_t52qkdjr_mv", {
                        businessType: 1
                    }));

                  case 14:
                    t.next = 26;
                    break;

                  case 16:
                    t.prev = 16, t.t0 = t.catch(0), t.t1 = void 0 === t.t0 ? "undefined" : S(t.t0), 
                    t.next = "string" === t.t1 ? 21 : "function" === t.t1 ? 23 : 25;
                    break;

                  case 21:
                    return e.toast(t.t0), t.abrupt("break", 26);

                  case 23:
                    return t.t0(), t.abrupt("break", 26);

                  case 25:
                    return t.abrupt("break", 26);

                  case 26:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 0, 16 ] ]);
        }))();
    },
    stopRefreshProcessingOrder: function() {
        var e = this.selectComponent("#processing-order");
        e && e.handlePageHide();
    },
    startRefreshProcessingOrder: function() {
        var e = this.selectComponent("#processing-order");
        e && e.handlePageRefresh();
    },
    onDeliveryFormChange: function() {
        var e = this;
        this.updateFromPreview().then(function() {
            e.data.goodsInfo.goodsType && void 0 !== O.sendAddress.id && void 0 !== O.receiveAddress.id ? e.navigateTo("delivery-order-edit") : e.updateIndexPage();
        }).catch(function(t) {
            return e.handlePreviewException(t, e.onDeliveryFormChange.bind(e));
        });
    },
    renderFirstLoad: function() {
        var e = this;
        return t(r.default.mark(function t() {
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, C.initIndexLocation.apply(e, [ O, N ]);

                  case 2:
                    return t.next = 4, (0, p.silentLogin)();

                  case 4:
                    e.updateIndexPage(), (0, p.checkIsLogin)() ? (e.setDataAsync({
                        isLogin: !0
                    }), e.updateFromPreview().catch(function(t) {
                        e.handlePreviewException(t);
                    }), e.showFallingCoupons().then(function() {
                        e.requestAndShowMarketingInfo();
                    })) : e.requestAndShowMarketingInfo();

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t, e);
        }))();
    },
    updateIndexPage: (0, v.default)(function() {
        var e = this, t = void 0, a = "b" === D.globalConfig.testIdMapping.addresspage_autorecognition;
        a ? ("delivery" !== O.pageMode || O.sendAddress.address || (t = this.getNearPoi()), 
        this.setDataAsync({
            nearPoiAddress: {
                address: "正在获取发件位置...",
                lng: null,
                lat: null,
                name: "请完善发件人信息"
            },
            nearPoiWarn: !1,
            noNearPoi: !1
        })) : this.setDataAsync({
            nearPoiAddress: null
        }), this.fetchIndexApiData().then(function(a) {
            e.updateMapRiderIcon(a.homeConfig.riderIcon), e.updateMapArea({
                ongoingOrderIds: a.processingOrderIds || [],
                waitForPaidOrderIds: a.waitForPaidOrderIds || [],
                bubbleText: a.fixedLocalTip,
                nearbyRiderPointList: a.nearbyRiderPointList
            }), e.updateRecommendAddress(a.recommendSender), e.updateBuyFormData(a.homeConfig.tabIcon, a.homeConfig.defaultInput, a.buyCategories), 
            a.city && a.city.cityId && f.default.setCity(a.city.cityId), t && (-3 !== a.metrics ? t.then(function(t) {
                if (t.result.pois && t.result.pois.length) {
                    var a = t.result.pois[0];
                    e.setDataAsync({
                        nearPoiAddress: {
                            address: a.title,
                            lng: a.location.lng,
                            lat: a.location.lat,
                            name: "请完善发件人信息"
                        },
                        nearPoiWarn: !1,
                        noNearPoi: !1
                    });
                } else e.resetNearPoi();
            }).catch(function() {
                e.resetNearPoi();
            }) : e.resetNearPoi()), e.pageMetricsHandler && e.pageMetricsHandler.add({
                step: "request_index_api_success"
            }).end();
        }).catch(function(t) {
            e.pageMetricsHandler && e.pageMetricsHandler.end(), a && e.resetNearPoi(), e.toast(t.message);
        }), (0, p.checkIsLogin)() ? (this.getCertificationStatus(), "B" === D.globalConfig.testIdMapping.processing_order_entry && this.startRefreshProcessingOrder()) : this.stopRefreshProcessingOrder();
    }, 10),
    resetNearPoi: function() {
        this.setDataAsync({
            nearPoiAddress: {
                address: "从哪里发出",
                lng: null,
                lat: null,
                name: "请完善发件人信息"
            },
            nearPoiWarn: !1,
            noNearPoi: !0
        });
    },
    updateMapArea: function(e) {
        var t = e.nearbyRiderPointList, a = e.ongoingOrderIds, r = e.waitForPaidOrderIds, n = e.bubbleText;
        this.setData({
            ongoingOrderIds: a,
            waitForPaidOrderIds: r,
            pinText: (n || "").trim(),
            pinTextVisible: void 0 === O.sendAddress.id,
            nearbyRiderPointList: t || []
        }), this.updateMapMarkers(t, n), a.length > 0 && f.default.view("b_1ds2fu3e", {
            active_order_num: a.length
        });
    },
    updateMapRiderIcon: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var n;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (-1 !== (0, l.compareVersion)(s.default.systemInfo.SDKVersion, "2.3.0")) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    if (e) {
                        t.next = 6;
                        break;
                    }
                    return a.riderIconPath = "../../imgs/defaultRider.png", (0, h.removeItem)("riderIcon"), 
                    t.abrupt("return");

                  case 6:
                    if ((n = (0, h.getItem)("riderIcon")) && e === n.url && n.path) {
                        t.next = 10;
                        break;
                    }
                    return a.downLoadAndSetRiderIcon(e), t.abrupt("return");

                  case 10:
                    return t.prev = 10, t.next = 13, (0, u.getFileInfo)({
                        filePath: n.path
                    });

                  case 13:
                    t.next = 19;
                    break;

                  case 15:
                    return t.prev = 15, t.t0 = t.catch(10), a.downLoadAndSetRiderIcon(e), t.abrupt("return");

                  case 19:
                    a.riderIconPath = n.path;

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, t, a, [ [ 10, 15 ] ]);
        }))();
    },
    downLoadAndSetRiderIcon: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var n, i;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = void 0, t.prev = 1, t.next = 4, (0, g.downloadFile)(e);

                  case 4:
                    n = t.sent, t.next = 9;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(1);

                  case 9:
                    200 === n.statusCode && (i = n.tempFilePath, a.riderIconPath = i, (0, h.setItem)("riderIcon", {
                        url: e,
                        path: i
                    }), a.setData({
                        markers: a.data.markers.map(function(e) {
                            return "rider" === e.type && (e.iconPath = a.riderIconPath), e;
                        })
                    }));

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t, a, [ [ 1, 7 ] ]);
        }))();
    },
    updateFromPreview: function() {
        var e = this;
        return this.requestDeliveryPreview().then(function(t) {
            t.deliveryCategories && (e.deliveryCategories = t.deliveryCategories), t.goodsConfig && (e.goodsConfig = t.goodsConfig), 
            t.commonConfig && (e.commonConfig = t.commonConfig);
            var a = t.latestFinishedDeliveryOrder;
            if (a && void 0 === e.data.goodsInfo.goodsType && (e.goodsConfig ? (0, k.validateGoodsValue)(a.minGoodsValue, a.maxGoodsValue) && e.updateGoodsInfo(a.goodsType, a.goodsNames, a.goodsWeight, a.minGoodsValue, a.maxGoodsValue) : e.updateGoodsInfo(a.goodsType, a.goodsNames, a.goodsWeight)), 
            !e.data.isAddressDegrade) {
                var r = void 0 === O.sendAddress.id ? 0 : 1;
                f.default.view("b_ifscnes4", {
                    click_hasvalue: r
                }), f.default.view("b_9fcynaio", {
                    click_hasvalue: r
                });
            }
        });
    },
    handlePreviewException: function(e, t) {
        var a = e.code, r = e.message;
        switch (a) {
          case 10001:
          case 10002:
          case 10003:
          case 10314:
            this.toast(r);
            break;

          case 10311:
            this.setData({
                deliveryOrderToken: ""
            }), this.toast(r), t && t();
            break;

          case 10316:
            var n = [ {
                latitude: O.sendAddress.lat,
                longitude: O.sendAddress.lng
            } ];
            this.myMap.includePoints({
                padding: 200,
                points: n
            }), O.dispatch("clearAddress", {
                receiveAddress: {}
            }), this.toast(r);
            break;

          case 10106:
            O.dispatch("clearAddress"), this.setData({
                scale: 16
            }), this.toast(r);
            break;

          case 10112:
          case 10113:
          case 10114:
          case 10115:
            var i = {};
            try {
                i = JSON.parse(r);
            } catch (e) {
                this.toast(r || "服务器开小差啦, 请稍后重试");
                break;
            }
            this.modal({
                content: i.desc || "服务器开小差啦, 请稍后重试",
                showCancel: !1,
                confirmText: "我知道了"
            }), "1" === i.addressType ? this.setDataAsync({
                sendAddressErrorTip: i.extraDesc || "",
                hasAddressError: !0
            }) : this.setDataAsync({
                receiveAddressErrorTip: i.extraDesc || "",
                hasAddressError: !0
            });
            break;

          default:
            this.toast(r);
        }
    },
    changeCity: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var n, i;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (a.setData({
                        cityName: e,
                        cityNameDisplayed: (0, C.cutCityName)(e)
                    }), n = O.actualLocation, i = void 0, e !== a.data.userCityName || !n.lat) {
                        t.next = 7;
                        break;
                    }
                    i = n, t.next = 17;
                    break;

                  case 7:
                    return t.prev = 7, t.next = 10, O.dispatch("cityToActPoint", e);

                  case 10:
                    i = O.actPoint, t.next = 17;
                    break;

                  case 13:
                    return t.prev = 13, t.t0 = t.catch(7), a.toast("切换城市失败，请您稍后重试"), t.abrupt("return");

                  case 17:
                    if (i.lat && i.lng) {
                        t.next = 20;
                        break;
                    }
                    return a.toast("切换城市失败，请您稍后重试"), t.abrupt("return");

                  case 20:
                    return a.setData({
                        scale: 16,
                        recommendAddress: {}
                    }), O.dispatch("clearAddress"), O.dispatch("updateActPoint", i), t.abrupt("return", i);

                  case 24:
                  case "end":
                    return t.stop();
                }
            }, t, a, [ [ 7, 13 ] ]);
        }))();
    },
    updateGoodsInfo: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : -1, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1, r = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0, n = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0;
        this.setData({
            goodsInfoText: t + "、" + (a < 5 ? "小于5公斤" : a + "公斤"),
            goodsInfo: {
                goodsTypeName: t,
                goodsType: e,
                goodsWeight: a,
                minGoodsValue: r,
                maxGoodsValue: n
            }
        });
    },
    riderIconPath: "../../imgs/defaultRider.png",
    updateMapMarkers: function(e, t) {
        var a = this;
        e = e || [], "delivery" === O.pageMode && void 0 !== O.sendAddress.id && void 0 !== O.receiveAddress.id && (e = []);
        var r = e.map(function(e, t) {
            return {
                id: t + 1,
                latitude: e.lat / 1e6,
                longitude: e.lng / 1e6,
                iconPath: a.riderIconPath || "../../imgs/defaultRider.png",
                width: 35,
                height: 35,
                type: "rider"
            };
        });
        if ("delivery" === O.pageMode) {
            var n = void 0;
            t && (n = {
                content: t + "  ",
                color: "#ffffff",
                fontSize: 14,
                borderRadius: 15,
                bgColor: "#595959",
                padding: 7,
                textAlign: "center",
                display: "ALWAYS"
            }), void 0 !== O.sendAddress.id && r.push({
                id: r.length + 1,
                latitude: O.sendAddress.lat,
                longitude: O.sendAddress.lng,
                iconPath: "../../imgs/send.png",
                width: 35,
                height: 40,
                callout: n
            }), void 0 !== O.receiveAddress.id && r.push({
                id: r.length + 1,
                latitude: O.receiveAddress.lat,
                longitude: O.receiveAddress.lng,
                iconPath: "../../imgs/receive.png",
                width: 35,
                height: 40
            });
        }
        this.setData({
            markers: r
        }), "delivery" === O.pageMode && void 0 !== O.sendAddress.id && void 0 !== O.receiveAddress.id && this.myMap.includePoints({
            padding: [ 80, 80, 50, 80 ],
            points: [ {
                latitude: O.sendAddress.lat,
                longitude: O.sendAddress.lng
            }, {
                latitude: O.receiveAddress.lat,
                longitude: O.receiveAddress.lng
            } ]
        });
    },
    requestDeliveryPreview: function() {
        var e = this, t = (0, h.getItem)("actPoint"), a = {
            orderToken: this.data.deliveryOrderToken,
            bindPhone: this.data.deliveryBindPhone,
            wmFingerprint: "",
            fingerprint: "",
            actLongitude: O.actPoint.lng ? (0, l.locFormat)(O.actPoint.lng) : (0, l.locFormat)(t.lng),
            actLatitude: O.actPoint.lat ? (0, l.locFormat)(O.actPoint.lat) : (0, l.locFormat)(t.lat),
            businessType: 1
        };
        if (this.data.goodsInfo.goodsType && this.data.goodsInfo.goodsType > 0) {
            var r = this.data.goodsInfo;
            a.goodTypes = [ r.goodsType ], a.goodTypeNames = [ r.goodsTypeName ], a.goodWeight = r.goodsWeight, 
            a.minGoodValue = r.minGoodsValue || 0, a.maxGoodValue = r.maxGoodsValue || 0;
        }
        if (void 0 !== O.sendAddress.id) {
            var n = O.sendAddress;
            a.senderName = n.name, a.senderPhone = n.phone, a.fetchAddressId = n.id, a.fetchAddress = n.address || "", 
            a.fetchHouseNumber = n.houseNumber || "", a.fetchLongitude = (0, l.locFormat)(n.lng), 
            a.fetchLatitude = (0, l.locFormat)(n.lat), a.actLongitude = (0, l.locFormat)(n.lng), 
            a.actLatitude = (0, l.locFormat)(n.lat);
        }
        if (void 0 !== O.receiveAddress.id) {
            var i = O.receiveAddress;
            a.recipientName = i.name, a.recipientPhone = i.phone, a.recipientAddressId = i.id, 
            a.recipientAddress = i.address || "", a.recipientHouseNumber = i.houseNumber || "", 
            a.recipientLongitude = (0, l.locFormat)(i.lng), a.recipientLatitude = (0, l.locFormat)(i.lat);
        }
        return a.insuranceType = 5, a.insuranceValue = 0, a.userInsurancePrice = 0, (0, 
        g.postInfo)(d.deliveryPreviewApi, a).then(function(t) {
            if (t && 0 === t.code) return e.setData({
                deliveryOrderToken: t.data.orderToken,
                deliveryBindPhone: t.data.mobile,
                isAddressDegrade: 1 === t.data.isAddressDegrade
            }), e.clearAddressError(), t.data;
            if (t && 0 !== t.code) {
                var a = new Error(t.message);
                throw a.code = t.code, e.clearAddressError(), a;
            }
            throw new Error("网络异常，请重试");
        }).catch(function(e) {
            throw e && e.code ? e : new Error("网络异常，请重试");
        });
    },
    updateRecommendAddress: function(e) {
        e ? (e.lat /= 1e6, e.lng /= 1e6, this.setData({
            recommendAddress: e,
            showRecommendAddress: !0
        }), void 0 === O.sendAddress.id && e.id && f.default.view("b_5fsu9v4i")) : this.setData({
            recommendAddress: {}
        });
    },
    reverseCity: function(e, a) {
        var n = this;
        return new Promise(function() {
            var i = t(r.default.mark(function t(i, s) {
                var o, d, c, u, l, p;
                return r.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return o = !1, t.prev = 1, t.next = 4, M.default;

                      case 4:
                        o = t.sent.mafSwitch, t.next = 9;
                        break;

                      case 7:
                        t.prev = 7, t.t0 = t.catch(1);

                      case 9:
                        if (!o) {
                            t.next = 26;
                            break;
                        }
                        return t.prev = 10, t.next = 13, _.default.reverseGeocoder({
                            location: a + "," + e,
                            scenario: "ADMIN"
                        });

                      case 13:
                        d = t.sent, c = d.addr_info, u = void 0 === c ? [] : c, l = (0, L.getCityAndDistrict)(u), 
                        "市" === (p = l.cityName).substr(p.length - 1) && (p = p.substring(0, p.length - 1)), 
                        i(p), t.next = 24;
                        break;

                      case 20:
                        t.prev = 20, t.t1 = t.catch(10), s(t.t1), (0, y.reportDetailJsError)("美团地图sdk获取城市名称错误", {
                            e: t.t1,
                            lng: a,
                            lat: e
                        }, "warn");

                      case 24:
                        t.next = 27;
                        break;

                      case 26:
                        n.mapSDK.reverseGeocoder({
                            location: {
                                latitude: e,
                                longitude: a
                            },
                            success: function(t) {
                                if (0 === t.status && t.result) {
                                    var r = t.result.address_component.city || "";
                                    "市" === r.substr(r.length - 1) && (r = r.substring(0, r.length - 1)), i(r);
                                } else (0, y.reportDetailJsError)("腾讯地图sdk获取城市名称错误", {
                                    res: t,
                                    lng: a,
                                    lat: e
                                }, "warn"), s();
                            },
                            fail: function(t) {
                                (0, y.reportDetailJsError)("腾讯地图sdk获取城市名称失败", {
                                    res: t,
                                    lng: a,
                                    lat: e
                                }, "warn"), s(new Error("unkown error"));
                            }
                        });

                      case 27:
                      case "end":
                        return t.stop();
                    }
                }, t, n, [ [ 1, 7 ], [ 10, 20 ] ]);
            }));
            return function(e, t) {
                return i.apply(this, arguments);
            };
        }());
    },
    showFallingCoupons: function() {
        var e = this;
        return (0, g.postInfo)(d.couponHeavenApi, {}).then(function(t) {
            if (t && 0 === t.code && t.data && t.data.heavenCouponViews) {
                var a = t.data, r = a.heavenCouponViews.map(function(e) {
                    var t = e.couponAmount.split(".");
                    return e.intNum = t[0], t.length > 1 && (e.floatNum = t[1]), e;
                }), n = void 0;
                switch (r.length) {
                  case 1:
                    n = "top:42%";
                    break;

                  case 2:
                    n = "top: 47%";
                    break;

                  default:
                    n = "top: 50%";
                }
                F.remove("fallingCoupons", {
                    animation: !1
                }), F.append({
                    id: "fallingCoupons",
                    onExecute: function() {
                        e.setDataAsync({
                            couponBanner: a.banner,
                            couponList: r,
                            couponStyle: {
                                homeButtonBg: a.homeButtonBg || "FFCE65",
                                homeButtonText: a.homeButtonText || "进入首页",
                                homeButtonTextBg: a.homeButtonTextBg || "333333",
                                popupBg: a.popupBg || "F30025"
                            },
                            couponModalVisible: !0,
                            couponLayerStyle: "opacity:0.5;",
                            couponModalStyle: n,
                            fullWindowBuyEditing: !1
                        }), f.default.view("b_0v1h1r4b");
                    },
                    onRemove: function(t) {
                        !1 !== t.animation ? (e.setDataAsync({
                            couponModalVisible: !1,
                            couponLayerStyle: "display: none;",
                            couponModalStyle: "top: 150%"
                        }), setTimeout(function() {
                            e.setDataAsync({
                                couponModalStyle: "display: none; top: 0"
                            });
                        }, 300)) : e.setDataAsync({
                            couponModalVisible: !1,
                            couponModalStyle: "display: none; top: 0"
                        });
                    }
                });
            } else console.log(t.message);
        });
    },
    hideFallingCoupons: function() {
        F.remove("fallingCoupons");
    },
    requestAndShowMarketingInfo: function() {
        var e = this;
        return t(r.default.mark(function t() {
            var a, n, i, s, o, c;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, g.postInfo)(d.homeMarketingApi);

                  case 3:
                    (a = t.sent) && 0 === a.code ? (n = a.data, i = n.popupList, s = n.suspendSourceList, 
                    o = n.topSourceList, c = {}, i && i.length && !e.data.modalMarketingVisible && (F.remove("marketing"), 
                    F.append({
                        id: "marketing",
                        onExecute: function() {
                            var t = new Date().toLocaleDateString();
                            (0, h.getItem)("lastModalMarketingDate") !== t ? (e.setDataAsync({
                                modalMarketingVisible: !0,
                                modalMarketing: {
                                    id: i[0].id,
                                    picUrl: i[0].picUrl,
                                    url: i[0].skipUrl
                                }
                            }), (0, h.setItem)("lastModalMarketingDate", t), f.default.view("b_oa7txzfx", {
                                operationalposition_id: i[0].id
                            })) : F.remove("marketing");
                        },
                        onRemove: function() {
                            e.setDataAsync({
                                modalMarketingVisible: !1
                            });
                        }
                    })), s && s.length ? c.suspendMarketing = {
                        icon: s[0].icon,
                        url: s[0].skipUrl,
                        id: s[0].id
                    } : c.suspendMarketing = null, o && o.length ? c.topMarketing = {
                        content: o[0].content,
                        icon: o[0].icon,
                        url: o[0].skipUrl,
                        id: o[0].id
                    } : c.topMarketing = null, e.setData(c), e.data.suspendMarketing && f.default.view("b_bknex1za", {
                        operationalposition_id: e.data.suspendMarketing.id
                    }), e.data.topMarketing && 0 === e.data.ongoingOrderIds.length && 0 === e.data.waitForPaidOrderIds.length && f.default.view("b_jo6hbncf", {
                        operationalposition_id: e.data.topMarketing.id
                    })) : e.toast(a.message), t.next = 10;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(0), e.toast("网络异常，请重试");

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 0, 7 ] ]);
        }))();
    },
    updateBuyFormData: function(e, t, a) {
        this.setData({
            buyTabBadge: e,
            buyEditTip: t || this.data.buyEditTip,
            buyCategories: a || this.data.buyCategories
        }), this.setData({
            buyCategorySelected: this.data.buyCategories[0]
        });
    },
    updateOrderIds: function(e, t) {
        this.setData({
            ongoingOrderIds: e
        }), t && this.setData({
            waitForPaidOrderIds: t
        });
    },
    fetchIndexApiData: function() {
        var e = {
            businessType: "delivery" === O.pageMode ? 1 : 2
        };
        void 0 !== O.sendAddress.id && (e.fetchLongitude = (0, l.locFormat)(O.sendAddress.lng), 
        e.fetchLatitude = (0, l.locFormat)(O.sendAddress.lat));
        var t = (0, h.getItem)("actPoint") || {};
        return t.lat && t.lng || ((0, y.reportDetailJsError)("经纬度错误：actPoint参数错误"), s.default.actualLocation && s.default.actualLocation.lat) ? (0, 
        g.postInfo)(d.homeIndexApi, e).then(function(e) {
            if (e && 0 === e.code) return e.data;
            throw e ? new Error(e.message) : new Error("未知服务器错误，请重试");
        }).catch(function(e) {
            throw new Error("网络异常，请重试");
        }) : ((0, y.reportDetailJsError)("经纬度错误：index接口参数错误，经纬度缺失"), Promise.reject());
    },
    onShareAppMessage: function() {
        return c.shareApp.call(this, {
            type: "menu"
        });
    },
    navigateTo: function(e) {
        var t = this, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", r = "";
        this.lastPage = e;
        var n = Object.assign({}, O.sendAddress, {
            lat: (0, l.locFormat)(O.sendAddress.lat),
            lng: (0, l.locFormat)(O.sendAddress.lng)
        }), s = Object.assign({}, O.receiveAddress, {
            lat: (0, l.locFormat)(O.receiveAddress.lat),
            lng: (0, l.locFormat)(O.receiveAddress.lng)
        });
        switch ((0, h.setItem)("sendAddr", n), (0, h.setItem)("receiveAddr", s), (0, h.setItem)("cityData", {
            name: this.data.cityName
        }), e) {
          case "city-list":
            r = "/address/pages/cityList/cityList";
            break;

          case "user-center":
            r = "/preference/pages/personalCenter/personalCenter?sendAddr=" + encodeURIComponent(JSON.stringify(n));
            break;

          case "send-address-list":
            r = "/address/pages/addrList/addrList?addrType=1&hasSaveOption=" + !this.data.isAddressDegrade + "&originPage=pages/index/index";
            break;

          case "receive-address-list":
            r = "/address/pages/addrList/addrList?addrType=2&fetchLatitude=" + n.lat + "&fetchLongitude=" + n.lng + "&originPage=pages/index/index";
            break;

          case "send-address-edit":
            var d = "", c = "edit";
            O.sendAddress.address || (this.data.nearPoiAddress && (0, l.checkLoc)(this.data.nearPoiAddress.lng) && (0, 
            l.checkLoc)(this.data.nearPoiAddress.lat) && (d = encodeURIComponent(JSON.stringify({
                title: this.data.nearPoiAddress.address,
                location: {
                    lng: this.data.nearPoiAddress.lng,
                    lat: this.data.nearPoiAddress.lat
                }
            }))), c = "add"), r = "/address/pages/addrEdit/addrEdit?addrType=1&action=" + c + "&selectAddr=" + d + "&hasSaveOption=" + !this.data.isAddressDegrade + "&needAddrList=true&originPage=pages/index/index";
            break;

          case "receive-address-edit":
            var u = "edit";
            O.receiveAddress.address || (u = "add"), r = "/address/pages/addrEdit/addrEdit?addrType=2&action=" + u + "&fetchLatitude=" + n.lat + "&fetchLongitude=" + n.lng + "&hasSaveOption=" + !this.data.isAddressDegrade + "&needAddrList=true&originPage=pages/index/index";
            break;

          case "goods-info":
            var p = this.data.goodsInfo, g = p.goodsWeight, f = p.goodsType, m = void 0 === f ? "" : f, v = p.minGoodsValue, y = void 0 === v ? "" : v, b = p.maxGoodsValue, k = void 0 === b ? "" : b;
            r = "/order/pages/goodsInfo/goodsInfo?deliveryCategories=" + (this.deliveryCategories ? encodeURIComponent(JSON.stringify(this.deliveryCategories)) : "") + "&goodsConfig=" + (this.goodsConfig ? encodeURIComponent(JSON.stringify(this.goodsConfig)) : "") + "&commonConfig=" + (this.commonConfig ? encodeURIComponent(JSON.stringify(this.commonConfig)) : "") + "&goodsWeight=" + g + "&selectedType=" + m + "&refer=" + o.GOODS_INFO_REFER_INDEX + "&minGoodsValue=" + y + "&maxGoodsValue=" + k;
            break;

          case "delivery-order-edit":
            var A = this.data.goodsInfo, x = A.goodsWeight, w = A.goodsType, I = A.goodsTypeName, P = A.minGoodsValue, T = A.maxGoodsValue;
            r = "/order/pages/orderConfirm/orderConfirm?originType=index&goodsType=" + w + "&goodsWeight=" + x + "&goodsTypeName=" + (I || "") + "&is_suggest_address=" + (O.sendAddress.isRecommend ? 2 : 0) + "&minGoodsValue=" + P + "&maxGoodsValue=" + T;
            break;

          case "buy-order-edit":
            r = "/order/pages/orderBuy/orderBuy";
            break;

          case "order-list":
            r = "/pages/orderList/orderList";
            break;

          case "order-detail":
            r = "/pages/orderDetail/orderDetail";
            break;

          case "invite-coupon":
            r = "/marketing/pages/personalInvite/personalInvite";
            break;

          default:
            r = e;
        }
        (0, i.navigateTo)({
            url: r + a,
            fail: function() {
                t.toast("目标页面不存在，请稍后再试");
            }
        });
    },
    showLocationAuthModalIfNeeded: function() {
        var e = this;
        return t(r.default.mark(function t() {
            var a;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, u.getSetting)();

                  case 3:
                    if ((a = t.sent).authSetting["scope.userLocation"]) {
                        t.next = 9;
                        break;
                    }
                    return F.append({
                        id: "locationAuth",
                        onExecute: function() {
                            e.setDataAsync({
                                locationAuthModalVisible: !0
                            });
                        },
                        onRemove: function() {
                            e.setDataAsync({
                                locationAuthModalVisible: !1
                            });
                        }
                    }), t.abrupt("return", !0);

                  case 9:
                    return t.abrupt("return", !1);

                  case 10:
                    t.next = 15;
                    break;

                  case 12:
                    return t.prev = 12, t.t0 = t.catch(0), t.abrupt("return", !1);

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 0, 12 ] ]);
        }))();
    },
    changeAddr: function(e) {
        var t = this;
        O.dispatch("changeAddr", e), this.setDataAsync({
            showRecommendAddress: !1
        }), this.reverseCity(e.data.lat, e.data.lng).then(function(e) {
            return t.setData({
                cityName: e,
                cityNameDisplayed: (0, C.cutCityName)(e)
            });
        }), this.onDeliveryFormChange();
    },
    clearAddress: function() {
        O.dispatch("clearAddress"), this.setData({
            scale: 16,
            markers: []
        }), this.updateMapArea({
            nearbyRiderPointList: this.data.nearbyRiderPointList,
            ongoingOrderIds: this.data.ongoingOrderIds,
            waitForPaidOrderIds: this.data.waitForPaidOrderIds,
            bubbleText: ""
        }), this.clearAddressError(), this.updateIndexPage();
    },
    clearAddressError: function() {
        this.setDataAsync({
            sendAddressErrorTip: "",
            receiveAddressErrorTip: "",
            hasAddressError: !1
        });
    },
    closeModalMarketing: function() {
        F.remove("marketing");
    },
    onMapRegionChange: function(e) {
        "end" !== e.type && this.data.pinTextVisible && this.setDataAsync({
            pinTextVisible: !1
        }), "end" !== e.type || e.causedBy && "drag" !== e.causedBy || void 0 !== O.sendAddress.id && "buy" !== O.pageMode || this.getCenterLocationAndUpdate();
    },
    getNearPoi: function() {
        var e = this;
        return new Promise(function() {
            var a = t(r.default.mark(function t(a, n) {
                var i, s, o;
                return r.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return i = !1, t.prev = 1, t.next = 4, M.default;

                      case 4:
                        i = t.sent.mafSwitch, t.next = 9;
                        break;

                      case 7:
                        t.prev = 7, t.t0 = t.catch(1);

                      case 9:
                        if (!i) {
                            t.next = 25;
                            break;
                        }
                        return t.prev = 10, t.next = 13, _.default.reverseGeocoder({
                            location: O.actPoint.lng + "," + O.actPoint.lat,
                            scenario: "GENERAL",
                            radius: 20
                        });

                      case 13:
                        s = t.sent, (o = (s.pois || []).map(function(e) {
                            return {
                                title: e.name || "",
                                location: {
                                    lng: +((e.location || "").split(",")[0] || ""),
                                    lat: +((e.location || "").split(",")[1] || "")
                                },
                                distance: +(e.distance || 0)
                            };
                        })).sort(function(e, t) {
                            return e.distance - t.distance;
                        }), a({
                            result: {
                                pois: o
                            }
                        }), t.next = 23;
                        break;

                      case 19:
                        t.prev = 19, t.t1 = t.catch(10), n(t.t1), (0, y.reportDetailJsError)("美团地图sdk获取poi错误", {
                            e: t.t1,
                            lng: O.actPoint.lng,
                            lat: O.actPoint.lng
                        }, "warn");

                      case 23:
                        t.next = 26;
                        break;

                      case 25:
                        e.mapSDK.reverseGeocoder({
                            location: {
                                latitude: O.actPoint.lat,
                                longitude: O.actPoint.lng
                            },
                            get_poi: 1,
                            poi_options: "page_index=1;page_size=1;policy=1;radius=20",
                            success: function(e) {
                                a(e);
                            },
                            fail: function(e) {
                                n(e);
                            }
                        });

                      case 26:
                      case "end":
                        return t.stop();
                    }
                }, t, e, [ [ 1, 7 ], [ 10, 19 ] ]);
            }));
            return function(e, t) {
                return a.apply(this, arguments);
            };
        }());
    },
    getCenterLocationAndUpdate: (0, v.default)(t(r.default.mark(function e() {
        var t, a, n, i = this;
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, e.next = 3, O.dispatch("getCenterLocation", this.myMap);

              case 3:
                t = O.actPoint, a = t.lat, n = t.lng, this.reverseCity(a, n).then(function(e) {
                    i.setData({
                        cityName: e,
                        cityNameDisplayed: (0, C.cutCityName)(e)
                    });
                }), this.updateIndexPage(), e.next = 11;
                break;

              case 8:
                e.prev = 8, e.t0 = e.catch(0), (0, y.reportDetailJsError)("经纬度错误：获取地图组件中心点参数失败", e.t0);

              case 11:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 0, 8 ] ]);
    })), 500),
    handleTopMarketingTap: function() {
        this.navigateTo(this.data.topMarketing.url), f.default.click("b_m39q50cy", {
            operationalposition_id: this.data.topMarketing.id
        });
    },
    handleSuspendMarketingTap: function() {
        this.navigateTo(this.data.suspendMarketing.url), f.default.click("b_jev0au74", {
            operationalposition_id: this.data.suspendMarketing.id
        });
    },
    handleModalMarketingTap: function() {
        this.navigateTo(this.data.modalMarketing.url), this.closeModalMarketing(), f.default.click("b_7cgqn5pj", {
            operationalposition_id: this.data.modalMarketing.id
        });
    },
    handleCloseModalMarketing: function() {
        this.closeModalMarketing(), f.default.click("b_n08zk3ix", {
            operationalposition_id: this.data.modalMarketing.id
        });
    },
    togglePageMode: function(e) {
        var t = e.currentTarget.dataset.pageMode;
        t !== O.pageMode && (O.dispatch("changePageMode", t), this.updateMapArea({
            nearbyRiderPointList: this.data.nearbyRiderPointList,
            ongoingOrderIds: this.data.ongoingOrderIds,
            waitForPaidOrderIds: this.data.waitForPaidOrderIds,
            bubbleText: ""
        }), this.updateIndexPage()), "delivery" === t ? f.default.click("b_fh8jaa6g") : f.default.click("b_3e46tnp2");
    },
    handleSendAddressContentTap: function(e) {
        var a = this;
        return t(r.default.mark(function e() {
            var t;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    t = void 0 === O.sendAddress.id ? 0 : 1, (0, p.checkIsLogin)() && a.navigateTo("send-address-edit"), 
                    f.default.click("b_gxik855o", {
                        click_hasvalue: t
                    });

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e, a);
        }))();
    },
    handleSendAddressNoteTap: function() {
        var e = this;
        return t(r.default.mark(function t() {
            var a;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    a = void 0 === O.sendAddress.id ? 0 : 1, (0, p.checkIsLogin)() && e.navigateTo("send-address-list"), 
                    f.default.click("b_5tjt3tm9", {
                        click_hasvalue: a
                    });

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t, e);
        }))();
    },
    handleReceiveAddressContentTap: function(e) {
        var a = this;
        return t(r.default.mark(function e() {
            var t;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t = void 0 === O.receiveAddress.id ? 0 : 1, f.default.click("b_mmy6eqdg", {
                        click_hasvalue: t
                    }), void 0 !== O.sendAddress.id) {
                        e.next = 6;
                        break;
                    }
                    return a.toast("请先填写发件地址"), a.setDataAsync({
                        nearPoiWarn: !0
                    }), e.abrupt("return");

                  case 6:
                    a.navigateTo("receive-address-edit");

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e, a);
        }))();
    },
    handleReceiveAddressNoteTap: function() {
        var e = this;
        return t(r.default.mark(function t() {
            var a;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (a = void 0 === O.receiveAddress.id ? 0 : 1, void 0 !== O.sendAddress.id) {
                        t.next = 5;
                        break;
                    }
                    return e.toast("请先填写发件地址"), e.setDataAsync({
                        nearPoiWarn: !0
                    }), t.abrupt("return");

                  case 5:
                    e.navigateTo("receive-address-list"), f.default.click("b_u9qdhkpp", {
                        click_hasvalue: a
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t, e);
        }))();
    },
    onTapRecommendAddress: function(e) {
        f.default.click("b_rtesh12q");
        var t = Object.assign({}, this.data.recommendAddress, {
            isRecommend: !0
        });
        O.dispatch("tapRecommendAddress", t), this.setData({
            showRecommendAddress: !1
        }), this.updateMapArea({
            nearbyRiderPointList: this.data.nearbyRiderPointList,
            ongoingOrderIds: this.data.ongoingOrderIds,
            waitForPaidOrderIds: this.data.waitForPaidOrderIds,
            bubbleText: ""
        }), this.onDeliveryFormChange();
    },
    closeRecommendAddress: function() {
        f.default.click("b_6m2pzj7l"), this.setData({
            showRecommendAddress: !1
        });
    },
    onTapGoodsInfo: function(e) {
        var a = this;
        return t(r.default.mark(function e() {
            var t;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    t = a.data.goodsInfoText ? 1 : 0, f.default.click("b_zwt0v6t0", {
                        click_hasvalue: t
                    }), (0, p.checkIsLogin)() && (a.deliveryCategories ? a.navigateTo("goods-info") : a.updateFromPreview().then(function() {
                        a.navigateTo("goods-info");
                    }).catch(function(e) {
                        a.handlePreviewException(e);
                    }));

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e, a);
        }))();
    },
    onTapMapRelocate: function(e) {
        var a = this;
        return t(r.default.mark(function e() {
            var t, n, i, s;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, O.dispatch("wxLocation");

                  case 3:
                    e.next = 12;
                    break;

                  case 5:
                    return e.prev = 5, e.t0 = e.catch(0), e.next = 9, a.showLocationAuthModalIfNeeded();

                  case 9:
                    return (t = e.sent) || a.toast("未获取到您的地理位置，请稍后重试"), e.abrupt("return");

                  case 12:
                    if (n = O.actualLocation, i = n.lat, s = n.lng, i && s) {
                        e.next = 16;
                        break;
                    }
                    return a.toast("未获取到您的地理位置，请稍后重试"), e.abrupt("return");

                  case 16:
                    O.dispatch("updateActPoint", {
                        lat: i,
                        lng: s
                    }), a.setData({
                        scale: 16
                    }), a.reverseCity(i, s).then(function(e) {
                        a.setData({
                            cityName: e,
                            userCityName: e,
                            cityNameDisplayed: (0, C.cutCityName)(e)
                        });
                    }), a.updateIndexPage();

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, e, a, [ [ 0, 5 ] ]);
        }))();
    },
    onTapClearAddresses: function(e) {
        f.default.click("b_jhqeuibb"), this.clearAddress();
    },
    onTapOrderBubble: function(e) {
        f.default.click("b_ylk51s7w", {
            active_order_num: this.data.ongoingOrderIds.length
        });
        var t = e.currentTarget.dataset.orderCount, a = e.currentTarget.dataset.orderType;
        if (t >= 2) this.navigateTo("order-list"); else {
            var r = "";
            switch (a) {
              case "wait-for":
                r = this.data.waitForPaidOrderIds[0];
                break;

              case "delivering":
                r = this.data.ongoingOrderIds[0];
            }
            this.navigateTo("order-detail", "?orderViewId=" + r);
        }
    },
    onTapCity: function(e) {
        f.default.click("b_yk1vsexh"), this.navigateTo("city-list");
    },
    onTapUserIcon: function(e) {
        var a = this;
        return t(r.default.mark(function e() {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    f.default.click("b_mjvam1eg"), (0, p.checkIsLogin)() && a.navigateTo("user-center");

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e, a);
        }))();
    },
    onTapEditingTextBelow: function(e) {
        var a = this;
        return t(r.default.mark(function e() {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    f.default.click("b_jcom7oay", {
                        click_hasvalue: a.data.buyDescription.length > 0 ? 1 : 0
                    }), (0, p.checkIsLogin)() && a.openFullWindowBuy();

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e, a);
        }))();
    },
    openFullWindowBuy: function() {
        var e = this;
        this.setData({
            buyFullWindow: !0,
            buyInputTip: this.data.buyCategorySelected ? this.data.buyCategorySelected.defaultInput : this.data.buyEditTip
        });
        var t = this.data.buyDescription ? 1 : 0, a = this.data.buyCategorySelected ? this.data.buyCategorySelected.name : "", r = this.data.buyCategorySelected ? this.data.buyCategorySelected.id : 0;
        f.default.view("b_jdpgdtm5", {
            show_hasdefaultvalue: t,
            tag_name: a,
            click_hasvalue: t
        }), this.data.buyCategorySelected && this.data.buyCategorySelected.tags && this.data.buyCategorySelected.tags.length > 0 && f.default.view("b_y2gtn1zl", {
            tag: this.data.buyCategorySelected.tags.join(","),
            tag_id: r,
            tag_name: a
        }), setTimeout(function() {
            return e.setData({
                buyInputFocus: !0
            });
        }, 100);
    },
    onTapBuyBtn: function(e) {
        var a = this;
        return t(r.default.mark(function e() {
            var t, n, i, s;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    t = a.data.buyFullWindow, n = a.data.buyCategorySelected ? a.data.buyCategorySelected.name : "", 
                    i = a.data.buyCategorySelected ? a.data.buyCategorySelected.id : 0, e.t0 = !0, e.next = e.t0 === ("" === a.data.buyDescription && !1 === t) ? 6 : e.t0 === ("" === a.data.buyDescription && t) ? 8 : 10;
                    break;

                  case 6:
                    return a.openFullWindowBuy(), e.abrupt("break", 12);

                  case 8:
                    return a.toast("请输入商品信息"), e.abrupt("break", 12);

                  case 10:
                    (0, h.setItem)("lxTappedBuyTags", a.lxTappedBuyTags), a.navigateTo("buy-order-edit", "?description=" + encodeURIComponent(a.data.buyDescription) + "&tagId=" + i + "&tagName=" + encodeURIComponent(n));

                  case 12:
                    s = "" !== a.data.buyDescription ? 1 : 0, t ? f.default.click("b_1lrgivjq", {
                        click_hasvalue: s,
                        show_hasdefaultvalue: s
                    }) : f.default.click("b_d5okm44s", {
                        click_hasvalue: s,
                        show_hasdefaultvalue: s
                    });

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, e, a);
        }))();
    },
    onTapCategoryIconBelow: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var n;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    n = e.currentTarget.dataset.category, f.default.click("b_4wbkrrnu", {
                        tag_id: n.id,
                        tag_name: n.name,
                        module_position: e.currentTarget.dataset.position
                    }), (0, p.checkIsLogin)() && (a.setData({
                        buyCategorySelected: n
                    }), a.openFullWindowBuy());

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t, a);
        }))();
    },
    onTapCategoryTitle: function(e) {
        var t = e.currentTarget.dataset.category;
        t !== this.data.buyCategorySelected && (this.setData({
            buyCategorySelected: t
        }), f.default.view("b_y2gtn1zl", {
            tag: t.tags.join(","),
            tag_id: t.id,
            tag_name: t.name
        })), f.default.click("b_ui9soulq", {
            tag_id: t.id,
            tag_name: t.name,
            module_position: e.currentTarget.dataset.position
        });
    },
    onTapCategoryItem: function(e) {
        var t = e.currentTarget.dataset.text, a = void 0;
        (a = this.data.buyDescription ? this.data.buyDescription + " " + t : t).length > 100 && wx.showToast({
            title: "最多只能输入100个字",
            icon: "none"
        }), a = a.substr(0, 100), this.setData({
            buyDescription: a,
            buyEditingDescription: a
        }), this.lxTappedBuyTags.push(t);
        var r = this.data.buyCategorySelected ? this.data.buyCategorySelected.name : "", n = this.data.buyCategorySelected ? this.data.buyCategorySelected.id : 0;
        f.default.click("b_hsvw5874", {
            tag: t,
            tag_name: r,
            tag_id: n
        });
    },
    onTapCloseFullWindowBuy: function() {
        this.setData({
            buyFullWindow: !1
        }), f.default.click("b_p4l5fl8y");
    },
    onInputBuyDescription: function(e) {
        var t = e.detail.value;
        t.length > 100 && (wx.showToast({
            title: "最多只能输入100个字",
            icon: "none"
        }), t = t.substr(0, 100), this.setData({
            buyEditingDescription: t
        })), this.setData({
            buyDescription: t
        });
    },
    onTapBuyInput: function(e) {
        this.setData({
            buyInputFocus: !0
        }), f.default.click("b_qjy3726l", {
            click_hasvalue: this.data.buyDescription ? 1 : 0
        });
    },
    onBuyInputBlur: function() {
        this.setData({
            buyEditingDescription: this.data.buyDescription,
            buyInputFocus: !1
        });
    },
    onLocationAuthModalConfirm: function() {
        F.remove("locationAuth");
    },
    onLocationAuthModalCancel: function() {
        F.remove("locationAuth");
    },
    onSettingEnd: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var n, i, s, o;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(n = e.detail)["scope.userLocation"]) {
                        t.next = 18;
                        break;
                    }
                    return t.prev = 2, t.next = 5, O.dispatch("wxLocation");

                  case 5:
                    if (i = O.actualLocation, s = i.lat, o = i.lng, s && o) {
                        t.next = 9;
                        break;
                    }
                    return a.toast("未获取到您的地理位置，请稍后重试"), t.abrupt("return");

                  case 9:
                    O.dispatch("updateActPoint", {
                        lat: s,
                        lng: o
                    }), a.setData({
                        scale: 16
                    }), a.reverseCity(s, o).then(function(e) {
                        return a.setData({
                            cityName: e,
                            userCityName: e,
                            cityNameDisplayed: (0, C.cutCityName)(e)
                        });
                    }), a.updateIndexPage(), t.next = 18;
                    break;

                  case 15:
                    t.prev = 15, t.t0 = t.catch(2), a.toast("未获取到您的地理位置，请稍后重试");

                  case 18:
                  case "end":
                    return t.stop();
                }
            }, t, a, [ [ 2, 15 ] ]);
        }))();
    },
    handleGetUserInfo: function(e) {
        var a = this;
        return t(r.default.mark(function t() {
            var n;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.detail.userInfo) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return t.next = 4, (0, p.ptLogin)();

                  case 4:
                    if (!(n = t.sent)) {
                        t.next = 13;
                        break;
                    }
                    return a.setDataAsync({
                        isLogin: !0
                    }), a.updateIndexPage(), t.next = 10, a.showFallingCoupons();

                  case 10:
                    a.requestAndShowMarketingInfo(), t.next = 14;
                    break;

                  case 13:
                    a.toast("登录失败");

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, t, a);
        }))();
    }
});