function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function s(i, n) {
                try {
                    var a = t[i](n), o = a.value;
                } catch (e) {
                    return void r(e);
                }
                if (!a.done) return Promise.resolve(o).then(function(e) {
                    s("next", e);
                }, function(e) {
                    s("throw", e);
                });
                e(o);
            }
            return s("next");
        });
    };
}

var r = e(require("../../../../libs/regenerator-runtime/runtime-module.js")), s = require("../../../../modules/api/request.js"), i = require("../../../../modules/api/urls.js"), n = require("../../../../modules/utils/util.js"), a = require("../../../../modules/api/route.js"), o = require("../../../../modules/utils/abtest.js"), u = e(require("../../../../modules/global.js")), c = e(require("../../../../modules/api/lx.js")), d = require("../../../../modules/api/login");

Component({
    properties: {
        hasStrongCertification: {
            type: Boolean,
            default: !1
        }
    },
    data: {
        orderStatus: 0,
        mainDesc: "",
        subDesc: null,
        isShow: !1,
        isOpen: !0,
        canUseViewOnMap: (0, n.compareVersion)(u.default.systemInfo.SDKVersion, "2.8.0") >= 0
    },
    processingOrderCount: 0,
    orderViewId: null,
    refreshTimer: null,
    countTimer: null,
    methods: {
        getProcessingOrder: function() {
            var e = this;
            return t(r.default.mark(function t() {
                var n, a;
                return r.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return n = void 0, t.prev = 1, t.next = 4, (0, s.postInfo)(i.processingOrderApi);

                      case 4:
                        n = t.sent, t.next = 10;
                        break;

                      case 7:
                        t.prev = 7, t.t0 = t.catch(1), e.resetData();

                      case 10:
                        0 === n.code ? (a = n.data, e.processingOrderCount = a.processingOrderCount, e.orderViewId = a.orderViewId, 
                        e.orderStatus = a.orderStatus, e.render(a), e.processingOrderCount >= 1 && !e.refreshTimer && e.data.isOpen && e.startRefreshTimer()) : (e.resetData(), 
                        24002 === n.code && e.stopRefreshTimer());

                      case 11:
                      case "end":
                        return t.stop();
                    }
                }, t, e, [ [ 1, 7 ] ]);
            }))();
        },
        handleTap: function() {
            this.processingOrderCount <= 0 || (this.processingOrderCount > 1 ? (0, a.navigateTo)({
                url: "/pages/orderList/orderList"
            }) : (0, a.navigateTo)({
                url: "/pages/orderDetail/orderDetail?orderViewId=" + this.orderViewId
            }), this.lxReport("b_banma_6w412qbr_mc", "click"));
        },
        handleIconTap: function() {
            this.setData({
                isOpen: !this.data.isOpen
            }), this.data.isOpen ? (this.getProcessingOrder(), this.lxReport("b_banma_6w412qbr_mv", "view")) : this.stopRefreshTimer(), 
            this.lxReport("b_banma_aqy45u4p_mc", "click");
        },
        resetData: function() {
            this.setData({
                orderStatus: 0,
                mainDesc: "",
                subDesc: null,
                processingOrderCount: 0,
                isShow: !1,
                isOpen: !0
            });
        },
        render: function(e) {
            if (e.processingOrderCount <= 0) this.resetData(); else if (e.processingOrderCount > 1) this.setData({
                mainDesc: (e.processingOrderCount > 99 ? "99+" : e.processingOrderCount) + "个订单进行中",
                subDesc: null,
                picUrl: e.picUrl,
                isShow: !0
            }); else {
                this.stopCount();
                var t = e.orderStatus, r = {
                    orderStatus: t,
                    mainDesc: e.mainDesc,
                    picUrl: e.picUrl,
                    isShow: !0
                };
                if (1 === t) {
                    var s = e.detailTime;
                    if (s && s.payLimitTime && s.currentTime) {
                        var i = s.payLimitTime - s.currentTime;
                        this.countDown(i, e.subDesc);
                    } else this.resetData();
                } else if (2 !== t && 21 !== t || 0 !== e.isPrebook) if (2 !== t && 21 !== t || 1 !== e.isPrebook) {
                    var n = e.subDesc.indexOf("{time}") > -1 ? "time" : e.subDesc.indexOf("{distance}") > -1 ? "distance" : "", a = "time" === n ? e.estimateArrivalTime : e.distance;
                    r.subDesc = this.constructSubDesc(e.subDesc, a, n);
                } else r.subDesc = this.constructSubDesc(e.subDesc, e.estimateArrivalTime, "time"); else {
                    var o = e.detailTime;
                    if (!o || !o.midTime || !o.currentTime) return void this.resetData();
                    var u = o.midTime - o.currentTime, c = o.currentTime - o.createTime;
                    u > 0 ? this.countDown(u, e.subDesc) : this.countUp(c, o.endTime, e.subDesc);
                }
                this.setData(r);
            }
        },
        constructSubDesc: function(e, t, r) {
            switch (r) {
              case "time":
                return {
                    descArray: e.split("{time}"),
                    param: (0, n.timeToDate)(1e3 * t)
                };

              case "count":
                return {
                    descArray: e.split("{time}"),
                    param: (0, n.timeFormat)("mm:ss", 1e3 * t)
                };

              case "distance":
                return {
                    descArray: e.split("{distance}"),
                    param: t
                };

              default:
                return {
                    descArray: [ e ]
                };
            }
        },
        countDown: function(e, t) {
            var r = this;
            e <= 0 ? this.setData({
                subDesc: null
            }) : (this.setData({
                subDesc: this.constructSubDesc(t, e, "count")
            }), this.countTimer = setInterval(function() {
                if ((e -= 1) <= 0) return r.setData({
                    subDesc: null
                }), r.stopCount(), void r.getProcessingOrder();
                r.setData({
                    subDesc: r.constructSubDesc(t, e, "count")
                });
            }, 1e3));
        },
        countUp: function(e, t, r) {
            var s = this;
            Date.now() > 1e3 * t ? this.setData({
                subDesc: null
            }) : (this.setData({
                subDesc: this.constructSubDesc(r, e, "count")
            }), this.countTimer = setInterval(function() {
                if (e += 1, Date.now() > 1e3 * t) return s.setData({
                    subDesc: null
                }), s.stopCount(), void s.getProcessingOrder();
                s.setData({
                    subDesc: s.constructSubDesc(r, e, "count")
                });
            }, 1e3));
        },
        stopCount: function() {
            this.countTimer && (clearInterval(this.countTimer), this.countTimer = null);
        },
        startRefreshTimer: function() {
            var e = this;
            this.refreshTimer = setInterval(function() {
                e.getProcessingOrder();
            }, 1e3 * o.globalConfig.processingOrderRefreshInterval || 3e4);
        },
        stopRefreshTimer: function() {
            this.refreshTimer && (clearInterval(this.refreshTimer), this.refreshTimer = null);
        },
        handlePageRefresh: function() {
            var e = this;
            return t(r.default.mark(function t() {
                return r.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.getProcessingOrder();

                      case 2:
                        e.data.isShow && (e.lxReport("b_banma_aqy45u4p_mv", "view"), e.data.isOpen && e.lxReport("b_banma_6w412qbr_mv", "view"));

                      case 3:
                      case "end":
                        return t.stop();
                    }
                }, t, e);
            }))();
        },
        handlePageHide: function() {
            this.stopRefreshTimer(), this.stopCount();
        },
        lxReport: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "click";
            c.default[t](e, {
                order_id: this.orderViewId,
                order_status: this.orderStatus,
                order_quantity_new: this.processingOrderCount,
                order_entry_status: this.data.isOpen ? 0 : 1
            });
        }
    },
    ready: function() {
        (0, d.checkIsLogin)() && this.getProcessingOrder();
    }
});