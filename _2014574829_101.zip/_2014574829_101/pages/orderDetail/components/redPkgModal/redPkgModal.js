function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, s) {
            function r(i, o) {
                try {
                    var a = t[i](o), n = a.value;
                } catch (e) {
                    return void s(e);
                }
                if (!a.done) return Promise.resolve(n).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(n);
            }
            return r("next");
        });
    };
}

var s = e(require("../../../../libs/regenerator-runtime/runtime-module.js")), r = require("../../../../modules/api/request"), i = require("../../../../modules/api/urls"), o = require("../../../../modules/utils/storage.js"), a = e(require("../../../../modules/api/lx"));

Component({
    properties: {
        order: {
            type: Object,
            value: {}
        },
        orderViewId: {
            type: String,
            value: ""
        },
        luckyCanWeChatCircle: {
            type: Boolean,
            value: !0
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                this.setData({
                    modalShow: e
                }), e && (this.triggerEvent("set-overflow-map", {
                    visible: !0,
                    shareOption: this.data.shareOption
                }, {
                    bubbles: !0,
                    composed: !0
                }), this._lxReport("b_0vlpwd2q", "view", {}));
            }
        },
        shouldAutoPop: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        sharePopIcon: "https://vfile.meituan.net/paotui/jjxo8i7jlua.png",
        sharePopMainText: "恭喜获得10个红包",
        sharePopAssiText: "分享给小伙伴，一起抢10元大礼包",
        sharePopButtonText: "发红包",
        sharePopFloatIcon: "https://vfile.meituan.net/paotui/jjxqdqa6od.png",
        shareOption: {
            shareUrl: "",
            shareTitle: "拼手气抢红包",
            shareIcon: "https://vfile.meituan.net/paotui/jjy00vpstk.png",
            shareContent: ""
        },
        modalShow: !1,
        style: "background:rgba(0, 0, 0, 0.5);",
        slotOption: {
            body: !0,
            footer: !0
        }
    },
    methods: {
        initPkgInfo: function() {
            var e = this;
            return t(s.default.mark(function t() {
                var a, n, l, h;
                return s.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, t.next = 3, (0, r.postInfo)(i.redPkgApi.getShareInfo, {
                            orderViewId: e.properties.orderViewId
                        });

                      case 3:
                        0 === (a = t.sent).code && (n = a.data) && (e.setData({
                            sharePopIcon: n.sharePopIcon || "https://vfile.meituan.net/paotui/jjxo8i7jlua.png",
                            sharePopMainText: n.sharePopMainText || "恭喜获得10个红包",
                            sharePopAssiText: n.sharePopAssiText || "分享给小伙伴，一起抢10元大礼包",
                            sharePopButtonText: n.sharePopButtonText || "发红包",
                            sharePopFloatIcon: n.sharePopFloatIcon || "https://vfile.meituan.net/paotui/jjxqdqa6od.png",
                            shareOption: {
                                shareUrl: n.shareBaseUrl && n.shareBaseUrl + "?shareKey=" + n.shareUrlKey || "/marketing/pages/luckyPackage/luckyPackage?shareKey=" + n.shareUrlKey,
                                shareTitle: n.shareTitle || "拼手气抢红包",
                                shareIcon: n.shareIcon || "https://vfile.meituan.net/paotui/jjy00vpstk.png",
                                shareContent: n.shareContent || ""
                            }
                        }), l = (0, o.getItem)("lucky_modal_list") || [], (h = l.includes(e.properties.orderViewId)) || e.popLuckyModal(), 
                        e.triggerEvent("set-lucky-float-btn-show", {
                            visible: !0
                        })), t.next = 9;
                        break;

                      case 7:
                        t.prev = 7, t.t0 = t.catch(0);

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, t, e, [ [ 0, 7 ] ]);
            }))();
        },
        popLuckyModal: function() {
            if (this.data.shouldAutoPop) {
                this.setData({
                    modalShow: !0
                }), this._lxReport("b_0vlpwd2q", "view", {}), this.triggerEvent("set-overflow-map", {
                    visible: !0,
                    shareOption: this.data.shareOption
                }, {
                    bubbles: !0,
                    composed: !0
                });
                var e = (0, o.getItem)("lucky_modal_list");
                e.includes(this.properties.orderViewId) || e.push(this.properties.orderViewId), 
                e.length > 5 && (e = e.slice(e.length - 5)), (0, o.setItem)("lucky_modal_list", e);
            }
        },
        handleCancel: function() {
            this._lxReport("b_135ij7nh", "click", {}), this.setData({
                modalShow: !1
            }), this.triggerEvent("red-pkg-end", null, {
                bubbles: !0,
                composed: !0
            }), this.triggerEvent("set-overflow-map", {
                visible: !1,
                shareOption: this.data.shareOption
            }, {
                bubbles: !0,
                composed: !0
            }), this.triggerEvent("set-pkg-modal", {
                visible: !1
            });
        },
        handleShare: function() {
            this._lxReport("b_ivq39cdg", "click", {}), this.setData({
                modalShow: !1
            }), this.data.luckyCanWeChatCircle ? this.triggerEvent("set-share-slide", {
                visible: !0,
                shareOption: this.data.shareOption
            }) : (this.triggerEvent("set-share-slide", {
                visible: !1,
                shareOption: this.data.shareOption
            }), this.triggerEvent("red-pkg-end", null, {
                bubbles: !0,
                composed: !0
            }), this.triggerEvent("set-overflow-map", {
                visible: !1,
                shareOption: this.data.shareOption
            }, {
                bubbles: !0,
                composed: !0
            }), this.setData({
                modalShow: !1
            }), this.triggerEvent("set-pkg-modal", {
                visible: !1
            }));
        },
        initLuckyStorage: function() {
            (0, o.getItem)("lucky_modal_list") || (0, o.setItem)("lucky_modal_list", []);
        },
        _lxReport: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "click", s = arguments[2], r = this.properties.order || {}, i = {
                order_status: r.orderStatus.value,
                businessType: r.businessType,
                order_id: r.orderViewId
            };
            a.default[t](e, Object.assign({}, i, s));
        }
    },
    attached: function() {
        this.initLuckyStorage(), this.initPkgInfo();
    }
});