function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t) {
    return 0 == t ? "1\b米" : parseFloat(t) >= 1 ? t.toFixed(1) + "公里" : 1e3 * t + "米";
}

t(require("../../../../libs/regenerator-runtime/runtime-module.js"));

var a = require("../../../../modules/api/route.js"), s = t(require("../../../../modules/api/lx.js")), o = require("../../../../modules/utils/goodsValue.js"), i = 0;

Component({
    properties: {
        order: {
            type: Object,
            value: null,
            observer: function(t) {
                var a = this, s = [ t.goodsNames ], i = t.businessType, r = Number(t.total);
                if (1 === i) {
                    var u = t.goodsWeight;
                    (0, o.validateGoodsValue)(t.goodsMinValue, t.goodsMaxValue) && s.push((0, o.formatGoodsValue)([ t.goodsMinValue, t.goodsMaxValue ])), 
                    s.push(u >= 5 ? u + "公斤" : "小于5公斤");
                } else t.goodsValue && s.push("预估商品费" + t.goodsValue + "元"), t.goodsPayStatus && t.goodsPayStatus.value && (r += Number(t.goodsPayAmount), 
                r = Math.round(100 * r) / 100);
                this.setData({
                    orderViewId: t.orderViewId,
                    goodsInfoArr: s,
                    distance: e(t.distance),
                    nearby: 1 == t.businessTypeTag,
                    totalFee: r
                }, function() {
                    a._compareWidth();
                });
            }
        },
        luckyIconStatus: {
            type: Number,
            value: 0,
            observer: function(t) {
                this.setData({
                    luckyFloatStatus: t
                });
            }
        },
        autoPopRedPackage: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        isShowPriceDetail: !1,
        goodsInfoArr: [],
        arrowPriceUp: 0,
        distance: 0,
        showArrow: !1,
        arrowUp: 0,
        nearby: !1,
        totalFee: 0,
        orderViewId: 0,
        pkgModalShow: !1,
        sharePkgIcon: "https://vfile.meituan.net/paotui/jjxqdqa6od.png",
        showShareIcon: !1,
        luckyFloatStatus: 1,
        luckyBtnTimeout: 3e3,
        shareOption: {}
    },
    attached: function() {
        var t = this;
        i = setTimeout(function() {
            t.setData({
                luckyFloatStatus: 0
            });
        }, this.data.luckyBtnTimeout);
    },
    methods: {
        _compareWidth: function() {
            var t = this, e = wx.createSelectorQuery().in(this);
            e.select(".goodsInfo").boundingClientRect(), e.select(".hiddenWidth").boundingClientRect(), 
            e.exec(function(e) {
                e[0] && void 0 !== e[0].width && t.setData({
                    showArrow: e[1].width >= e[0].width || e[1].height >= e[0].height
                });
            });
        },
        showPriceDetail: function() {
            var t = this.data.order;
            s.default.click("b_2da8iwev", {
                order_id: t.orderViewId,
                order_status: t.orderStatus.value,
                businessType: t.businessType
            }), this.setData({
                isShowPriceDetail: !this.data.isShowPriceDetail,
                arrowPriceUp: 0 == this.data.arrowPriceUp ? 180 : 0
            });
        },
        showMore: function() {
            if (this.data.showArrow) {
                var t = this.data.order;
                s.default.click("b_gzzwwca4", {
                    order_id: t.orderViewId,
                    order_status: t.orderStatus.value,
                    businessType: t.businessType
                }), 0 === this.data.arrowUp ? this.setData({
                    arrowUp: 180
                }) : this.setData({
                    arrowUp: 0
                });
            }
        },
        setPkgModal: function(t) {
            var e = t.detail.visible, a = void 0 !== e && e;
            this.setData({
                pkgModalShow: a
            });
        },
        setLuckyFloatBtnShow: function(t) {
            var e = t.detail.visible, a = void 0 !== e && e;
            this.setData({
                showShareIcon: a
            }), a && this._lxReport("b_ll08thgr", "view", {});
        },
        setIconStatus: function() {
            var t = this;
            clearTimeout(i), 0 === this.data.luckyFloatStatus ? (this._lxReport("b_sdlqsry0", "click", {}), 
            this.setData({
                luckyFloatStatus: 1
            }), this.triggerEvent("async-lucky-icon-status", {
                value: 1
            }), i = setTimeout(function() {
                t.setData({
                    luckyFloatStatus: 0
                });
            }, this.data.luckyBtnTimeout)) : 1 === this.data.luckyFloatStatus && (this._lxReport("b_a0g0dfzd", "click", {}), 
            this.setShareModal(), i = setTimeout(function() {
                t.setData({
                    luckyFloatStatus: 0
                });
            }, this.data.luckyBtnTimeout));
        },
        setShareModal: function() {
            this.setData({
                pkgModalShow: !0
            });
        },
        setShareSlide: function(t) {
            var e = t.detail, a = e.visible, s = void 0 !== a && a, o = e.shareOption, i = void 0 === o ? {} : o;
            this.setData({
                shareOption: i
            }), this.setData({
                shareSlideShow: s
            }), this.setData({
                pkgModalShow: !1
            }), s && this._lxReport("b_672ce0wx", "view", {});
        },
        handleShareTap: function(t) {
            "moments" === t.detail.type ? (this._lxReport("b_gmbwck8s", "click", {}), (0, a.navigateTo)({
                url: "/marketing/pages/shareMoments/shareMoments?couponType=lucky&orderViewId=" + this.data.orderViewId
            })) : this._lxReport("b_9byfcl8h", "click", {}), this.triggerEvent("red-pkg-end", {
                bubbles: !0,
                composed: !0
            }), this.triggerEvent("set-overflow-map", {
                visible: !1,
                shareOption: this.data.shareOption
            }, {
                bubbles: !0,
                composed: !0
            });
        },
        shareCancel: function() {
            this.triggerEvent("red-pkg-end", {
                bubbles: !0,
                composed: !0
            }), this.triggerEvent("set-overflow-map", {
                visible: !1,
                shareOption: this.data.shareOption
            }, {
                bubbles: !0,
                composed: !0
            });
        },
        _lxReport: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "click", a = arguments[2], o = this.properties.order || {}, i = {
                order_status: o.orderStatus.value,
                businessType: o.businessType,
                order_id: o.orderViewId
            };
            s.default[e](t, Object.assign({}, i, a));
        }
    }
});