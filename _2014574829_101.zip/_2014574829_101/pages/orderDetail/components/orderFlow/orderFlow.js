!function(e) {
    e && e.__esModule;
}(require("../../../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../../../modules/utils/util.js");

Component({
    properties: {
        flow: {
            type: Object,
            value: null,
            observer: function(t) {
                var r = t.map(function(t) {
                    return {
                        text: t.orderFlowStatus.text,
                        time: (0, e.timeToDate)(1e3 * t.flowStatusTime)
                    };
                });
                this.setData({
                    flowList: r
                });
            }
        }
    },
    data: {
        flowList: []
    }
});