function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function r(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, t) {
            function n(a, s) {
                try {
                    var u = r[a](s), i = u.value;
                } catch (e) {
                    return void t(e);
                }
                if (!u.done) return Promise.resolve(i).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(i);
            }
            return n("next");
        });
    };
}

var t = e(require("../../../../libs/regenerator-runtime/runtime-module.js")), n = e(require("../../../../modules/api/lx.js")), a = require("../../../../modules/api/wx");

Component({
    properties: {
        order: {
            type: Object,
            value: null,
            observer: function(e) {
                this.setData({
                    businessType: e.businessType
                }), e.pickupImages && this.setData({
                    pickupImages: e.pickupImages.toString().replace(/[[\]]/g, "").replace(/"/g, "").split(",")
                }), e.merchantCloseConfig && e.merchantCloseConfig.closeImages && this.setData({
                    closeImages: JSON.parse(e.merchantCloseConfig.closeImages)
                });
            }
        }
    },
    data: {
        closeImages: [],
        pickupImages: []
    },
    methods: {
        handleImageTap: function(e) {
            var n = this;
            return r(t.default.mark(function r() {
                return t.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, (0, a.previewImage)({
                            current: e.currentTarget.dataset.url,
                            urls: n.data.imageList
                        });

                      case 2:
                        n._lxReport("b_epevzegb");

                      case 3:
                      case "end":
                        return r.stop();
                    }
                }, r, n);
            }))();
        },
        previewCloseImage: function(e) {
            var n = this;
            return r(t.default.mark(function r() {
                return t.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, (0, a.previewImage)({
                            current: e.currentTarget.dataset.url,
                            urls: n.data.closeImages
                        });

                      case 2:
                      case "end":
                        return r.stop();
                    }
                }, r, n);
            }))();
        },
        previewPickupImage: function(e) {
            var n = this;
            return r(t.default.mark(function r() {
                return t.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, (0, a.previewImage)({
                            current: e.currentTarget.dataset.url,
                            urls: n.data.pickupImages
                        });

                      case 2:
                        n._lxReport("b_m525azxt");

                      case 3:
                      case "end":
                        return r.stop();
                    }
                }, r, n);
            }))();
        },
        _lxReport: function(e) {
            var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "click", t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, a = this.data.order, s = {
                order_status: a.orderStatus.value,
                businessType: a.businessType,
                order_id: a.orderViewId
            };
            n.default[r](e, Object.assign({}, s, t));
        }
    }
});