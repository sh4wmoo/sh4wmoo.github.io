function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function r(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, t) {
            function n(o, a) {
                try {
                    var i = r[o](a), s = i.value;
                } catch (e) {
                    return void t(e);
                }
                if (!i.done) return Promise.resolve(s).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(s);
            }
            return n("next");
        });
    };
}

var t = e(require("../../../../libs/regenerator-runtime/runtime-module.js")), n = require("../../../../modules/api/route.js"), o = require("../../../../modules/api/request"), a = require("../../../../modules/api/urls"), i = require("../../../../modules/utils/util"), s = e(require("../../../../modules/api/lx")), d = require("../../../../modules/api/wx.js"), u = !1;

(0, d.getStorage)({
    key: "usedPrivacy"
}).then(function(e) {
    e && (u = e);
}).catch(function(e) {}), Component({
    properties: {
        orderStatus: {
            type: Number
        },
        businessType: {
            type: Number
        },
        orderViewId: {
            type: String
        },
        riderPhone: {
            type: String
        },
        show: {
            type: Boolean,
            value: !1,
            observer: function(e) {
                e ? this.initPrivacyPhone() : this.setData({
                    modalShow: !1
                });
            }
        }
    },
    data: {
        modalShow: !1,
        showedUserPhone: "--",
        inputPhone: "",
        showBeginnerGuide: !1,
        phoneFocus: !1,
        type: "normal",
        slotOption: {
            body: !0,
            footer: !0
        },
        canCall: !0,
        privacyTipsMsg: "",
        privacyTipsUrl: ""
    },
    methods: {
        initPrivacyPhone: function() {
            var e = this;
            return this.riderPrivacyPhone = "", (0, o.postInfo)(a.newRiderPhoneApi, {
                orderViewId: this.properties.orderViewId
            }).then(function() {
                var n = r(t.default.mark(function r(n) {
                    var o, a, i;
                    return t.default.wrap(function(r) {
                        for (;;) switch (r.prev = r.next) {
                          case 0:
                            if (0 !== n.code || !n.data.isPrivacy) {
                                r.next = 20;
                                break;
                            }
                            return e.userBindPhone = n.data.userBindPhone, e.riderPrivacyPhone = n.data.riderPhoneNumber, 
                            o = e.getShowedPhone(e.userBindPhone), a = n.data.privacyTipsMsg || "", i = n.data.privacyTipsUrl || "", 
                            e.setData({
                                modalShow: !0,
                                type: "normal",
                                showedUserPhone: o,
                                showBeginnerGuide: !u,
                                privacyTipsMsg: a,
                                privacyTipsUrl: i
                            }), e.triggerEvent("show"), u = !0, r.prev = 9, r.next = 12, (0, d.setStorage)({
                                key: "usedPrivacy",
                                data: !0
                            });

                          case 12:
                            r.next = 17;
                            break;

                          case 14:
                            r.prev = 14, r.t0 = r.catch(9), console.error("e");

                          case 17:
                            e._lxReport("b_q1423dlh", "view"), r.next = 21;
                            break;

                          case 20:
                            0 !== n.code || n.data.isPrivacy ? e.properties.riderPhone ? (e.setData({
                                modalShow: !0,
                                type: "error",
                                errorText: "隐私保护服务不稳定"
                            }), e.triggerEvent("show")) : wx.showToast({
                                icon: "none",
                                title: n.message || "服务器开小差啦，请重试"
                            }) : (e._lxReport("b_8j5hfs5b", "view"), e.riderPhone = n.data.riderPhoneNumber, 
                            e.setData({
                                modalShow: !0,
                                type: "degrade",
                                errorText: "隐私号服务系统维护中"
                            }), e.triggerEvent("show"));

                          case 21:
                          case "end":
                            return r.stop();
                        }
                    }, r, e, [ [ 9, 14 ] ]);
                }));
                return function(e) {
                    return n.apply(this, arguments);
                };
            }()).catch(function() {
                e.properties.riderPhone ? (e.setData({
                    modalShow: !0,
                    type: "error",
                    errorText: "网络环境异常"
                }), e.triggerEvent("show")) : wx.showToast({
                    icon: "none",
                    title: "网络异常，请稍后再试"
                });
            });
        },
        getShowedPhone: function(e) {
            return e.length < 8 ? e : /^\d+$/.test(e) ? e.replace(/^(\d+)(\d{4})(\d{4})$/, function() {
                for (var e = arguments.length, r = Array(e), t = 0; t < e; t++) r[t] = arguments[t];
                return r.slice(1, 4).join(" ");
            }) : e;
        },
        handleEditClick: function() {
            this._lxReport("b_sb0nihgq"), this.setData({
                type: "edit",
                canCall: !1,
                showBeginnerGuide: !1,
                phoneFocus: !0
            }), this._lxReport("b_pkb5iq2c", "view");
        },
        handleUserPhoneInput: function(e) {
            var r = (0, i.escapePhoneNum)(e.detail.value.trim());
            return /^1\d{10}$/.test(r) ? (this.setData({
                canCall: !0
            }), this.changedPhone = r) : this.setData({
                canCall: !1
            }), {
                value: r,
                cursor: e.detail.cursor
            };
        },
        handleCancel: function() {
            var e = this;
            "edit" === this.data.type ? (this._lxReport("b_7os0wgw3"), this.setData({
                phoneFocus: !1
            }), setTimeout(function() {
                e.setData({
                    type: "normal",
                    canCall: !0,
                    inputPhone: ""
                });
            }, 500)) : ("degrade" === this.data.type ? this._lxReport("b_9mbi0wca") : this._lxReport("b_p1pmdltb"), 
            this.triggerEvent("cancel"));
        },
        handleCall: function() {
            var e = this;
            return r(t.default.mark(function n() {
                return t.default.wrap(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        if (e.data.canCall) {
                            n.next = 2;
                            break;
                        }
                        return n.abrupt("return");

                      case 2:
                        if (e.setData({
                            showBeginnerGuide: !1
                        }), "edit" !== e.data.type) {
                            n.next = 8;
                            break;
                        }
                        return e._lxReport("b_pou49vqt"), n.abrupt("return", (0, o.postInfo)(a.updateBindPhoneApi, {
                            orderViewId: e.properties.orderViewId,
                            bindPhone: e.changedPhone
                        }).then(function() {
                            var n = r(t.default.mark(function r(n) {
                                return t.default.wrap(function(r) {
                                    for (;;) switch (r.prev = r.next) {
                                      case 0:
                                        if (0 !== n.code || !n.data.isPrivacy || !n.data.riderPhoneNumber) {
                                            r.next = 15;
                                            break;
                                        }
                                        return e.riderPrivacyPhone = n.data.riderPhoneNumber, e.userBindPhone = e.changedPhone, 
                                        e.setData({
                                            showedUserPhone: e.getShowedPhone(e.userBindPhone)
                                        }), r.prev = 4, r.next = 7, (0, d.makePhoneCall)({
                                            phoneNumber: e.riderPrivacyPhone || e.properties.riderPhone
                                        });

                                      case 7:
                                        e.triggerEvent("confirm"), r.next = 13;
                                        break;

                                      case 10:
                                        r.prev = 10, r.t0 = r.catch(4), console.error(r.t0);

                                      case 13:
                                        r.next = 16;
                                        break;

                                      case 15:
                                        0 !== n.code || n.data.isPrivacy ? e.properties.riderPhone ? e.setData({
                                            type: "error",
                                            errorText: "隐私保护服务不稳定"
                                        }) : wx.showToast({
                                            icon: "none",
                                            title: n.message || "服务器开小差啦，请重试"
                                        }) : (e.setData({
                                            type: "degrade",
                                            errorText: "隐私号服务系统维护中"
                                        }), e._lxReport("b_8j5hfs5b", "view"));

                                      case 16:
                                      case "end":
                                        return r.stop();
                                    }
                                }, r, e, [ [ 4, 10 ] ]);
                            }));
                            return function(e) {
                                return n.apply(this, arguments);
                            };
                        }()).catch(function() {
                            e.properties.riderPhone ? e.setData({
                                type: "error",
                                errorText: "网络环境异常"
                            }) : wx.showToast({
                                icon: "none",
                                title: "网络异常，请稍后再试"
                            });
                        }));

                      case 8:
                        return "degrade" === e.data.type ? e._lxReport("b_ni0gipwh") : e._lxReport("b_ofh34awh"), 
                        n.prev = 9, n.next = 12, (0, d.makePhoneCall)({
                            phoneNumber: e.riderPrivacyPhone || e.properties.riderPhone || e.riderPhone
                        });

                      case 12:
                        e.triggerEvent("confirm"), n.next = 18;
                        break;

                      case 15:
                        n.prev = 15, n.t0 = n.catch(9), console.error(n.t0);

                      case 18:
                      case "end":
                        return n.stop();
                    }
                }, n, e, [ [ 9, 15 ] ]);
            }))();
        },
        _lxReport: function(e) {
            var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "click", t = arguments[2], n = {
                order_status: this.properties.orderStatus,
                businessType: this.properties.businessType,
                order_id: this.properties.orderViewId
            };
            s.default[r](e, Object.assign({}, n, t));
        },
        goToPrivacyRecordPage: function() {
            this.data.privacyTipsUrl && (0, n.navigateTo)({
                url: "/pages/webView/webView?url=" + encodeURIComponent(this.data.privacyTipsUrl)
            });
        }
    }
});