function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function i(a, n) {
                try {
                    var s = t[a](n), o = s.value;
                } catch (e) {
                    return void r(e);
                }
                if (!s.done) return Promise.resolve(o).then(function(e) {
                    i("next", e);
                }, function(e) {
                    i("throw", e);
                });
                e(o);
            }
            return i("next");
        });
    };
}

var r = e(require("../../../../libs/regenerator-runtime/runtime-module.js")), i = require("../../../../modules/api/route.js"), a = require("../../../../modules/utils/orderStatus.js"), n = require("../../../../constants.js"), s = require("../../../../modules/utils/util.js"), o = e(require("../../../../modules/api/lx.js")), u = require("../../../../modules/api/wx.js"), d = require("../../../../modules/utils/abtest.js"), l = require("../../../../modules/utils/subscribeMessage.js");

Component({
    properties: {
        order: {
            type: Object,
            value: null,
            observer: function(e) {
                clearInterval(this.data.timer);
                var t = e.orderStatus.value, r = e.businessType, i = (0, a.statusConfig)(r)[t];
                if (this.setData({
                    statusVal: t,
                    status: i
                }), this._lx(e), 1 == t) {
                    var n = e.detailTime;
                    if (n && n.payLimitTime && n.currentTime) {
                        var o = n.payLimitTime - n.currentTime;
                        return void this._countDown(o);
                    }
                    this.setData({
                        countDownTime: 15
                    });
                }
                if ((2 == t || 21 == t) && 0 == e.pickupTime) {
                    var u = e.detailTime;
                    if (!(u && u.midTime && u.currentTime)) return void this.setData({
                        "detailTime.down": !1,
                        "detailTime.up": !1,
                        "detailTime.default": !0
                    });
                    var l = u.midTime - u.currentTime, c = u.currentTime - u.createTime;
                    21 != t && l > 0 ? (this.setData({
                        "detailTime.down": !0,
                        "detailTime.up": !1,
                        "detailTime.default": !1
                    }), this._countDown(l)) : (this.setData({
                        "detailTime.down": !1,
                        "detailTime.up": !0,
                        "detailTime.default": !1
                    }), this._countUp(c, u.endTime));
                }
                if ((2 == t || 21 == t) && e.pickupTime > 0) {
                    var m = e.pickupTime, h = m ? 1e3 * m : 0;
                    this.setData({
                        pickupTime: (0, s.timeToDate)(h)
                    });
                }
                4 == t && this.setData({
                    pickupImages: e.pickupImages.toString().replace(/[[\]]/g, "").replace(/"/g, "").split(",")
                }), e.merchantCloseConfig && e.merchantCloseConfig.closeImages && this.setData({
                    closeImages: JSON.parse(e.merchantCloseConfig.closeImages)
                }), 2 !== t && 21 !== t || !e.orderDetailUrgeGrabInfo || 1 !== e.orderDetailUrgeGrabInfo.urgeGrabDegrade || "B" !== d.globalConfig.testIdMapping.urge_grab ? this.setData({
                    isShowUrgeOrderBtn: !1
                }) : this.setData({
                    isShowUrgeOrderBtn: !0
                });
            }
        },
        shareOrderInfo: {
            type: Object,
            value: null
        }
    },
    detached: function() {
        clearInterval(this.data.timer);
    },
    data: {
        status: {},
        statusVal: 0,
        isShowSwiper: !1,
        countDownTime: "",
        detailTime: {
            down: !0,
            up: !1,
            end: !1,
            default: !1
        },
        swiperImages: [],
        closeImages: [],
        pickupImages: [],
        pickupTime: 0,
        timer: null,
        isShowUrgeOrderBtn: !1
    },
    methods: {
        _countDown: function(e) {
            var t = this;
            if (e <= 0) this.setData({
                countDownTime: "0:00"
            }); else {
                var r = setInterval(function() {
                    e -= 1;
                    var i = Math.floor(e / 60), a = e % 60;
                    t.setData({
                        countDownTime: i + ":" + (a < 10 ? "0" + a : a)
                    }), e <= 0 && (clearInterval(r), t.triggerEvent("countdownend"));
                }, 1e3);
                this.setData({
                    timer: r
                });
            }
        },
        _countUp: function(e, t) {
            var r = this;
            if (+new Date() > 1e3 * t) this.setData({
                "detailTime.up": !1,
                "detailTime.end": !0
            }); else {
                var i = setInterval(function() {
                    e += 1;
                    var a = Math.floor(e / 60), n = e % 60;
                    r.setData({
                        countDownTime: a + ":" + (n < 10 ? "0" + n : n)
                    }), +new Date() > 1e3 * t && (clearInterval(i), r.triggerEvent("countupend"));
                }, 1e3);
                this.setData({
                    timer: i
                });
            }
        },
        orderCancel: function() {
            this.triggerEvent("cancelorder", this.data.order);
        },
        changeOrder: function() {
            this.triggerEvent("changeorder", this.data.order);
        },
        handleInvoiceTap: function() {
            var e = this;
            return t(r.default.mark(function t() {
                var a;
                return r.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!(a = e.data.order).invoiceDetailConfig) {
                            t.next = 9;
                            break;
                        }
                        if (0 !== a.invoiceDetailConfig.invoiceStatus) {
                            t.next = 8;
                            break;
                        }
                        return t.next = 5, (0, l.subscribeOnInvoice)();

                      case 5:
                        (0, i.navigateTo)({
                            url: "/preference/pages/invoiceContainer/invoiceContainer"
                        }), t.next = 9;
                        break;

                      case 8:
                        (0, i.navigateTo)({
                            url: "/pages/webView/webView?url=" + encodeURIComponent(a.invoiceDetailConfig.invoiceHistoryUrl)
                        });

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, t, e);
            }))();
        },
        preventD: function() {},
        callServer: function() {
            var e = this;
            return t(r.default.mark(function t() {
                var i;
                return r.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return i = e.data.order, o.default.click("b_jlwip9yy", {
                            order_id: i.orderViewId,
                            businessType: i.businessType,
                            order_status: i.orderStatus.value
                        }), t.prev = 2, t.next = 5, (0, u.makePhoneCall)({
                            phoneNumber: n.SERVICE_PHONE
                        });

                      case 5:
                        t.next = 10;
                        break;

                      case 7:
                        t.prev = 7, t.t0 = t.catch(2), console.error(t.t0);

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, t, e, [ [ 2, 7 ] ]);
            }))();
        },
        hideSwiper: function(e) {
            this.setData({
                isShowSwiper: !1
            }), this.triggerEvent("showMap");
        },
        showCloseSwiper: function() {
            this.setData({
                isShowSwiper: !0,
                swiperImages: this.data.closeImages
            }), this.triggerEvent("hideMap");
        },
        showPickupSwiper: function() {
            var e = this.data.order;
            o.default.click("b_m525azxt", {
                order_id: e.orderViewId,
                businessType: e.businessType,
                order_status: e.orderStatus.value
            }), this.setData({
                isShowSwiper: !0,
                swiperImages: this.data.pickupImages
            }), this.triggerEvent("hideMap");
        },
        toPay: function() {
            this.triggerEvent("pay");
        },
        showFlow: function() {
            this.triggerEvent("showflow");
        },
        _lx: function(e) {
            var t = e.orderStatus.value, r = e.businessType, i = (0, a.statusConfig)(r)[t], n = {
                order_id: e.orderViewId,
                businessType: r,
                order_status: t
            };
            i.hasCancelBtn && o.default.view("b_rhkeg79h", n), i.hasPayBtn && o.default.view("b_dlom4mkl", n), 
            i.hasTopCallServer && o.default.view("b_lfmnjy4r", n), i.hasAgain && o.default.view("b_85oihwi1", n), 
            i.hasCheckRefundStatus && o.default.view("b_shvxobtj", n), i.hasShareBtn && this.properties.shareOrderInfo && o.default.view("b_banma_lb8qilpz_mv", n), 
            i.hasCommentBtn && 1 === e.commentStatus && o.default.view("b_11omg0iz", n), e.goodsCode && o.default.view("b_voeubj3u", n), 
            i.hasProductPayBtn && 0 === e.goodsPayStatus.value && o.default.view("b_njhb35tm", n), 
            1 !== e.modifyStatus && 3 !== e.modifyStatus || o.default.view("b_banma_vmqonbcl_mv", n), 
            2 !== t && 21 !== t || !e.orderDetailUrgeGrabInfo || 1 !== e.orderDetailUrgeGrabInfo.urgeGrabDegrade || "B" !== d.globalConfig.testIdMapping.urge_grab || o.default.view("b_banma_qw28hmhn_mv", n);
        },
        oneMoreOrder: function() {
            var e = this.data.order, t = e.orderViewId, r = e.businessType, a = {
                order_id: t,
                order_status: e.orderStatus.value,
                businessType: r
            };
            o.default.click("paotui_c_orddtl_omrord_ck", a), r === n.BUSINESS_TYPE_BUY ? (0, 
            i.navigateTo)({
                url: "/order/pages/orderBuy/orderBuy?oneMoreOrderId=" + this.data.order.orderViewId
            }) : r === n.BUSINESS_TYPE_DELIVERY && (0, i.navigateTo)({
                url: "/order/pages/orderConfirm/orderConfirm?originType=detail&oneMoreOrderId=" + this.data.order.orderViewId
            });
        },
        pickTipFee: function() {
            this.triggerEvent("pick-tip-fee", this.data.orderInfo);
        },
        commentOrder: function() {
            var e = this.data.order, t = e.orderViewId, r = e.businessType, a = e.orderStatus.value;
            o.default.click("b_8w7clnr4", {
                order_id: t,
                order_status: a,
                businessType: r
            }), (0, i.navigateTo)({
                url: "/comment/pages/commentEdit/commentEdit?orderViewId=" + this.data.order.orderViewId
            });
        },
        payProduct: function() {
            this.triggerEvent("payProduct");
            var e = this.data.order;
            o.default.click("b_b1leg732", {
                order_id: e.orderViewId,
                businessType: e.businessType,
                order_status: e.orderStatus.value
            });
        },
        urgeOrder: function() {
            this.triggerEvent("urgeOrder");
        },
        handlePayInstructionTap: function() {
            this.triggerEvent("showInstruction");
        }
    }
});