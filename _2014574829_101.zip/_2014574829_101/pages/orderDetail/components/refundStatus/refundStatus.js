function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

e(require("../../../../libs/regenerator-runtime/runtime-module.js"));

var r = e(require("../../../../modules/api/lx")), n = require("../../../../modules/api/urls.js"), a = require("../../../../modules/api/route.js");

Component({
    data: {
        refundStatusColor: "#333333;"
    },
    properties: {
        order: {
            type: Object,
            value: null,
            observer: function(e) {
                var n = e.refundDetail.refundState, a = "#333333;";
                1 === n ? a = "#FF6F00;" : 3 !== n && 4 !== n || (a = "#FF4D2F;"), this.setData({
                    refundStatusColor: a
                }), e.cancelFeeAppealInfo && e.cancelFeeAppealInfo.supportAppealDisplay && r.default.view("b_banma_yjde3016_mv", {
                    order_id: e.orderViewId,
                    businessType: e.businessType,
                    cancel_condtion: e.cancelFeeAppealInfo.preCanceledStatus
                });
            }
        }
    },
    methods: {
        toRefundDetail: function() {
            var e = this.properties.order, n = e.orderViewId, t = e.businessType, i = e.orderStatus;
            (0, a.navigateTo)({
                url: "/cancel/pages/refundDetail/refundDetail?orderViewId=" + n
            }), r.default.click("b_xkuywlww", {
                order_id: n,
                businessType: t,
                order_status: i.value
            });
        },
        handleCancelFeeDoubt: function() {
            var e = this.properties.order, t = e.orderViewId, i = e.businessType, s = e.cancelFeeAppealInfo;
            s.appealed ? (0, a.navigateTo)({
                url: "/cancel/pages/cancelFeeRefund/cancelFeeRefund?orderViewId=" + t + "&from=orderDetail&businessType=" + this.businessType + "&cancelCondition=" + this.cancelCondition
            }) : (0, a.navigateTo)({
                url: "/pages/webView/webView?need_params=true&url=" + encodeURIComponent(n.h5.cancelFeeRule + "?orderViewId=" + t + "&action=true&businessType" + i + "&cancelCondition=" + s.preCanceledStatus + "&btnText=" + (s.cancelRuleButtonDesc || ""))
            }), r.default.click("b_banma_yjde3016_mc", {
                order_id: t,
                businessType: i,
                cancel_condtion: s.preCanceledStatus
            });
        }
    }
});