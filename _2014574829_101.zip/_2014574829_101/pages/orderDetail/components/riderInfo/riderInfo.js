function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, r) {
            function a(s, i) {
                try {
                    var n = e[s](i), o = n.value;
                } catch (t) {
                    return void r(t);
                }
                if (!n.done) return Promise.resolve(o).then(function(t) {
                    a("next", t);
                }, function(t) {
                    a("throw", t);
                });
                t(o);
            }
            return a("next");
        });
    };
}

var r = t(require("../../../../libs/regenerator-runtime/runtime-module.js")), a = require("../../../../modules/api/route.js"), s = t(require("../../../../modules/api/lx.js")), i = require("../../../../modules/api/wx.js"), n = "https://p0.meituan.net/paotui/j81idqpwtro1or.png", o = "https://p0.meituan.net/paotui/j81idtsha1nhfr.png", u = "https://p1.meituan.net/paotui/j81ids2giz4cxr.png";

Component({
    properties: {
        order: {
            type: Object,
            value: null,
            observer: function(t) {
                this.setData({
                    riderInfo: t.rider,
                    score: parseInt(100 * (t.rider.satisfactionRatio || 0)),
                    orderViewId: t.orderViewId,
                    privacyInfo: t.privacyInfo
                }), this.setStarsCount(t.rider.star);
            }
        }
    },
    data: {
        riderInfo: {},
        score: 0,
        starsCount: {
            light: [],
            half: [],
            grey: []
        },
        showPrivacyModal: !1
    },
    methods: {
        setStarsCount: function(t) {
            switch (t) {
              case 1:
                this.setData({
                    starsCount: {
                        light: [ n ],
                        half: [],
                        grey: [ u, u, u, u ]
                    }
                });
                break;

              case 2:
                this.setData({
                    starsCount: {
                        light: [ n, n ],
                        half: [],
                        grey: [ u, u, u ]
                    }
                });
                break;

              case 3:
                this.setData({
                    starsCount: {
                        light: [ n, n, n ],
                        half: [],
                        grey: [ u, u ]
                    }
                });
                break;

              case 3.5:
                this.setData({
                    starsCount: {
                        light: [ n, n, n ],
                        half: [ o ],
                        grey: [ u ]
                    }
                });
                break;

              case 4:
                this.setData({
                    starsCount: {
                        light: [ n, n, n, n ],
                        half: [],
                        grey: [ u ]
                    }
                });
                break;

              case 4.5:
                this.setData({
                    starsCount: {
                        light: [ n, n, n, n ],
                        half: [ o ],
                        grey: []
                    }
                });
                break;

              case 5:
                this.setData({
                    starsCount: {
                        light: [ n, n, n, n, n ],
                        half: [],
                        grey: []
                    }
                });
                break;

              default:
                this.setData({
                    starsCount: {
                        light: 0,
                        half: 0,
                        grey: 0
                    }
                });
            }
        },
        callRider: function(t) {
            var a = this;
            return e(r.default.mark(function t() {
                var e;
                return r.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!a.data.showPrivacyModal) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return");

                      case 2:
                        if (e = a.data.order, s.default.click("b_ys5137xv", {
                            order_id: e.orderViewId,
                            order_status: e.orderStatus.value,
                            businessType: e.businessType
                        }), !1 !== e.privacySupport) {
                            t.next = 16;
                            break;
                        }
                        if (t.prev = 5, t.t0 = e.rider.phone, !t.t0) {
                            t.next = 10;
                            break;
                        }
                        return t.next = 10, (0, i.makePhoneCall)({
                            phoneNumber: e.rider.phone
                        });

                      case 10:
                        t.next = 15;
                        break;

                      case 12:
                        t.prev = 12, t.t1 = t.catch(5), console.error(t.t1);

                      case 15:
                        return t.abrupt("return");

                      case 16:
                        a.setData({
                            showPrivacyModal: !0
                        });

                      case 17:
                      case "end":
                        return t.stop();
                    }
                }, t, a, [ [ 5, 12 ] ]);
            }))();
        },
        handlePrivacyModalShow: function() {
            this.triggerEvent("showprivacy");
        },
        closePrivacyModal: function() {
            this.setData({
                showPrivacyModal: !1
            }), this.triggerEvent("hideprivacy");
        },
        handlePrivacyTipTap: function() {
            if (this.data.privacyInfo) {
                var t = this.data.privacyInfo.privacyUrl;
                t && (0, a.navigateTo)({
                    url: "/pages/webView/webView?url=" + encodeURIComponent(t)
                });
            }
        }
    }
});