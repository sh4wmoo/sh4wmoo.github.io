function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, n) {
            function i(r, o) {
                try {
                    var a = e[r](o), s = a.value;
                } catch (t) {
                    return void n(t);
                }
                if (!a.done) return Promise.resolve(s).then(function(t) {
                    i("next", t);
                }, function(t) {
                    i("throw", t);
                });
                t(s);
            }
            return i("next");
        });
    };
}

var n = t(require("../../../../libs/regenerator-runtime/runtime-module.js")), i = require("../../../../modules/api/wx"), r = t(require("../../../../modules/utils/debounce.js")), o = require("../../../../modules/utils/storage"), a = t(require("../../../../modules/api/lx.js")), s = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e];
        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
    }
    return t;
};

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && ((0, o.setItem)("usedBuyPayOnline", !0), this._lxReport("b_oklwdloa", "view"));
            }
        },
        order: {
            type: Object,
            value: null,
            observer: function(t) {
                var e = t.pickupImages ? JSON.parse(t.pickupImages) : [], n = e.slice(0, 3);
                this.setData(s({
                    imageList: e,
                    showedImageList: n,
                    price: t.goodsPayAmount ? t.goodsPayAmount : 0,
                    payEnable: !t.goodsPayStatus || 0 === t.goodsPayStatus.value
                }, t.orderDetailConfig));
            }
        }
    },
    data: {
        imageList: [],
        price: 0,
        payEnable: !0,
        tipContentShow: !1,
        cornerUrl: "",
        buyPayOnlineTipsList: []
    },
    ready: function() {
        this.setData({
            tipContentShow: !(0, o.getItem)("usedBuyPayOnline")
        });
    },
    methods: {
        closeSlide: function() {
            this.setData({
                show: !1,
                tipContentShow: !1
            }), this.triggerEvent("close"), this._lxReport("b_yr1863l7");
        },
        switchTip: function() {
            this.setData({
                tipContentShow: !this.data.tipContentShow
            }), this._lxReport("b_l2ji1t0i"), this.data.tipContentShow && this._lxReport("b_g89oe13q", "view");
        },
        handleClickBg: function() {
            this.data.tipContentShow ? this.setData({
                tipContentShow: !1
            }) : this.closeSlide();
        },
        handlePayLater: function() {
            this.setData({
                show: !1,
                tipContentShow: !1
            }), this.triggerEvent("close"), this._lxReport("b_tyvlcva4");
        },
        handleImageTap: function(t) {
            var r = this;
            return e(n.default.mark(function e() {
                return n.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, (0, i.previewImage)({
                            current: t.currentTarget.dataset.url,
                            urls: r.data.imageList
                        });

                      case 2:
                        r._lxReport("b_epevzegb");

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, r);
            }))();
        },
        handlePay: (0, r.default)(function() {
            this.data.payEnable && this.triggerEvent("pay"), this._lxReport("b_juioxznt");
        }, 500),
        handleInstructionTap: function() {
            this.triggerEvent("showInstruction"), this._lxReport("b_z5zr49i8");
        },
        _lxReport: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "click", n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, i = this.data.order, r = {
                order_status: i.orderStatus.value,
                businessType: i.businessType,
                order_id: i.orderViewId
            };
            a.default[e](t, Object.assign({}, r, n));
        }
    }
});