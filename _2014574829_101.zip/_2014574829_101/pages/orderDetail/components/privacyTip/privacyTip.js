!function(e) {
    e && e.__esModule;
}(require("../../../../libs/regenerator-runtime/runtime-module.js"));

var e = require("../../../../modules/api/route.js"), t = null, r = null;

Component({
    properties: {
        tips: {
            type: Array,
            value: [],
            observer: function(e) {
                var i = this;
                this.clearTimer(), this.setData({
                    currentTip: 0,
                    show: !0
                }), e.length >= 2 && (t = setInterval(function() {
                    i.setData({
                        show: !1
                    }), r = setTimeout(function() {
                        i.setData({
                            currentTip: (i.data.currentTip + 1) % e.length,
                            show: !0
                        });
                    }, 300);
                }, 1e4));
            }
        }
    },
    data: {
        currentTip: 0,
        show: !0
    },
    methods: {
        clearTimer: function() {
            clearTimeout(r), r = null, clearInterval(t), t = null;
        },
        goToUrl: function() {
            var t = this.properties.tips[this.data.currentTip].skipUrl;
            t && (t = "/pages/webView/webView?url=" + encodeURIComponent(t), (0, e.navigateTo)({
                url: t
            }));
        }
    },
    detached: function() {
        this.clearTimer();
    }
});