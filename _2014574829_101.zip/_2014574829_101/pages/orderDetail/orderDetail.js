function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function a(i, o) {
                try {
                    var n = t[i](o), s = n.value;
                } catch (e) {
                    return void r(e);
                }
                if (!n.done) return Promise.resolve(s).then(function(e) {
                    a("next", e);
                }, function(e) {
                    a("throw", e);
                });
                e(s);
            }
            return a("next");
        });
    };
}

var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, a = e(require("../../libs/regenerator-runtime/runtime-module.js")), i = require("../../modules/utils/user.js"), o = require("../../modules/api/route.js"), n = require("../../modules/utils/orderStatus.js"), s = require("../../modules/utils/util.js"), d = e(require("../../modules/utils/weather/weather.js")), u = require("../../modules/api/request.js"), c = require("../../modules/api/urls.js"), l = require("../../constants.js"), p = require("../../modules/utils/share.js"), h = require("../../modules/utils/storage.js"), f = require("./mapPoints.js"), w = require("../../modules/utils/pay.js"), m = e(require("../../modules/api/lx.js")), b = require("../../modules/api/wx.js"), v = e(require("../../modules/page.js")), _ = e(require("../../modules/utils/debounce.js")), g = require("../../modules/utils/reportDetailError"), I = require("../../modules/api/cat"), x = require("../../modules/api/metrics.js"), y = require("../../modules/utils/abtest.js"), S = e(require("../../modules/global.js")), k = e(require("../../modules/utils/bmMonitor.js")), T = require("../../modules/utils/subscribeMessage.js"), M = "function" == typeof Symbol && "symbol" === r(Symbol.iterator) ? function(e) {
    return void 0 === e ? "undefined" : r(e);
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : r(e);
}, P = (0, s.getSystemVersion)(S.default.systemInfo), V = S.default.isIOS && (0, 
s.compareVersion)(P, "13.0.0") >= 0, C = {};

(0, v.default)({
    data: {
        orderMap: {
            displayCover: !1,
            coverCallback: null
        },
        initLat: 0,
        initLng: 0,
        animation: "",
        markers: [],
        hasMap: !1,
        hasBottomCallServer: !1,
        scrollTop: 0,
        order: null,
        showOrderViewId: "",
        paddingBottom: 0,
        orderInnerStatus: "",
        createOrderTime: "",
        pickupTime: "",
        errorMap: !1,
        showFakeMap: !1,
        needFakeMap: (0, s.compareVersion)(S.default.systemInfo.SDKVersion, "2.9.0") < 0,
        hasWeather: V,
        slideBgShow: !1,
        slideShow: "hidden",
        flow: null,
        initHidden: "none",
        isShowReturnIndexBtn: !1,
        businessType: 0,
        orderViewId: 0,
        orderStatus: 0,
        tipSlide: {
            tipFeeOrderViewId: "",
            orderToken: "",
            show: !1,
            state: -1,
            disableRight: !1,
            slideStatus: "hidden",
            tipTags: [ {
                id: 0,
                text: "不加了"
            }, {
                id: 5,
                text: "¥ 5"
            }, {
                id: 10,
                text: "¥ 10"
            }, {
                id: 15,
                text: "¥ 15"
            }, {
                id: 20,
                text: "¥ 20"
            }, {
                id: 25,
                text: "¥ 25"
            } ],
            tipFee: 0,
            tipFeeMax: 200
        },
        showProductPay: !1,
        showProductPayInstruction: !1,
        shareOption: {},
        luckyIconStatus: 1,
        orderTipSlotOption: {
            body: !0,
            footer: !0
        },
        orderTipShow: !1,
        safeModalShow: !1,
        autoPopRedPackage: !0,
        cancelOrderModalShow: !1,
        showModifyOrderInfoEntry: !1,
        refuseCancelModalShow: !1,
        refuseCancelModalSlotOption: {
            body: !0,
            footer: !0
        },
        shareOrderInfo: null,
        urgeOrderModalShow: !1,
        urgeGrabTitle: "",
        urgeGrabSubTitle: "",
        cancelCanUrgeGrab: 2
    },
    pageMetricsHandler: null,
    onLoad: function() {
        var e = t(a.default.mark(function e(t) {
            var r, i, n, s = this;
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return this.pageMetricsHandler = (0, x.startMetricsPagePoint)(this, "order_detail_load_full", {
                        num: 2
                    }), r = (0, h.getItem)("actPoint"), i = t.orderViewId, this.inited = !1, this.orderToken = null, 
                    this.fakeMapCount = 0, t && t.channel && (S.default.channel = t.channel, k.default.updateBaseParams({
                        channel: t.channel
                    })), this.setData({
                        initLat: r.lat,
                        initLng: r.lng,
                        mapCtx: wx.createMapContext("orderMap"),
                        orderViewId: i,
                        showOrderViewId: i.replace(/(\d{4})(?=\d)/g, "$1 ")
                    }), p.getHomeShareData.call(this), e.next = 11, (0, u.postInfo)(c.riderShareApi, {});

                  case 11:
                    0 === (n = e.sent).code && this.setData({
                        riderShareCfg: {
                            shareTitle: n.data.shareTitle,
                            shareIcon: n.data.shareIcon,
                            shareContent: n.data.shareContent
                        }
                    }), (0, o.checkIsFirstPage)() && (m.default.view("b_to6x8x6l", {
                        order_status: "",
                        businessType: "",
                        order_id: i
                    }), this.setData({
                        isShowReturnIndexBtn: !0
                    })), this.emit("pay.success", i), this.pageMetricsHandler && this.pageMetricsHandler.add({
                        step: "params_init_finish"
                    }), this.on("orderModify.success", function() {
                        setTimeout(function() {
                            s._init(s.data.orderViewId);
                        }, 2e3);
                    });

                  case 17:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    onUnload: function() {
        clearInterval(this.orderChangeTimer), clearInterval(this.orderFlowTimer), this.mapWeather && this.mapWeather.stop();
    },
    onHide: function() {
        clearInterval(this.orderChangeTimer), clearInterval(this.orderFlowTimer);
    },
    onShow: function() {
        var e = this;
        return t(a.default.mark(function t() {
            var r, i;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    r = e.data, e._init(r.orderViewId).then(function(t) {
                        e.inited = t, e.getOrderFlow(), (0, I.reportMetric)("order_detail_pv"), e._lxVisible();
                    }).catch(function(t) {
                        return e.pageMetricsHandler && e.pageMetricsHandler.end(), !1;
                    }), i = {
                        order_status: "",
                        businessType: "",
                        order_id: r.orderViewId
                    }, m.default.pv("paotui_c_orddtl_sw", i);

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t, e);
        }))();
    },
    tipFeeSubmit: function(e, t, r) {
        var a = {
            orderViewId: e,
            orderToken: t,
            tipFee: r,
            clientType: "wx_app_source"
        };
        return (0, u.postInfo)(c.tipFeeSubmitApi, a);
    },
    openTipSlide: function(e) {
        var r = this;
        return t(a.default.mark(function e() {
            var t, i, o, n, s, d, l, p, h, f;
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r._lxReport("b_4x063jzk"), t = r.data.orderViewId, i = {
                        orderViewId: t,
                        orderToken: r.data.tipSlide.orderToken
                    }, e.next = 5, (0, u.postInfo)(c.tipFeePreviewApi, i);

                  case 5:
                    0 === (o = e.sent).code ? (n = o.data || {}, s = n.tipFees, d = n.tipFeeMax, l = n.tipFeeTotal, 
                    p = void 0, h = void 0, o.data && s ? (h = d - l, p = s.map(function(e) {
                        return {
                            id: e,
                            text: "￥" + e,
                            disabled: e > h
                        };
                    })) : p = r.data.tipSlide.tipTags, f = r.data.tipSlide || {}, f = Object.assign({}, f, {
                        tipTags: p,
                        state: 0,
                        tipFee: r.data.tipSlide.tipFee || p[0].id,
                        tipFeeMax: h,
                        tipFeeTotal: l,
                        orderToken: o.data.orderToken || "",
                        tipFeeOrderViewId: o.data.orderViewId,
                        show: !0,
                        slideStatus: "visible"
                    }), r.setData({
                        tipSlide: f,
                        "orderMap.displayCover": !0,
                        "orderMap.coverCallback": r.tipCancel.bind(r)
                    })) : r.handleTipFeePreviewException(o.code, o.message);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e, r);
        }))();
    },
    handleTipFeePreviewException: function(e, t) {
        switch (e) {
          case 11603:
          case 11604:
            this.toast(t), this._init(this.data.orderViewId);
            break;

          default:
            this.toast(t);
        }
    },
    handleTipFeeSubmitException: function(e, t) {
        this.toast(t), this._init(this.data.orderViewId);
    },
    tipCancel: function() {
        this.setData({
            "orderMap.displayCover": !1,
            "orderMap.coverCallback": null,
            "tipSlide.state": -1,
            "tipSlide.show": !1,
            "tipSlide.slideStatus": "hidden"
        });
    },
    tipConfirm: function(e) {
        this.setData({
            "orderMap.displayCover": !1,
            "orderMap.coverCallback": null,
            "tipSlide.show": !1,
            "tipSlide.slideStatus": "hidden",
            "tipSlide.state": 1
        }), this._lxReport("b_a38na9ch");
    },
    setTipValue: function(e) {
        var r = this;
        return t(a.default.mark(function t() {
            var i, o, n, s, d, l;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!r.tipFeeSubmitting) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return r.tipFeeSubmitting = !0, i = e.detail.value, r.setData({
                        "tipSlide.tipFee": i
                    }), o = {
                        orderViewId: r.data.tipSlide.tipFeeOrderViewId,
                        orderToken: r.data.tipSlide.orderToken,
                        tipFee: i,
                        clientType: "wx_app_source"
                    }, t.prev = 6, t.next = 9, (0, u.postInfo)(c.tipFeeSubmitApi, o);

                  case 9:
                    0 === (n = t.sent).code ? (s = r.data.order, d = s.orderStatus, l = s.businessType, 
                    m.default.order("b_1zo1pg0r", n.data.orderViewId, {
                        order_id: n.data.orderViewId,
                        order_status: d.value,
                        businessType: l
                    }), (0, w.ptPay)({
                        orderViewId: n.data.orderViewId,
                        pay_success_url: "/pages/orderDetail/orderDetail?orderViewId=" + r.data.orderViewId,
                        success: function() {
                            r.toast("小费支付成功，已优先为您通知骑手，请耐心等待"), r._init(r.data.orderViewId);
                        }
                    })) : r.handleTipFeeSubmitException(n.code, n.message), t.next = 16;
                    break;

                  case 13:
                    t.prev = 13, t.t0 = t.catch(6), r.handleTipFeeSubmitException(-1, "当前网络异常，请稍后重试");

                  case 16:
                    return t.prev = 16, r.tipFeeSubmitting = !1, t.finish(16);

                  case 19:
                  case "end":
                    return t.stop();
                }
            }, t, r, [ [ 6, 13, 16, 19 ] ]);
        }))();
    },
    setTipValueOverflow: function(e) {
        this.setData({
            "tipSlide.disableRight": !e.detail.data.valid
        });
    },
    getOrderChangedDetail: function(e) {
        var r = this, i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        return t(a.default.mark(function t() {
            var o, n, d, l, p, h, f;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, u.postInfo)(c.orderDetailChangeApi, {
                        orderViewId: e
                    }, {
                        showLoading: i
                    });

                  case 3:
                    if (0 !== (o = t.sent).code || !o.data) {
                        t.next = 36;
                        break;
                    }
                    if (n = o.data.orderStatus.value, d = o.data.modifyStatus, l = o.data.refundStatus, 
                    n === r.data.orderStatus) {
                        t.next = 16;
                        break;
                    }
                    return r.inited = !1, t.next = 12, r._init(e);

                  case 12:
                    return r.inited = t.sent, t.abrupt("return", r.inited);

                  case 16:
                    if (void 0 === d || d === r.data.order.modifyStatus) {
                        t.next = 24;
                        break;
                    }
                    return r.inited = !1, t.next = 20, r._init(e);

                  case 20:
                    return r.inited = t.sent, t.abrupt("return", r.inited);

                  case 24:
                    if (l === r.data.order.refundDetail.refundState) {
                        t.next = 32;
                        break;
                    }
                    return r.inited = !1, t.next = 28, r._init(e);

                  case 28:
                    return r.inited = t.sent, t.abrupt("return", r.inited);

                  case 32:
                    o.data.latestRiderPoint && (p = o.data.latestRiderPoint, h = p.lat, f = p.lng, r.translateRiderMarker({
                        lat: (0, s.locIntToFloat)(h),
                        lng: (0, s.locIntToFloat)(f)
                    }));

                  case 33:
                    return t.abrupt("return", !0);

                  case 36:
                    return t.abrupt("return", !1);

                  case 37:
                    t.next = 42;
                    break;

                  case 39:
                    return t.prev = 39, t.t0 = t.catch(0), t.abrupt("return", !1);

                  case 42:
                  case "end":
                    return t.stop();
                }
            }, t, r, [ [ 0, 39 ] ]);
        }))();
    },
    handleCountEnd: function() {
        this._init(this.data.orderViewId);
    },
    showProductPaySlide: function(e) {
        this.setData({
            showProductPay: !0
        }), this.switchFakeMap(!0), this._lxReport("b_i3067zip", "view");
    },
    hideProductPaySlide: function() {
        this.data.showProductPay && (this.setData({
            showProductPay: !1
        }), this.switchFakeMap(!1));
    },
    showProductPayInstruction: function() {
        this.setData({
            showProductPayInstruction: !0
        }), this.switchFakeMap(!0);
    },
    hideProductPayInstruction: function() {
        this.data.showProductPayInstruction && (this.setData({
            showProductPayInstruction: !1
        }), this.switchFakeMap(!1));
    },
    handleProductPayError: function(e) {
        var r = this;
        return t(a.default.mark(function t() {
            var i, o;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (10341 !== e.code) {
                        t.next = 14;
                        break;
                    }
                    return t.prev = 1, r.toast(e.message), t.next = 5, (0, u.postInfo)(c.latestPayAmountApi, {
                        orderViewId: r.data.orderViewId
                    });

                  case 5:
                    0 === (i = t.sent).code && ((o = r.data.order).goodsPayAmount = i.data.goodsPayAmount, 
                    o.goodsNeedPay = i.data.goodsNeedPay, r.setData({
                        order: o
                    })), t.next = 12;
                    break;

                  case 9:
                    t.prev = 9, t.t0 = t.catch(1), r.toast("网络异常，请重试");

                  case 12:
                    t.next = 16;
                    break;

                  case 14:
                    r.toast(e.message), 10354 !== e.code && 10355 !== e.code && 10356 !== e.code && 10370 !== e.code || (r.hideProductPaySlide(), 
                    r._init(r.data.orderViewId));

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t, r, [ [ 1, 9 ] ]);
        }))();
    },
    isProductPaying: !1,
    productPay: function() {
        var e = this;
        return t(a.default.mark(function t() {
            var r, o, n, s;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!e.isProductPaying) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return e.isProductPaying = !0, t.prev = 3, t.next = 6, (0, u.postInfo)(c.goodsPayPreviewApi, {
                        orderToken: e.orderToken,
                        orderViewId: e.data.orderViewId,
                        goodsFee: e.data.order.goodsPayAmount
                    });

                  case 6:
                    if (0 === (r = t.sent).code) {
                        t.next = 10;
                        break;
                    }
                    return e.isProductPaying = !1, t.abrupt("return", e.handleProductPayError(r));

                  case 10:
                    return e.orderToken = r.data.orderToken, o = S.default.appId, n = (0, i.getUserInfo)().openId, 
                    t.next = 15, (0, u.postInfo)(c.goodsPaySubmitApi, {
                        orderViewId: e.data.orderViewId,
                        goodsFee: e.data.order.goodsPayAmount,
                        orderToken: e.orderToken,
                        pushToken: "",
                        appId: o,
                        openId: n
                    });

                  case 15:
                    if (0 === (s = t.sent).code) {
                        t.next = 19;
                        break;
                    }
                    return e.isProductPaying = !1, t.abrupt("return", e.handleProductPayError(s));

                  case 19:
                    (0, w.ptPay)({
                        orderViewId: s.data.orderViewId,
                        pay_success_url: "/pages/orderDetail/orderDetail?orderViewId=" + e.data.orderViewId,
                        success: function() {
                            e.isProductPaying = !1, e.toast("商品费支付成功"), e.hideProductPaySlide(), e._init(e.data.orderViewId), 
                            e._lxReport("b_rit6hllm", "order", {
                                order_id: s.data.orderViewId
                            });
                        },
                        mtPayCallback: function() {
                            e.isProductPaying = !1;
                        },
                        fail: function() {
                            e.isProductPaying = !1;
                        },
                        prePayFail: function() {
                            e.isProductPaying = !1;
                        }
                    }), t.next = 26;
                    break;

                  case 22:
                    t.prev = 22, t.t0 = t.catch(3), e.isProductPaying = !1, e.toast("网络异常，请重试");

                  case 26:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 3, 22 ] ]);
        }))();
    },
    getOrderShareInfo: function(e) {
        var r = this;
        return t(a.default.mark(function t() {
            var i, o, n, s, d, l, p, h;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, u.postInfo)(c.orderShareApi, {
                        orderViewId: e
                    }).catch(function() {
                        return Promise.reject(function() {
                            r.setData({
                                shareOrderInfo: null
                            });
                        });
                    });

                  case 3:
                    0 === (i = t.sent).code && i.data && i.data.orderShareToWeChatParam ? (o = i.data.orderShareToWeChatParam, 
                    n = o.title, s = void 0 === n ? "我正用美团跑腿送东西，点击查看骑手实时位置" : n, d = o.sharePath, l = void 0 === d ? "" : d, 
                    p = o.picUrl, h = void 0 === p ? "https://vfile.meituan.net/paotui/jecxy83crpb9.png" : p, 
                    l ? r.setData({
                        shareOrderInfo: {
                            title: s,
                            path: l,
                            imageUrl: h
                        }
                    }) : r.setData({
                        shareOrderInfo: null
                    })) : r.setData({
                        shareOrderInfo: null
                    }), t.next = 17;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(0), t.t1 = void 0 === t.t0 ? "undefined" : M(t.t0), t.next = "string" === t.t1 ? 12 : "function" === t.t1 ? 14 : 16;
                    break;

                  case 12:
                    return r.toast(t.t0), t.abrupt("break", 17);

                  case 14:
                    return t.t0(), t.abrupt("break", 17);

                  case 16:
                    return t.abrupt("break", 17);

                  case 17:
                  case "end":
                    return t.stop();
                }
            }, t, r, [ [ 0, 7 ] ]);
        }))();
    },
    _init: function(e) {
        var r = this;
        return t(a.default.mark(function t() {
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return clearInterval(r.orderChangeTimer), clearInterval(r.orderFlowTimer), t.abrupt("return", (0, 
                    u.postInfo)(c.orderDetail, {
                        orderViewId: e
                    }).then(function(t) {
                        if (r.pageMetricsHandler && r.pageMetricsHandler.add({
                            step: "order_detail_api_success"
                        }), r.error(), r.setData({
                            errorMap: !0
                        }), 0 !== t.code) return r.toast(t.message), !1;
                        var a = t.data, i = a.orderStatus.value, o = a.businessType, d = (0, n.statusConfig)(o)[i].hasBottomCallServer || !1, u = [ 1, 2, 3, 4, 21, 62, 31, 64 ], c = (0, 
                        n.statusConfig)(o)[i];
                        r._setInnerStatus(a), 1 === o && r.showSafeModalIfNeeded(), r.setData({
                            hasMap: c.map || !1,
                            orderStatus: i,
                            businessType: o,
                            hasBottomCallServer: d,
                            order: a,
                            createOrderTime: (0, s.timeFormat)("yyyy-MM-dd hh:mm:ss", new Date(1e3 * a.orderDate)),
                            pickupTime: (0, s.timeToDate)(1e3 * a.pickupTime),
                            initHidden: "block"
                        }), a.policyOfGoodsValue && !a.insurancePkg && m.default.view("b_banma_9kxrok8y_mv"), 
                        !r.inited && 4 === i && 1 === a.goodsNeedPay && a.goodsPayStatus && 0 === a.goodsPayStatus.value && r.showProductPaySlide(a), 
                        r.setMapWeather(a.weatherStatus);
                        var l = (a.orderDetailConfig || {
                            orderChangedInterval: 0
                        }).orderChangedInterval;
                        if (l >= 1 && (1 === i || 2 === i || 3 === i || 4 === i || 7 === i || 61 === i || 62 === i || 64 === i) && (clearInterval(r.orderChangeTimer), 
                        r.orderChangeTimer = setInterval(function(e) {
                            if (!e) {
                                if ((0, g.reportDetailJsError)("setInterval 传参 error", ""), !r.data.orderViewId) return void (0, 
                                g.reportDetailJsError)("data orderViewId 不存在", "");
                                e = r.data.orderViewId;
                            }
                            r.getOrderChangedDetail(e);
                        }, 1e3 * l, r.data.orderViewId)), clearInterval(r.orderFlowTimer), r.orderFlowTimer = setInterval(function() {
                            r.getOrderFlow();
                        }, 3e4), "B" === (y.globalConfig.testIdMapping.order_share || "A") && c.hasShareBtn && r.getOrderShareInfo(e), 
                        a.popupInfo && a.popupInfo.title) {
                            var p = (0, h.getItem)("refuseCancelModalList") || [];
                            -1 === p.indexOf(e) && (r.showRefuseCancelModal(a.popupInfo), p.push(e), p.length > 5 && p.shift(), 
                            (0, h.setItem)("refuseCancelModalList", p));
                        }
                        return r._lxReport("b_nngas4ng", "view"), a.rider && r._lxReport("b_5bxo5yx3", "view"), 
                        a.insurancePkg && r._lxReport("b_xutg7q5z", "view"), d && r._lxReport("b_knyfa367", "view"), 
                        u.includes(a.orderStatus.value) && (r.mapCtx = r.mapCtx || wx.createMapContext("orderMap"), 
                        r._setMap(a)), c.operations && c.operations.isShowTipFeeBtn && r._lxReport("b_yfchlz2f", "view"), 
                        0 === a.commentStatus && r._lxReport("b_u22ah9sf"), !0;
                    }));

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t, r);
        }))();
    },
    _setMap: function(e) {
        var t = this.data.orderInnerStatus, r = e.orderStatus.value, a = (0, f.mapPoints)(e), i = this._filterArr(a[r][t].points);
        this.setData({
            markers: this._filterArr(a[r][t].markers)
        }), i.length > 1 ? this.mapCtx.includePoints({
            padding: S.default.isIOS ? [ 120, 100, 10, 100 ] : [ 80, 100, 10, 100 ],
            points: i
        }) : 1 === i.length && this.mapCtx.moveToLocation({
            longitude: i[0].longitude,
            latitude: i[0].latitude
        });
    },
    translateRiderMarker: function(e) {
        this.mapCtx.translateMarker({
            markerId: f.MARKER_RIRDER,
            duration: 500,
            destination: {
                latitude: e.lat,
                longitude: e.lng
            }
        });
    },
    _filterArr: function(e) {
        return e.filter(function(e) {
            if ("[object Object]" === Object.prototype.toString.call(e)) return e;
        });
    },
    _setInnerStatus: function(e) {
        var t = 2 === e.businessType && 0 === e.businessTypeTag && "hasAddr", r = 2 === e.businessType && 1 === e.businessTypeTag && "noAddr", a = 1 === e.businessType && e.pickupTime && "order", i = 1 === e.businessType && 0 === e.pickupTime && "now";
        this.setData({
            orderInnerStatus: t || r || a || i
        });
    },
    showSafeModalIfNeeded: function() {
        (0, h.getItem)("hasShowedSafeModal") || (this.setData({
            safeModalShow: !0,
            autoPopRedPackage: !1
        }), this.switchFakeMap(!0), (0, h.setItem)("hasShowedSafeModal", !0));
    },
    hideSafeModal: function() {
        this.setData({
            safeModalShow: !1
        }), this.switchFakeMap(!0);
    },
    mapWeather: null,
    setMapWeather: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        0 !== e ? (this.mapWeather ? this.mapWeather.start(e) : this.mapWeather = new d.default("weather", e), 
        V && this._lxReport("b_banma_rk8lntz3_mv", "view", {
            weatherStatus: e
        })) : this.mapWeather && this.mapWeather.stop();
    },
    onShareAppMessage: function(e) {
        if ("button" === e.from) {
            if ("normal" === e.target.dataset.type) {
                var t = this.data.shareOption;
                return {
                    title: t.shareTitle,
                    path: "" + t.shareUrl,
                    imageUrl: t.shareIcon
                };
            }
            return this._lxReport("b_banma_lb8qilpz_mc", "click"), this.data.shareOrderInfo;
        }
        return p.shareApp.call(this, {
            type: "menu"
        });
    },
    onPullDownRefresh: function() {
        this._init(this.data.orderViewId).then(function() {
            wx.stopPullDownRefresh();
        });
    },
    showFlow: function() {
        var e = this;
        return this._lxReport("b_ieohe1t8"), (0, u.postInfo)(c.orderFlow, {
            orderViewId: this.data.orderViewId
        }).then(function(t) {
            return 0 !== t.code ? (e.toast(t.message), !1) : (e.setData({
                flow: t.data.items,
                slideBgShow: !0,
                slideShow: "visible"
            }), e.hideMap(), !0);
        }).catch(function(t) {
            return e.toast("网络异常"), !1;
        });
    },
    getOrderFlow: function() {
        var e = this;
        (0, u.postInfo)(c.orderFlow, {
            orderViewId: this.data.orderViewId
        }).then(function(t) {
            if (10301 === t.code && clearInterval(e.orderFlowTimer), 0 !== t.code) return e.toast(t.message), 
            !1;
            e.setData({
                flow: t.data.items
            });
        }).catch(function(t) {
            e.toast("网络异常");
        });
    },
    closeSlide: function() {
        this.setData({
            slideBgShow: !1,
            slideShow: "hidden"
        }), this.showMap();
    },
    handleCancel: function(e, r) {
        var i = this;
        return t(a.default.mark(function t() {
            var o, n, d;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, T.subscribeOnCancel)({
                        businessType: i.data.businessType,
                        orderViewId: e
                    });

                  case 3:
                    return t.next = 5, (0, u.postInfo)(c.cancelApi, {
                        orderViewId: e,
                        code: 0,
                        reason: "",
                        orderStatus: r || 0
                    });

                  case 5:
                    o = t.sent, n = o.code, d = o.message, 0 === n ? i._init(e) : 10337 === n ? (i._lxReport("b_j4ug90ob", "view", {
                        cancorder_exception_type: o.code
                    }), (0, s.ptShowModal)({
                        title: "提示",
                        content: d,
                        showCancel: !1,
                        confirmText: "我知道了",
                        confirm: function() {
                            return i._init(e);
                        }
                    })) : 0 !== n && (i._lxReport("b_j4ug90ob", "view", {
                        cancorder_exception_type: o.code
                    }), i.toast(d), i._init(e)), t.next = 13;
                    break;

                  case 10:
                    t.prev = 10, t.t0 = t.catch(0), i.toast("网络异常");

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, t, i, [ [ 0, 10 ] ]);
        }))();
    },
    handleCancelPreviewException: function(e, t) {
        this.toast(t), this._init(this.data.orderViewId);
    },
    previewCancelOrder: function() {
        var e = this;
        return t(a.default.mark(function t() {
            var r, i, o;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if ("B" !== y.globalConfig.testIdMapping.urge_grab) {
                        t.next = 16;
                        break;
                    }
                    return t.prev = 1, r = e.data.orderViewId, t.next = 5, (0, u.postInfo)(c.cancelCanUrgeOrderApi, {
                        orderId: r
                    });

                  case 5:
                    return i = t.sent, o = 2, i && 0 === i.code && i.data && (1 !== i.data.cancelCanUrgeGrab && 2 !== i.data.cancelCanUrgeGrab || (o = i.data.cancelCanUrgeGrab)), 
                    t.abrupt("return", o);

                  case 11:
                    return t.prev = 11, t.t0 = t.catch(1), t.abrupt("return", 2);

                  case 14:
                    t.next = 17;
                    break;

                  case 16:
                    return t.abrupt("return", 2);

                  case 17:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 1, 11 ] ]);
        }))();
    },
    cancelOrder: function(e) {
        var r = this;
        return t(a.default.mark(function t() {
            var i, n, d, u, c, l, p, h, f, w;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (i = [ e.detail ], n = i[0], d = i[1], u = void 0 === d ? n.orderViewId : d, 
                    c = i[2], l = void 0 === c ? n.orderStatus.value : c, r._lxReport("paotui_c_orddtl_cnclord_ck"), 
                    1 != l) {
                        t.next = 7;
                        break;
                    }
                    r._lxReport("b_0n4vn7k1"), (0, s.ptShowModal)({
                        content: "确定要取消订单么？",
                        cancelText: "放弃",
                        confirmText: "确定",
                        confirm: function() {
                            return r.handleCancel(u, l);
                        }
                    }), t.next = 21;
                    break;

                  case 7:
                    if (2 !== l && 21 !== l) {
                        t.next = 20;
                        break;
                    }
                    return p = void 0, p = (2 !== n.businessType || 1 !== n.isPrebook) && (1 === n.modifyStatus || 3 === n.modifyStatus), 
                    t.next = 12, r.previewCancelOrder();

                  case 12:
                    h = t.sent, r.setDataAsync({
                        cancelCanUrgeGrab: h,
                        cancelOrderModalShow: !0,
                        showModifyOrderInfoEntry: p
                    }), r._lxReport("b_0n4vn7k1", "view"), 1 === h ? r._lxReport("b_banma_0gob2wll_mv", "view") : r._lxReport("b_z38be0jd", "view"), 
                    r._lxReport("b_qiidvlwi", "view"), p && r._lxReport("b_banma_1sitp4vy_mv", "view"), 
                    t.next = 21;
                    break;

                  case 20:
                    n.popupInfo && n.popupInfo.title ? r.showRefuseCancelModal(n.popupInfo) : (f = r.data.businessType, 
                    w = "/cancel/pages/cancelOrder/cancelOrder", (0, o.navigateTo)({
                        url: w + "?orderViewId=" + u + "&orderStatus=" + l + "&businessType=" + f
                    }));

                  case 21:
                  case "end":
                    return t.stop();
                }
            }, t, r);
        }))();
    },
    changeOrder: function() {
        var e = this.data.orderViewId;
        (0, o.navigateTo)({
            url: "/order/pages/orderModify/orderModify?orderViewId=" + e
        });
    },
    copyOrderNum: function() {
        var e = this;
        return t(a.default.mark(function t() {
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e._lxReport("b_qd2kljsc"), t.prev = 1, t.next = 4, (0, b.setClipboardData)({
                        data: e.data.order.orderViewId
                    });

                  case 4:
                    wx.showToast({
                        title: "复制订单号成功"
                    }), t.next = 10;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(1), wx.showToast({
                        title: "复制失败，您可尝试长按订单号码复制"
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 1, 7 ] ]);
        }))();
    },
    handleOverflowMap: function(e) {
        var t = e.detail, r = t.visible, a = void 0 === r || r, i = t.shareOption, o = void 0 === i ? {} : i;
        this.setData({
            shareOption: o
        }), this.switchFakeMap(a);
    },
    switchFakeMap: function() {
        !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0] ? (this.fakeMapCount++, 
        this.setData({
            showFakeMap: !0
        })) : --this.fakeMapCount <= 0 && this.setData({
            showFakeMap: !1
        });
    },
    handleShowPrivacy: function() {
        this.setData({
            showFakeMap: !0
        });
    },
    handleHidePrivacy: function() {
        this.setData({
            showFakeMap: !1
        });
    },
    hideMap: function() {
        var e = this;
        this.setData({
            paddingBottom: 400
        }), wx.createSelectorQuery().selectViewport().scrollOffset(function(t) {
            e.setData({
                scrollTop: t.scrollTop
            });
        }).exec(), wx.pageScrollTo({
            scrollTop: 600,
            duration: 300
        });
    },
    showMap: function() {
        wx.pageScrollTo({
            scrollTop: this.data.scrollTop,
            duration: 300
        }), this.setData({
            paddingBottom: 0
        });
    },
    refreshMap: (0, _.default)(t(a.default.mark(function e() {
        return a.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, this.getOrderChangedDetail(this.data.orderViewId, !0);

              case 2:
                this._setMap(this.data.order);

              case 3:
              case "end":
                return e.stop();
            }
        }, e, this);
    }))),
    openCommentDetail: function() {
        this._lxReport("b_7mjywepm"), (0, o.navigateTo)({
            url: "/comment/pages/commentDetail/commentDetail?orderViewId=" + this.data.orderViewId
        });
    },
    callServer: function() {
        var e = this;
        return t(a.default.mark(function t() {
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e._lxReport("b_2m1hh8d2"), t.prev = 1, t.next = 4, (0, b.makePhoneCall)({
                        phoneNumber: l.SERVICE_PHONE
                    });

                  case 4:
                    t.next = 9;
                    break;

                  case 6:
                    t.prev = 6, t.t0 = t.catch(1), console.error(t.t0);

                  case 9:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 1, 6 ] ]);
        }))();
    },
    goWebView: function(e) {
        var t = e.currentTarget.dataset.url + "&terminal=paotui_c&token=" + (0, i.getUserInfo)().token;
        m.default.click("b_banma_hlobduux_mc"), (0, h.setItem)("webViewUrl", t), (0, o.navigateTo)({
            url: "/pages/webView/webView"
        });
    },
    payOrder: function() {
        var e = this, r = this.data.orderViewId, i = this.data.order.businessType;
        this._lxReport("b_0wet7lvp"), (0, w.ptPay)({
            orderViewId: r,
            pay_success_url: "/pages/orderDetail/orderDetail?orderViewId=" + r,
            success: function() {
                var o = t(a.default.mark(function t() {
                    return a.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return t.next = 2, (0, T.subscribeOnPay)({
                                businessType: i,
                                orderViewId: r
                            });

                          case 2:
                            e._init(r);

                          case 3:
                          case "end":
                            return t.stop();
                        }
                    }, t, e);
                }));
                return function() {
                    return o.apply(this, arguments);
                };
            }()
        });
    },
    returnIndex: function() {
        (0, o.redirectTo)({
            url: "/pages/index/index"
        }), this._lxReport("b_sb9991vs");
    },
    _lxVisible: function() {
        var e = this, t = wx.createSelectorQuery();
        t.selectViewport().boundingClientRect(), setTimeout(function() {
            t.selectAll(".orderInfo >>> .lxVisible, .lxVisible").boundingClientRect(), t.exec(function(t) {
                if (t[0]) {
                    var r = t[0].height;
                    t[1].forEach(function(t) {
                        if (t) {
                            var a = t.bottom, i = t.dataset.bid;
                            C[i] || a <= r && (C[i] = !0, e._lxReport(i, "view"));
                        }
                    });
                }
            }), setTimeout(e._lxVisible, 2e3);
        }, 2e3);
    },
    asyncLuckyIconStatus: function(e) {
        this.setData({
            luckyIconStatus: e.detail.value
        });
    },
    handleViewMove: function(e) {
        this.setData({
            luckyIconStatus: 0
        });
    },
    handleRedPackageEnd: function() {
        (y.globalConfig || {}).favorites_degrade || (0, h.getItem)("hasShowedOrderTip") || (this.setData({
            orderTipShow: !0
        }), this.switchFakeMap(!0), (0, h.setItem)("hasShowedOrderTip", !0), this._lxReport("b_05goh0ru", "view"));
    },
    closeOrderTip: function() {
        this.setData({
            orderTipShow: !1
        }), this.switchFakeMap(!1), this._lxReport("b_if7qvnyv", "click");
    },
    closeCancelOrderModal: function() {
        this.setData({
            cancelOrderModalShow: !1
        }), this._lxReport("paotui_c_orddtl_yeswait_ck");
    },
    cancelOrderConfirm: function() {
        this.setData({
            cancelOrderModalShow: !1
        });
        var e = [ this.data.order ], t = e[0], r = e[1], a = void 0 === r ? t.orderViewId : r, i = e[2], o = void 0 === i ? t.orderStatus.value : i;
        this.handleCancel(a, o), this._lxReport("paotui_c_orddtl_nowait_ck");
    },
    clickStatusModifyOrderInfo: function() {
        this.clickModifyOrderInfo(), this._lxReport("b_banma_vmqonbcl_mc");
    },
    clickCancelModifyOrderInfo: function() {
        this.clickModifyOrderInfo(), this._lxReport("b_banma_1sitp4vy_mc");
    },
    showRefuseCancelModal: function(e) {
        this.setDataAsync({
            refuseCancelModalShow: !0,
            refuseCancelTitle: e.title,
            refuseCancelSubTitle: e.content
        }), this.switchFakeMap(!0);
    },
    closeRefuseCancelModal: function() {
        this.setDataAsync({
            refuseCancelModalShow: !1
        }), this.switchFakeMap(!1);
    },
    clickModifyOrderInfo: function() {
        var e = this;
        return t(a.default.mark(function t() {
            var r;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = void 0, t.prev = 1, t.next = 4, (0, u.postInfo)(c.getModifyInfoApi, {
                        orderViewId: e.data.orderViewId
                    });

                  case 4:
                    r = t.sent, t.next = 10;
                    break;

                  case 7:
                    t.prev = 7, t.t0 = t.catch(1), e.toast("网络异常");

                  case 10:
                    e.setData({
                        cancelOrderModalShow: !1
                    }), 0 === r.code ? e.changeOrder() : (0, s.ptShowModal)({
                        content: r.message || "服务器开小差了，请稍后重试",
                        showCancel: !1,
                        confirmText: "我知道了",
                        confirm: function() {
                            e._init(e.data.orderViewId);
                        }
                    });

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t, e, [ [ 1, 7 ] ]);
        }))();
    },
    handleModifyRecordTap: function() {
        var e = this.data.order;
        (0, o.navigateTo)({
            url: "/order/pages/modifyRecord/modifyRecord?orderViewId=" + this.data.orderViewId + "&" + e.businessType + "&" + e.orderStatus.value
        }), this._lxReport("b_banma_9hrpwtf7_mc");
    },
    handleCloseUrgeOrderModal: function() {
        this.closeUrgeOrderModal(), this._lxReport("b_banma_99qmf9vk_mc", "click");
    },
    closeUrgeOrderModal: function() {
        this.setData({
            urgeOrderModalShow: !1
        });
    },
    pickUpFee: function() {
        this.closeUrgeOrderModal(), this.openTipSlide(), this._lxReport("b_banma_on61ejxr_mc", "click");
    },
    cancelOrderModalUrgeOrder: function() {
        this.setData({
            cancelOrderModalShow: !1
        }), this.urgeOrder("canceOrderModal");
    },
    urgeOrder: function(e) {
        var r = this;
        return t(a.default.mark(function t() {
            var i, o, n, s, d, l, p, h, f, w;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, i = r.data.orderViewId, t.next = 4, (0, u.postInfo)(c.urgeOrderApi, {
                        orderId: i
                    });

                  case 4:
                    (o = t.sent) && 0 === o.code && o.data ? (n = o.data, s = n.urgeGrabCode, d = n.urgeGrabTitle, 
                    l = n.urgeGrabSubTitle, p = n.urgeGrabTimes, h = n.urgeGrabShowType, f = n.waitGrabTime, 
                    1 === s ? 1 === h ? (r.toast(d), 1 === p && r._init(i)) : 2 === h && (r.setData({
                        urgeGrabTitle: d,
                        urgeGrabSubTitle: l,
                        urgeOrderModalShow: !0
                    }), r._lxReport("c_banma_0cja96q9", "pv"), r._lxReport("b_banma_nlpyynx9_mv", "view"), 
                    r._lxReport("b_banma_3muk6fiy_mv", "view")) : 2 === s || 3 === s ? (r.toast(d), 
                    r._init(i)) : 4 === s && r.toast(d), w = "b_banma_xhgjbefp_mc", "canceOrderModal" === e && (w = "b_banma_os807755_mc"), 
                    r._lxReport(w, "click", {
                        is_urge_grab_success: 1 === s ? 1 : 0,
                        urge_grab_pay_time: f,
                        urge_grab_times: p
                    })) : r.toast(o.message || "操作失败，请稍后再试"), t.next = 11;
                    break;

                  case 8:
                    t.prev = 8, t.t0 = t.catch(0), r.toast("操作失败，请稍后再试");

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t, r, [ [ 0, 8 ] ]);
        }))();
    },
    _lxReport: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "click", r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, a = this.data.order;
        if (!a) return !1;
        var i = {
            order_status: a.orderStatus.value,
            businessType: a.businessType,
            order_id: a.orderViewId
        };
        m.default[t](e, Object.assign({}, i, r));
    }
});