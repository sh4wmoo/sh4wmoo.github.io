function r(r) {
    return 0 == r ? "1\b米" : parseFloat(r) >= 1 ? r.toFixed(1) + "公里" : (1e3 * r).toFixed(0) + "米";
}

function e(r) {
    var e = r.order, n = r.markType, t = n.id, i = n.en, o = n.ch, a = n.icon, d = r.content;
    if (e[i]) {
        var p = {
            id: t,
            latitude: e[i].lat / m,
            longitude: e[i].lng / m,
            title: o,
            iconPath: a,
            alpha: 1,
            width: 32,
            height: 36
        };
        return d ? Object.assign(p, s(d)) : p;
    }
}

function s(r) {
    return {
        callout: {
            content: r,
            color: "#ffffff",
            bgColor: "#474644",
            display: "ALWAYS",
            textAlign: "center",
            borderRadius: 18,
            padding: 10,
            fontSize: 14
        }
    };
}

function n(r, e) {
    if (r[e]) return {
        latitude: r[e].lat / m,
        longitude: r[e].lng / m
    };
}

function t(e) {
    var s = e.orderStatus.value, n = e.businessTypeTag;
    if (1 == s) {
        var t = (0, i.timeToDate)(1e3 * e.estimateArrivalTime);
        return 1 == n ? "3公里内就近购买 预计" + t + "前送达" : r(e.distance) + " 预计" + t + "前送达";
    }
    if (2 == s) return e.orderDetailUrgeGrabInfo && 1 === e.orderDetailUrgeGrabInfo.urgeGrabDegrade && e.orderDetailUrgeGrabInfo.urgeGrabTimes >= 1 && "B" === o.globalConfig.testIdMapping.urge_grab ? "正在加速为您寻找骑手" : "正在为您寻找骑手";
    if (3 === s || 62 === s) {
        if (1 === e.isPrebook) return "骑手已接单";
        if (1 === n) {
            var a = 1 === e.businessType ? "距收件地" : "距收货地";
            return e.latestRiderPoint ? "" + a + r(e.latestRiderPoint.distance) : "";
        }
        if (0 === n) {
            var d = 1 === e.businessType ? "距取件地" : "距商家";
            return e.latestRiderPoint ? "" + d + r(e.latestRiderPoint.distance) : "";
        }
    }
    if (4 === s) {
        var p = 1 === e.businessType ? "距收件地" : "距收货地";
        return e.latestRiderPoint ? "" + p + r(e.latestRiderPoint.distance) : "";
    }
    return 21 == s ? e.orderDetailUrgeGrabInfo && 1 === e.orderDetailUrgeGrabInfo.urgeGrabDegrade && e.orderDetailUrgeGrabInfo.urgeGrabTimes >= 1 && "B" === o.globalConfig.testIdMapping.urge_grab ? "正在加速为您寻找骑手" : "优先为您寻找骑手" : 31 === s || 64 === s ? 1 === e.businessType ? "骑手已到取件地，即将上门取件" : "骑手已到达商家，正在为您购买" : void 0;
}

!function(r) {
    r && r.__esModule;
}(require("../../libs/regenerator-runtime/runtime-module.js"));

var i = require("../../modules/utils/util.js"), o = require("../../modules/utils/abtest.js"), a = {
    id: 1,
    en: "recipientAddress",
    ch: "收货地址",
    icon: "../../imgs/receive.png"
}, d = {
    id: 2,
    en: "fetchAddress",
    ch: "发货地址",
    icon: "../../imgs/send.png"
}, p = {
    id: 4,
    en: "latestRiderPoint",
    ch: "骑手位置",
    icon: "../../imgs/rider.png"
}, u = {
    id: 3,
    en: "fetchAddress",
    ch: "购买地址",
    icon: "../../imgs/buy.png"
}, m = 1e6;

module.exports = {
    mapPoints: function(r) {
        var s = n(r, "recipientAddress"), i = n(r, "fetchAddress"), o = n(r, "latestRiderPoint"), m = t(r), l = e({
            order: r,
            markType: a
        }), g = e({
            order: r,
            markType: a,
            content: m
        }), k = e({
            order: r,
            markType: 1 === r.businessType ? d : u
        }), c = e({
            order: r,
            markType: 1 === r.businessType ? d : u,
            content: m
        }), f = e({
            order: r,
            markType: p,
            content: m
        });
        return {
            1: {
                now: {
                    markers: [ k, g ],
                    points: [ i, s ]
                },
                order: {
                    markers: [ k, g ],
                    points: [ i, s ]
                },
                hasAddr: {
                    markers: [ k, g ],
                    points: [ i, s ]
                },
                noAddr: {
                    markers: [ g ],
                    points: [ s ]
                }
            },
            2: {
                now: {
                    markers: [ c ],
                    points: [ i ]
                },
                order: {
                    markers: [ c ],
                    points: [ i ]
                },
                hasAddr: {
                    markers: [ c ],
                    points: [ i ]
                },
                noAddr: {
                    markers: [ g ],
                    points: [ s ]
                }
            },
            3: {
                now: {
                    markers: [ k, f ],
                    points: [ i, o ]
                },
                order: {
                    markers: [ l, c ],
                    points: [ i ]
                },
                hasAddr: {
                    markers: r.isPrebook ? [ c ] : [ k, f ],
                    points: [ i, o ]
                },
                noAddr: {
                    markers: r.isPrebook ? [ g ] : [ l, f ],
                    points: [ s, o ]
                }
            },
            4: {
                now: {
                    markers: [ l, f ],
                    points: [ s, o ]
                },
                order: {
                    markers: [ l, f ],
                    points: [ s, o ]
                },
                hasAddr: {
                    markers: [ l, f ],
                    points: [ s, o ]
                },
                noAddr: {
                    markers: [ l, f ],
                    points: [ s, o ]
                }
            },
            21: {
                now: {
                    markers: [ c ],
                    points: [ i ]
                },
                order: {
                    markers: [ c ],
                    points: [ i ]
                },
                hasAddr: {
                    markers: [ c ],
                    points: [ i ]
                },
                noAddr: {
                    markers: [ g ],
                    points: [ s ]
                }
            },
            31: {
                now: {
                    markers: [ k, f ],
                    points: [ i, o ]
                },
                order: {
                    markers: [ k, f ],
                    points: [ i, o ]
                },
                hasAddr: {
                    markers: [ k, f ],
                    points: [ i, o ]
                },
                noAddr: {
                    markers: [ l, f ],
                    points: [ s, o ]
                }
            },
            62: {
                now: {
                    markers: [ l, f ],
                    points: [ s, o ]
                },
                order: {
                    markers: [ l, f ],
                    points: [ s, o ]
                },
                hasAddr: {
                    markers: [ l, f ],
                    points: [ s, o ]
                },
                noAddr: {
                    markers: [ l, f ],
                    points: [ s, o ]
                }
            },
            64: {
                now: {
                    markers: [ k, f ],
                    points: [ i, o ]
                },
                order: {
                    markers: [ k, f ],
                    points: [ i, o ]
                },
                hasAddr: {
                    markers: [ k, f ],
                    points: [ i, o ]
                },
                noAddr: {
                    markers: [ l, f ],
                    points: [ s, o ]
                }
            }
        };
    },
    MARKER_RCPT: 1,
    MARKER_FETCH: 2,
    MARKER_BUY: 3,
    MARKER_RIRDER: 4
};