function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, u) {
            function n(r, i) {
                try {
                    var a = t[r](i), o = a.value;
                } catch (e) {
                    return void u(e);
                }
                if (!a.done) return Promise.resolve(o).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(o);
            }
            return n("next");
        });
    };
}

var u = e(require("./libs/regenerator-runtime/runtime-module.js")), n = require("./modules/api/cat.js"), r = e(require("./modules/api/lx.js")), i = require("./modules/api/metrics.js"), a = e(require("./modules/global.js")), o = require("./modules/utils/uuid.js");

(0, i.app)({
    onLaunch: function() {
        var e = t(u.default.mark(function e(t) {
            return u.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    r.default.init("https://report.meituan.com", {
                        appnm: "paotui_c_miniprograms",
                        category: "banma"
                    }), r.default.set("app", a.default.version), r.default.set("uuid", o.uuid), r.default.setPaotuiEnv(), 
                    (0, n.start)(a.default.version, a.default.env), (0, i.init)(this, a.default.version, a.default.env);

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t) {
            return e.apply(this, arguments);
        };
    }(),
    onShow: function(e) {
        r.default.start();
    },
    onHide: function() {
        r.default.quit();
    }
}, n.app);